# Last Stand Legends — local play guide

## Run locally

1. Install Node.js 22 or newer.
2. Extract the project ZIP.
3. Open a terminal in the `last-stand-legends-main` folder.
4. Run `npm install` (or `bun install` if you use Bun).
5. Run `npm run dev`.
6. Open the local address printed in the terminal (normally `http://localhost:5173`).

## Controls

- **WASD / arrow keys:** move
- **Space:** character ability
- **Shift:** dash
- **Esc / P:** pause or resume
- **Mouse:** aim for weapons that use aiming

The game stores progress in the browser's local storage. Clearing browser data can erase that local save.

## Build checks

The supplied archive was missing `src/game/engine/render.ts`, and its home route was still the default Lovable placeholder. A renderer and a playable game menu/route have been added. A full dependency install/build could not be completed in the editing environment because package installation timed out; run `npm install` and `npm run build` locally to verify against your installed dependencies.
