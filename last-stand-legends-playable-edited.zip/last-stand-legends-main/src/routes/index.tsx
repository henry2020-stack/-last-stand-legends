import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { Game } from "@/game/engine/game";
import type { GameConfigInput } from "@/game/engine/config";
import type { HudSnapshot, UpgradeChoice } from "@/game/engine/types";
import { CHARACTERS, CHAR_IDS, type CharId } from "@/game/data/characters";
import { MAPS, MAP_IDS, type MapId } from "@/game/data/maps";
import { MODES, DIFFICULTIES, CHALLENGES, type ModeId, type DifficultyId, type ChallengeId } from "@/game/data/modes";
import { SHOP, SHOP_IDS, shopCost } from "@/game/data/shop";
import { WEAPONS, WEAPON_IDS } from "@/game/data/weapons";
import { ACHIEVEMENTS, applyRunResult, defaultSave, isMapUnlocked, loadSave, persist, type RunResult } from "@/game/save";

export const Route = createFileRoute("/")({
  head: () => ({ meta: [{ title: "Last Stand Legends — Survive the Eclipse" }, { name: "description", content: "A fast-paced fantasy survivor roguelite. Build your arsenal, evolve weapons and defeat colossal bosses." }] }),
  component: Index,
});

type Screen = "menu" | "run" | "levelup" | "paused" | "over";
const panel = "rounded-2xl border border-white/10 bg-[#101827]/90 shadow-2xl shadow-black/30 backdrop-blur-xl";
const btn = "rounded-xl border border-cyan-300/25 bg-cyan-300/10 px-4 py-3 text-sm font-bold text-cyan-100 transition hover:border-cyan-200/60 hover:bg-cyan-300/20 disabled:cursor-not-allowed disabled:opacity-40";

function Index() {
  const [save, setSave] = useState(() => loadSave());
  const [screen, setScreen] = useState<Screen>("menu");
  const [mode, setMode] = useState<ModeId>(save.last.mode);
  const [map, setMap] = useState<MapId>(save.last.map);
  const [char, setChar] = useState<CharId>(save.last.char);
  const [difficulty, setDifficulty] = useState<DifficultyId>(save.last.difficulty);
  const [challenge, setChallenge] = useState<ChallengeId>(save.last.challenge);
  const [hud, setHud] = useState<HudSnapshot | null>(null);
  const [choices, setChoices] = useState<UpgradeChoice[] | null>(null);
  const [result, setResult] = useState<RunResult | null>(null);
  const [notice, setNotice] = useState("");
  const [runKey, setRunKey] = useState(0);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const gameRef = useRef<Game | null>(null);
  const mounted = screen !== "menu";
  const selectedChar = CHARACTERS[char];
  const unlockedMap = useMemo(() => MAP_IDS.filter((id) => isMapUnlocked(save, id)), [save]);

  const startRun = useCallback(() => {
    const nextSave = { ...save, last: { char, map, mode, difficulty, challenge } };
    setSave(nextSave); persist(nextSave);
    setHud(null); setChoices(null); setResult(null); setScreen("run"); setRunKey((v) => v + 1);
  }, [save, char, map, mode, difficulty, challenge]);

  useEffect(() => {
    if (!mounted || !canvasRef.current) return;
    const cfg: GameConfigInput = { mode, map, char, difficulty, challenge, save };
    const game = new Game(canvasRef.current, cfg, {
      onLevelUp: (next) => { setChoices(next); setScreen(next ? "levelup" : "run"); },
      onHud: setHud,
      onBanner: (b) => setNotice(b.sub ? `${b.text} — ${b.sub}` : b.text),
      onPause: (paused) => setScreen(paused ? "paused" : "run"),
      onEnd: (r) => {
        setResult(r);
        setSave((prev) => {
          const updated = applyRunResult(prev, r).save;
          persist(updated);
          return updated;
        });
        setScreen("over");
      },
    });
    gameRef.current = game;
    game.start();
    return () => { game.destroy(); gameRef.current = null; };
  // runKey intentionally creates exactly one game instance per run.
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [runKey, mounted]);

  const returnToMenu = () => { gameRef.current?.destroy(); gameRef.current = null; setScreen("menu"); setChoices(null); };
  const unlockCharacter = (id: CharId) => {
    const cost = CHARACTERS[id].cost;
    if (save.chars.includes(id) || save.coins < cost) return;
    const updated = { ...save, coins: save.coins - cost, chars: [...save.chars, id] };
    setSave(updated); persist(updated); setChar(id);
  };
  const buyShop = (id: (typeof SHOP_IDS)[number]) => {
    const rank = save.shop[id] ?? 0;
    const cost = shopCost(id, rank);
    if (rank >= SHOP[id].max || save.coins < cost) return;
    const updated = { ...save, coins: save.coins - cost, shop: { ...save.shop, [id]: rank + 1 } };
    setSave(updated); persist(updated);
  };

  if (screen === "menu") return (
    <main className="min-h-screen overflow-hidden bg-[#080d18] text-white">
      <div className="pointer-events-none fixed inset-0 opacity-50" style={{ background: "radial-gradient(ellipse at 50% 0%, #164e63 0%, transparent 48%), radial-gradient(ellipse at 90% 80%, #38205f 0%, transparent 40%)" }} />
      <div className="relative mx-auto max-w-7xl px-5 py-8 md:px-8">
        <header className="mb-10 flex flex-wrap items-center justify-between gap-4">
          <div><p className="text-xs font-black uppercase tracking-[.35em] text-cyan-300">A survivor roguelite</p><h1 className="mt-1 text-3xl font-black tracking-tight md:text-5xl">LAST STAND <span className="text-cyan-300">LEGENDS</span></h1></div>
          <div className={`${panel} flex items-center gap-3 px-5 py-3`}><span className="text-xl">✦</span><div><div className="text-[10px] uppercase tracking-widest text-slate-400">Your coins</div><div className="text-xl font-black text-amber-300">{save.coins.toLocaleString()}</div></div></div>
        </header>
        <div className="grid gap-6 lg:grid-cols-[1.35fr_.85fr]">
          <section className={`${panel} relative overflow-hidden p-6 md:p-9`}>
            <div className="absolute -right-10 -top-10 h-64 w-64 rounded-full bg-cyan-400/10 blur-3xl" />
            <div className="relative"><div className="mb-4 inline-flex rounded-full border border-cyan-300/30 bg-cyan-300/10 px-3 py-1 text-xs font-bold uppercase tracking-widest text-cyan-200">The eclipse is rising</div>
              <h2 className="max-w-2xl text-4xl font-black leading-tight md:text-6xl">HOW LONG CAN<br/><span className="text-cyan-300">YOU SURVIVE?</span></h2>
              <p className="mt-4 max-w-xl text-sm leading-6 text-slate-300">Fight endless waves, collect experience, build devastating weapon combinations and face five ancient bosses across a world on the brink.</p>
              <div className="mt-8 grid gap-4 sm:grid-cols-2">
                <label className="text-xs font-bold uppercase tracking-widest text-slate-400">Game mode<select className="mt-2 w-full rounded-xl border border-white/10 bg-[#0a1220] p-3 text-sm text-white" value={mode} onChange={(e) => setMode(e.target.value as ModeId)}>{Object.values(MODES).map((m) => <option key={m.id} value={m.id}>{m.name}</option>)}</select></label>
                <label className="text-xs font-bold uppercase tracking-widest text-slate-400">Difficulty<select className="mt-2 w-full rounded-xl border border-white/10 bg-[#0a1220] p-3 text-sm text-white" value={difficulty} onChange={(e) => setDifficulty(e.target.value as DifficultyId)}>{Object.values(DIFFICULTIES).map((d) => <option key={d.id} value={d.id}>{d.name}</option>)}</select></label>
                <label className="text-xs font-bold uppercase tracking-widest text-slate-400">Arena<select className="mt-2 w-full rounded-xl border border-white/10 bg-[#0a1220] p-3 text-sm text-white" value={map} onChange={(e) => setMap(e.target.value as MapId)}>{MAP_IDS.map((id) => <option key={id} value={id} disabled={!unlockedMap.includes(id)}>{MAPS[id].name}{unlockedMap.includes(id) ? "" : " — locked"}</option>)}</select></label>
                <label className="text-xs font-bold uppercase tracking-widest text-slate-400">Challenge rules<select className="mt-2 w-full rounded-xl border border-white/10 bg-[#0a1220] p-3 text-sm text-white" value={challenge} onChange={(e) => setChallenge(e.target.value as ChallengeId)}>{Object.values(CHALLENGES).map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}</select></label>
              </div>
              <div className="mt-7 flex flex-wrap items-center gap-4"><button className="rounded-xl bg-cyan-300 px-8 py-4 text-base font-black uppercase tracking-wider text-slate-950 shadow-lg shadow-cyan-300/20 transition hover:scale-[1.02] hover:bg-cyan-200" onClick={startRun}>▶ Start survival</button><span className="text-xs text-slate-400">WASD / arrows to move · Space ability · Shift dash · Esc pause</span></div>
            </div>
          </section>
          <section className={`${panel} p-6`}>
            <div className="mb-4 flex items-center justify-between"><div><p className="text-xs font-bold uppercase tracking-widest text-cyan-300">Choose your legend</p><h2 className="text-2xl font-black">HERO ROSTER</h2></div><span className="text-xs text-slate-400">{save.chars.length}/{CHAR_IDS.length} unlocked</span></div>
            <div className="grid grid-cols-2 gap-2 sm:grid-cols-4 lg:grid-cols-2">{CHAR_IDS.map((id) => { const c = CHARACTERS[id]; const unlocked = save.chars.includes(id); return <button key={id} disabled={!unlocked && save.coins < c.cost} onClick={() => unlocked ? setChar(id) : unlockCharacter(id)} className={`rounded-xl border p-3 text-left transition ${char === id ? "border-cyan-300 bg-cyan-300/10" : "border-white/10 bg-black/20 hover:border-white/30"} disabled:opacity-30`}><div className="mb-2 flex h-10 items-center justify-center rounded-lg" style={{ background: `radial-gradient(circle, ${c.glow}55, transparent 70%)` }}><span className="text-2xl" style={{ color: c.trim }}>◆</span></div><div className="font-black">{c.name}</div><div className="text-[10px] text-slate-400">{c.title}</div>{!unlocked && <div className="mt-1 text-[10px] text-amber-300">Unlock · {c.cost} coins</div>}</button>; })}</div>
            <div className="mt-4 rounded-xl border border-white/10 bg-black/20 p-4"><div className="flex items-center gap-3"><div className="h-3 w-3 rounded-full" style={{ background: selectedChar.glow, boxShadow: `0 0 16px ${selectedChar.glow}` }}/><div><div className="font-black">{selectedChar.name} · {selectedChar.title}</div><div className="text-xs text-slate-400">Starts with {WEAPONS[selectedChar.weapon].name}</div></div></div><p className="mt-2 text-xs leading-5 text-slate-300">{selectedChar.desc}</p><p className="mt-2 text-[11px] text-cyan-200">{selectedChar.ability.name}: {selectedChar.ability.desc}</p></div>
          </section>
        </div>
        <div className="mt-6 grid gap-6 lg:grid-cols-[1fr_1fr]">
          <section className={`${panel} p-5`}><div className="mb-3 flex items-center justify-between"><h3 className="font-black tracking-wide">PERMANENT UPGRADES</h3><span className="text-xs text-slate-400">Spend coins between runs</span></div><div className="grid gap-2 sm:grid-cols-2">{SHOP_IDS.map((id) => { const rank = save.shop[id] ?? 0; const cost = shopCost(id, rank); return <div key={id} className="flex items-center justify-between gap-3 rounded-xl border border-white/10 bg-black/20 p-3"><div><div className="text-sm font-bold">{SHOP[id].name} <span className="text-xs text-cyan-300">{rank}/{SHOP[id].max}</span></div><div className="text-[10px] text-slate-400">{SHOP[id].desc}</div></div><button className={`${btn} px-3 py-2 text-xs`} disabled={rank >= SHOP[id].max || save.coins < cost} onClick={() => buyShop(id)}>{rank >= SHOP[id].max ? "MAX" : `✦ ${cost}`}</button></div>; })}</div></section>
          <section className={`${panel} p-5`}><h3 className="mb-3 font-black tracking-wide">LEGEND RECORD</h3><div className="grid grid-cols-2 gap-3">{[["Total kills", save.stats.totalKills.toLocaleString()], ["Runs played", save.stats.runs], ["Best level", save.stats.maxLevel], ["Total time", `${Math.floor(save.stats.totalTime / 60)}m`]].map(([label, value]) => <div key={label} className="rounded-xl bg-black/20 p-4"><div className="text-2xl font-black text-cyan-200">{value}</div><div className="text-[10px] uppercase tracking-widest text-slate-400">{label}</div></div>)}</div><div className="mt-4 text-xs text-slate-400">Achievements unlocked: {save.achievements.length}/{ACHIEVEMENTS.length}</div><div className="mt-2 h-2 overflow-hidden rounded-full bg-black/40"><div className="h-full rounded-full bg-cyan-300" style={{ width: `${100 * save.achievements.length / ACHIEVEMENTS.length}%` }}/></div></section>
        </div>
        <footer className="mt-8 text-center text-[10px] tracking-widest text-slate-600">LAST STAND LEGENDS · SURVIVE THE ECLIPSE</footer>
      </div>
    </main>
  );

  return <main className="relative h-screen w-screen overflow-hidden bg-[#080d18] text-white"><canvas ref={canvasRef} className="absolute inset-0 h-full w-full touch-none" />
    <div className="pointer-events-none absolute left-1/2 top-3 -translate-x-1/2 rounded-full border border-white/10 bg-black/50 px-4 py-2 text-center text-xs text-slate-200 backdrop-blur"><span className="font-bold text-cyan-200">{MAPS[map].name}</span>{hud && <span className="ml-3">{hud.goal}</span>}</div>
    <div className="pointer-events-none absolute right-4 top-4 rounded-xl border border-white/10 bg-black/45 px-3 py-2 text-right text-xs backdrop-blur"><div className="font-bold">{selectedChar.name}</div><div className="text-cyan-200">{hud?.coins ?? 0} coins · {hud?.kills ?? 0} kills</div></div>
    {notice && screen === "run" && <div className="pointer-events-none absolute left-1/2 top-20 -translate-x-1/2 rounded-lg bg-black/55 px-4 py-2 text-center text-xs text-amber-100">{notice}</div>}
    {hud?.boss && <div className="absolute left-1/2 top-16 w-[min(420px,80vw)] -translate-x-1/2"><div className="mb-1 text-center text-xs font-black">{hud.boss.name}</div><div className="h-3 overflow-hidden rounded-full border border-white/30 bg-black/70"><div className="h-full" style={{ width: `${100 * hud.boss.hp / hud.boss.max}%`, background: hud.boss.color }}/></div></div>}
    {(screen === "levelup" || screen === "paused" || screen === "over") && <div className="absolute inset-0 flex items-center justify-center overflow-y-auto bg-[#050914]/75 p-4 backdrop-blur-sm"><section className={`${panel} my-auto w-full max-w-2xl p-6 md:p-8`}>
      {screen === "levelup" && <><p className="text-center text-xs font-black uppercase tracking-[.3em] text-cyan-300">Power surge · Level {hud?.level ?? "up"}</p><h2 className="mt-2 text-center text-3xl font-black">CHOOSE AN UPGRADE</h2><p className="mb-6 mt-2 text-center text-sm text-slate-400">Your next evolution starts here. Pick one reward.</p><div className="grid gap-3 md:grid-cols-3">{choices?.map((c, i) => <button key={`${c.id}-${i}`} onClick={() => gameRef.current?.choose(i)} className="rounded-xl border border-white/10 bg-black/25 p-4 text-left transition hover:-translate-y-1 hover:border-cyan-300/60 hover:bg-cyan-300/10"><div className="mb-3 flex items-center justify-between"><span className="rounded-lg px-2 py-1 text-[10px] font-black uppercase" style={{ background: `${c.color}25`, color: c.color }}>{c.rarity}</span><span className="text-xs text-slate-400">{c.tag}</span></div><div className="text-lg font-black">{c.name}</div><p className="mt-2 text-xs leading-5 text-slate-300">{c.desc}</p></button>)}</div><div className="mt-5 flex justify-center"><button className={btn} disabled={!hud?.rerolls} onClick={() => gameRef.current?.reroll()}>↻ Reroll ({hud?.rerolls ?? 0})</button></div></>}
      {screen === "paused" && <><p className="text-center text-xs font-bold uppercase tracking-[.3em] text-cyan-300">Take a breath</p><h2 className="my-3 text-center text-4xl font-black">PAUSED</h2><p className="mb-6 text-center text-sm text-slate-400">The monsters are waiting. Your run is safe.</p><div className="flex flex-wrap justify-center gap-3"><button className={btn} onClick={() => gameRef.current?.setPaused(false)}>▶ Resume</button><button className={btn} onClick={returnToMenu}>Return to menu</button></div></>}
      {screen === "over" && <><p className="text-center text-xs font-black uppercase tracking-[.3em] text-cyan-300">{result?.won ? "The eclipse is broken" : "The arena has fallen"}</p><h2 className="my-3 text-center text-4xl font-black">{result?.won ? "VICTORY" : "RUN OVER"}</h2><div className="grid grid-cols-2 gap-3 sm:grid-cols-4">{[["Time", `${Math.floor((result?.time ?? 0) / 60)}:${String((result?.time ?? 0) % 60).padStart(2, "0")}`], ["Kills", result?.kills ?? 0], ["Level", result?.level ?? 1], ["Score", (result?.score ?? 0).toLocaleString()]].map(([k, v]) => <div key={k} className="rounded-xl bg-black/30 p-3 text-center"><div className="text-2xl font-black text-cyan-200">{v}</div><div className="text-[10px] uppercase tracking-widest text-slate-400">{k}</div></div>)}</div><p className="my-5 text-center text-sm text-amber-200">+{result?.coins ?? 0} coins earned · saved to your record</p><div className="flex flex-wrap justify-center gap-3"><button className={btn} onClick={startRun}>↻ Play again</button><button className={btn} onClick={returnToMenu}>Main menu</button></div></>}
    </section></div>}
    {screen === "run" && <button aria-label="Pause game" onClick={() => gameRef.current?.setPaused(true)} className="absolute bottom-4 right-4 rounded-xl border border-white/20 bg-black/50 px-4 py-2 text-xs font-bold backdrop-blur">Ⅱ Pause</button>}
  </main>;
}
