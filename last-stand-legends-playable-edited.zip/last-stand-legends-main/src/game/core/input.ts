/** Keyboard, mouse and virtual-joystick input. Attach once per game instance. */
export class Input {
  keys = new Set<string>();
  mouseX = 0;
  mouseY = 0;
  mouseActive = false;
  joyX = 0;
  joyY = 0;
  touchMode = false;
  private dashQ = false;
  private abilityQ = false;
  private pauseQ = false;
  private canvas: HTMLCanvasElement | null = null;

  private onKeyDown = (e: KeyboardEvent) => {
    const c = e.code;
    if (c === "Space" || c.startsWith("Arrow")) e.preventDefault();
    if (e.repeat) return;
    this.keys.add(c);
    if (c === "Space") this.abilityQ = true;
    if (c === "ShiftLeft" || c === "ShiftRight") this.dashQ = true;
    if (c === "Escape" || c === "KeyP") this.pauseQ = true;
  };
  private onKeyUp = (e: KeyboardEvent) => this.keys.delete(e.code);
  private onMouse = (e: MouseEvent) => {
    if (!this.canvas) return;
    const r = this.canvas.getBoundingClientRect();
    this.mouseX = e.clientX - r.left;
    this.mouseY = e.clientY - r.top;
    this.mouseActive = true;
    this.touchMode = false;
  };
  private onBlur = () => {
    this.keys.clear();
    this.pauseQ = true;
  };
  private onTouch = () => {
    this.touchMode = true;
    this.mouseActive = false;
  };
  private onContext = (e: Event) => e.preventDefault();
  private onMouseDown = (e: MouseEvent) => {
    if (e.button === 2) this.dashQ = true;
  };

  attach(canvas: HTMLCanvasElement) {
    this.canvas = canvas;
    window.addEventListener("keydown", this.onKeyDown);
    window.addEventListener("keyup", this.onKeyUp);
    window.addEventListener("mousemove", this.onMouse);
    window.addEventListener("blur", this.onBlur);
    window.addEventListener("touchstart", this.onTouch, { passive: true });
    canvas.addEventListener("contextmenu", this.onContext);
    canvas.addEventListener("mousedown", this.onMouseDown);
    if (typeof matchMedia !== "undefined" && matchMedia("(pointer: coarse)").matches) this.touchMode = true;
  }
  detach() {
    window.removeEventListener("keydown", this.onKeyDown);
    window.removeEventListener("keyup", this.onKeyUp);
    window.removeEventListener("mousemove", this.onMouse);
    window.removeEventListener("blur", this.onBlur);
    window.removeEventListener("touchstart", this.onTouch);
    this.canvas?.removeEventListener("contextmenu", this.onContext);
    this.canvas?.removeEventListener("mousedown", this.onMouseDown);
    this.canvas = null;
  }
  move(): { x: number; y: number } {
    let x = 0, y = 0;
    const k = this.keys;
    if (k.has("KeyW") || k.has("ArrowUp")) y -= 1;
    if (k.has("KeyS") || k.has("ArrowDown")) y += 1;
    if (k.has("KeyA") || k.has("ArrowLeft")) x -= 1;
    if (k.has("KeyD") || k.has("ArrowRight")) x += 1;
    x += this.joyX;
    y += this.joyY;
    const l = Math.hypot(x, y);
    if (l > 1) { x /= l; y /= l; }
    return { x, y };
  }
  queueDash() { this.dashQ = true; }
  queueAbility() { this.abilityQ = true; }
  takeDash() { const v = this.dashQ; this.dashQ = false; return v; }
  takeAbility() { const v = this.abilityQ; this.abilityQ = false; return v; }
  takePause() { const v = this.pauseQ; this.pauseQ = false; return v; }
  clearQueued() { this.dashQ = this.abilityQ = this.pauseQ = false; }
}
