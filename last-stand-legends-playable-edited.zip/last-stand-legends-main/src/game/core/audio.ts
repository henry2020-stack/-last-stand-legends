/** Procedural WebAudio sound effects and music sequencer — no audio files needed. */
export type Sfx =
  | "shoot" | "hit" | "crit" | "kill" | "xp" | "levelup" | "dash" | "ability" | "explosion"
  | "zap" | "fire" | "ice" | "hurt" | "roar" | "bossIntro" | "coin" | "chest" | "evolve"
  | "click" | "hover" | "beam" | "enemyShot" | "heal" | "block" | "warn" | "victory" | "defeat";

export type Track = "menu" | "battle" | "boss" | "none";

interface TrackDef {
  bpm: number;
  bass: (number | null)[];
  lead: (number | null)[];
  kick: string;
  snare: string;
  hat: string;
  leadWave: OscillatorType;
  pad: number[];
}

const TRACKS: Record<Exclude<Track, "none">, TrackDef> = {
  menu: {
    bpm: 84, leadWave: "triangle",
    bass: [0, null, null, null, 0, null, null, null, -4, null, null, null, -2, null, null, null],
    lead: [12, null, 15, null, 19, null, 15, null, 8, null, 12, null, 14, null, 10, null],
    kick: "x.......x.......", snare: "................", hat: "....x.......x...", pad: [0, 3, 7],
  },
  battle: {
    bpm: 128, leadWave: "square",
    bass: [0, 0, 12, 0, 0, 12, 0, 10, -2, -2, 10, -2, 3, 3, 15, 5],
    lead: [12, null, 15, 17, null, 15, 12, null, 10, null, 12, 15, null, 19, 17, null],
    kick: "x...x...x...x...", snare: "....x.......x...", hat: "x.x.x.x.x.x.x.xx", pad: [0, 3, 7],
  },
  boss: {
    bpm: 150, leadWave: "sawtooth",
    bass: [0, 0, 0, 12, 0, 0, 1, 13, 0, 0, 0, 12, -1, -1, 1, 6],
    lead: [12, 13, null, 12, 18, null, 17, 13, 12, null, 13, 15, 18, 17, 13, null],
    kick: "x..xx...x..xx.x.", snare: "....x.......x..x", hat: "xxxxxxxxxxxxxxxx", pad: [0, 1, 6],
  },
};

const mtof = (m: number) => 440 * Math.pow(2, (m - 69) / 12);

class AudioEngine {
  ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  private musicGain: GainNode | null = null;
  private sfxGain: GainNode | null = null;
  private noise: AudioBuffer | null = null;
  private last = new Map<Sfx, number>();
  private vol = { master: 0.8, music: 0.55, sfx: 0.8 };
  private track: Track = "none";
  private root = 45;
  private step = 0;
  private nextTime = 0;
  private timer: ReturnType<typeof setInterval> | null = null;

  /** Must be called from a user gesture. */
  init() {
    if (this.ctx) {
      if (this.ctx.state === "suspended") void this.ctx.resume();
      return;
    }
    const AC = window.AudioContext ?? (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!AC) return;
    const ctx = new AC();
    this.ctx = ctx;
    const comp = ctx.createDynamicsCompressor();
    comp.threshold.value = -14;
    comp.ratio.value = 4;
    comp.connect(ctx.destination);
    this.master = ctx.createGain();
    this.master.connect(comp);
    this.musicGain = ctx.createGain();
    this.musicGain.connect(this.master);
    this.sfxGain = ctx.createGain();
    this.sfxGain.connect(this.master);
    const len = ctx.sampleRate;
    this.noise = ctx.createBuffer(1, len, ctx.sampleRate);
    const d = this.noise.getChannelData(0);
    for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
    this.applyVolumes();
    this.timer = setInterval(() => this.schedule(), 30);
  }

  setVolumes(v: { master: number; music: number; sfx: number }) {
    this.vol = { ...v };
    this.applyVolumes();
  }
  private applyVolumes() {
    if (!this.ctx || !this.master || !this.musicGain || !this.sfxGain) return;
    const t = this.ctx.currentTime;
    this.master.gain.setTargetAtTime(this.vol.master, t, 0.05);
    this.musicGain.gain.setTargetAtTime(this.vol.music * 0.35, t, 0.05);
    this.sfxGain.gain.setTargetAtTime(this.vol.sfx * 0.6, t, 0.05);
  }

  setTrack(track: Track, root = 45) {
    if (this.track === track && this.root === root) return;
    this.track = track;
    this.root = root;
    this.step = 0;
    if (this.ctx) this.nextTime = this.ctx.currentTime + 0.05;
  }

  private schedule() {
    const ctx = this.ctx;
    if (!ctx || this.track === "none" || ctx.state !== "running") return;
    const tr = TRACKS[this.track];
    const stepDur = 60 / tr.bpm / 4;
    if (this.nextTime < ctx.currentTime) this.nextTime = ctx.currentTime + 0.02;
    while (this.nextTime < ctx.currentTime + 0.15) {
      this.playStep(tr, this.step, this.nextTime, stepDur);
      this.nextTime += stepDur;
      this.step = (this.step + 1) % 64;
    }
  }

  private playStep(tr: TrackDef, step: number, t: number, sd: number) {
    const s = step % 16;
    const bar = Math.floor(step / 16);
    const shift = [0, 0, -4, -2][bar] ?? 0;
    const out = this.musicGain!;
    if (tr.kick[s] === "x") this.kick(t, out);
    if (tr.snare[s] === "x") this.snare(t, out);
    if (tr.hat[s] === "x") this.hat(t, out, s % 4 === 2 ? 0.07 : 0.035);
    const b = tr.bass[s];
    if (b != null) this.tone(mtof(this.root - 12 + b + shift), t, sd * 0.9, "sawtooth", 0.13, out, 900);
    const l = tr.lead[s];
    if (l != null && bar % 2 === 1) this.tone(mtof(this.root + l + shift), t, sd * 0.8, tr.leadWave, 0.045, out, 2600);
    if (s === 0) for (const p of tr.pad) this.tone(mtof(this.root + 12 + p + shift), t, sd * 15, "triangle", 0.022, out, 1500, 0.4);
  }

  private env(g: GainNode, t: number, vol: number, a: number, dur: number) {
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(Math.max(0.0002, vol), t + a);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
  }

  private tone(freq: number, t: number, dur: number, type: OscillatorType, vol: number, out: AudioNode, cutoff = 4000, attack = 0.005, slideTo?: number) {
    const ctx = this.ctx!;
    const o = ctx.createOscillator();
    o.type = type;
    o.frequency.setValueAtTime(freq, t);
    if (slideTo) o.frequency.exponentialRampToValueAtTime(Math.max(20, slideTo), t + dur);
    const f = ctx.createBiquadFilter();
    f.type = "lowpass";
    f.frequency.value = cutoff;
    const g = ctx.createGain();
    this.env(g, t, vol, attack, dur);
    o.connect(f).connect(g).connect(out);
    o.start(t);
    o.stop(t + dur + 0.05);
  }

  private noiseHit(t: number, dur: number, vol: number, out: AudioNode, type: BiquadFilterType, freq: number, freqTo?: number, q = 1) {
    const ctx = this.ctx!;
    const src = ctx.createBufferSource();
    src.buffer = this.noise;
    const f = ctx.createBiquadFilter();
    f.type = type;
    f.frequency.setValueAtTime(freq, t);
    if (freqTo) f.frequency.exponentialRampToValueAtTime(freqTo, t + dur);
    f.Q.value = q;
    const g = ctx.createGain();
    this.env(g, t, vol, 0.003, dur);
    src.connect(f).connect(g).connect(out);
    src.start(t, Math.random() * 0.5);
    src.stop(t + dur + 0.05);
  }

  private kick(t: number, out: AudioNode) { this.tone(140, t, 0.22, "sine", 0.5, out, 800, 0.002, 40); }
  private snare(t: number, out: AudioNode) { this.noiseHit(t, 0.16, 0.18, out, "bandpass", 1800, 900, 0.8); this.tone(200, t, 0.08, "triangle", 0.08, out); }
  private hat(t: number, out: AudioNode, v: number) { this.noiseHit(t, 0.04, v, out, "highpass", 7000); }

  play(name: Sfx, vol = 1, pitch = 1) {
    const ctx = this.ctx;
    if (!ctx || ctx.state !== "running" || !this.sfxGain) return;
    const now = ctx.currentTime;
    const minGap: Partial<Record<Sfx, number>> = { hit: 0.035, xp: 0.03, shoot: 0.05, kill: 0.04, zap: 0.06, fire: 0.08, ice: 0.06, beam: 0.09, enemyShot: 0.07, coin: 0.05, block: 0.08, crit: 0.05, explosion: 0.06 };
    const gap = minGap[name] ?? 0;
    if (gap && now - (this.last.get(name) ?? 0) < gap) return;
    this.last.set(name, now);
    const o = this.sfxGain;
    const t = now + 0.005;
    const r = 1 + (Math.random() - 0.5) * 0.12;
    const p = pitch * r;
    switch (name) {
      case "shoot": this.tone(880 * p, t, 0.07, "square", 0.05 * vol, o, 3000, 0.002, 300 * p); break;
      case "hit": this.noiseHit(t, 0.06, 0.12 * vol, o, "bandpass", 2400 * p, 600, 1.5); break;
      case "crit": this.tone(1400 * p, t, 0.1, "triangle", 0.09 * vol, o, 6000, 0.002, 2200 * p); this.noiseHit(t, 0.08, 0.14 * vol, o, "highpass", 3000); break;
      case "kill": this.tone(320 * p, t, 0.09, "square", 0.05 * vol, o, 1800, 0.002, 90); break;
      case "xp": this.tone(1100 * p, t, 0.06, "sine", 0.06 * vol, o, 6000, 0.002, 1700 * p); break;
      case "coin": this.tone(1320, t, 0.06, "square", 0.04 * vol, o, 5000); this.tone(1760, t + 0.06, 0.12, "square", 0.04 * vol, o, 5000); break;
      case "levelup": [0, 4, 7, 12, 16].forEach((n, i) => this.tone(mtof(72 + n), t + i * 0.06, 0.3, "triangle", 0.1 * vol, o, 5000)); break;
      case "dash": this.noiseHit(t, 0.22, 0.2 * vol, o, "bandpass", 600, 3500, 2); break;
      case "ability": this.noiseHit(t, 0.5, 0.25 * vol, o, "lowpass", 3000, 200); this.tone(110, t, 0.5, "sawtooth", 0.15 * vol, o, 900, 0.01, 55); break;
      case "explosion": this.noiseHit(t, 0.5, 0.32 * vol, o, "lowpass", 1800 * p, 80); this.tone(90 * p, t, 0.35, "sine", 0.3 * vol, o, 400, 0.002, 30); break;
      case "zap": for (let i = 0; i < 3; i++) this.tone(400 + Math.random() * 1600, t + i * 0.025, 0.04, "sawtooth", 0.05 * vol, o, 5000); break;
      case "fire": this.noiseHit(t, 0.2, 0.1 * vol, o, "bandpass", 900 * p, 400, 0.7); break;
      case "ice": this.tone(2400 * p, t, 0.12, "sine", 0.05 * vol, o, 8000, 0.002, 3200 * p); this.noiseHit(t, 0.06, 0.06 * vol, o, "highpass", 5000); break;
      case "beam": this.tone(220 * p, t, 0.12, "sawtooth", 0.05 * vol, o, 2200); break;
      case "hurt": this.tone(180, t, 0.2, "square", 0.18 * vol, o, 1200, 0.002, 60); this.noiseHit(t, 0.1, 0.15 * vol, o, "lowpass", 1200); break;
      case "roar": this.tone(90, t, 1.2, "sawtooth", 0.25 * vol, o, 700, 0.05, 40); this.noiseHit(t, 1.1, 0.25 * vol, o, "bandpass", 400, 150, 0.6); break;
      case "bossIntro": this.tone(55, t, 2.2, "sawtooth", 0.25 * vol, o, 400, 0.3); [0, 0.5, 1.0].forEach((d) => this.kick(t + d, o)); break;
      case "chest": [0, 3, 7, 10, 14, 19].forEach((n, i) => this.tone(mtof(76 + n), t + i * 0.05, 0.25, "triangle", 0.08 * vol, o, 7000)); break;
      case "evolve": this.tone(110, t, 1.0, "sawtooth", 0.15 * vol, o, 3000, 0.02, 880); [0, 7, 12, 19, 24].forEach((n, i) => this.tone(mtof(64 + n), t + 0.5 + i * 0.07, 0.6, "square", 0.06 * vol, o, 6000)); break;
      case "click": this.tone(660, t, 0.05, "square", 0.06 * vol, o, 3000); break;
      case "hover": this.tone(990, t, 0.03, "sine", 0.03 * vol, o, 4000); break;
      case "enemyShot": this.tone(500 * p, t, 0.1, "triangle", 0.04 * vol, o, 2000, 0.002, 200); break;
      case "heal": [0, 5, 9].forEach((n, i) => this.tone(mtof(79 + n), t + i * 0.05, 0.2, "sine", 0.07 * vol, o, 6000)); break;
      case "block": this.tone(1800, t, 0.05, "square", 0.05 * vol, o, 6000); this.noiseHit(t, 0.05, 0.08 * vol, o, "highpass", 4000); break;
      case "warn": this.tone(440, t, 0.15, "square", 0.08 * vol, o, 2000); this.tone(440, t + 0.2, 0.15, "square", 0.08 * vol, o, 2000); break;
      case "victory": [0, 4, 7, 12, 7, 12, 16, 19].forEach((n, i) => this.tone(mtof(67 + n), t + i * 0.12, 0.4, "triangle", 0.1 * vol, o, 6000)); break;
      case "defeat": [7, 3, 0, -5].forEach((n, i) => this.tone(mtof(57 + n), t + i * 0.25, 0.5, "triangle", 0.1 * vol, o, 2000)); break;
    }
  }

  dispose() {
    if (this.timer) clearInterval(this.timer);
  }
}

let engine: AudioEngine | null = null;
export function audio(): AudioEngine {
  if (!engine) engine = new AudioEngine();
  return engine;
}
