export interface Poolable {
  alive: boolean;
}

/** Fixed-capacity object pool: objects are recycled instead of garbage collected. */
export class Pool<T extends Poolable> {
  readonly items: T[] = [];
  private free: T[] = [];
  constructor(
    private factory: () => T,
    private max = 4000,
  ) {}
  spawn(): T | null {
    if (this.items.length >= this.max) return null;
    const o = this.free.pop() ?? this.factory();
    o.alive = true;
    this.items.push(o);
    return o;
  }
  /** Remove dead objects (swap-compact) and recycle them. */
  sweep() {
    const it = this.items;
    let j = 0;
    for (let i = 0; i < it.length; i++) {
      const o = it[i];
      if (o.alive) it[j++] = o;
      else this.free.push(o);
    }
    it.length = j;
  }
  clear() {
    for (const o of this.items) {
      o.alive = false;
      this.free.push(o);
    }
    this.items.length = 0;
  }
}
