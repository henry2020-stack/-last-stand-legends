import { BOSSES, type BossId } from "./data/bosses";
import { CHARACTERS, CHAR_IDS, type CharId } from "./data/characters";
import { MAPS, MAP_IDS, type MapId } from "./data/maps";
import type { ChallengeId, DifficultyId, ModeId } from "./data/modes";
import type { ShopId } from "./data/shop";
import { WEAPONS, WEAPON_IDS, type WeaponId } from "./data/weapons";
import { mulberry32 } from "./core/math";

const KEY = "eclipse-survivors-save-v1";

export interface Settings {
  master: number;
  music: number;
  sfx: number;
  shake: boolean;
  damageNumbers: boolean;
  autoAim: boolean;
}

export interface SaveStats {
  totalKills: number;
  runs: number;
  totalTime: number;
  bosses: Partial<Record<BossId, number>>;
  evolutions: number;
  maxLevel: number;
  maxKillsRun: number;
  bestTime: Partial<Record<ModeId, number>>;
  bestScore: Partial<Record<ModeId, number>>;
  mapBest: Partial<Record<MapId, number>>;
  wins: Record<string, number>;
}

export interface SaveData {
  coins: number;
  chars: CharId[];
  weapons: WeaponId[];
  shop: Partial<Record<ShopId, number>>;
  achievements: string[];
  stats: SaveStats;
  daily: { date: string; done: string[] };
  settings: Settings;
  last: { char: CharId; map: MapId; mode: ModeId; difficulty: DifficultyId; challenge: ChallengeId };
}

export interface RunResult {
  mode: ModeId;
  map: MapId;
  char: CharId;
  difficulty: DifficultyId;
  challenge: ChallengeId | null;
  time: number;
  kills: number;
  level: number;
  coins: number;
  bossesKilled: BossId[];
  evolutions: number;
  won: boolean;
  score: number;
  weaponDmg: { id: string; name: string; dmg: number; color: string }[];
}

export function defaultSave(): SaveData {
  return {
    coins: 0,
    chars: ["kael"],
    weapons: WEAPON_IDS.filter((w) => WEAPONS[w].cost === 0),
    shop: {},
    achievements: [],
    stats: { totalKills: 0, runs: 0, totalTime: 0, bosses: {}, evolutions: 0, maxLevel: 0, maxKillsRun: 0, bestTime: {}, bestScore: {}, mapBest: {}, wins: {} },
    daily: { date: "", done: [] },
    settings: { master: 0.8, music: 0.55, sfx: 0.8, shake: true, damageNumbers: true, autoAim: false },
    last: { char: "kael", map: "forest", mode: "classic", difficulty: "normal", challenge: "glass" },
  };
}

export function loadSave(): SaveData {
  const d = defaultSave();
  try {
    const raw = typeof localStorage !== "undefined" ? localStorage.getItem(KEY) : null;
    if (!raw) return d;
    const p = JSON.parse(raw) as Partial<SaveData>;
    return {
      ...d,
      ...p,
      stats: { ...d.stats, ...(p.stats ?? {}) },
      settings: { ...d.settings, ...(p.settings ?? {}) },
      last: { ...d.last, ...(p.last ?? {}) },
      daily: { ...d.daily, ...(p.daily ?? {}) },
      chars: Array.from(new Set([...(p.chars ?? []), "kael" as CharId])).filter((c) => c in CHARACTERS),
      weapons: Array.from(new Set([...d.weapons, ...(p.weapons ?? [])])).filter((w) => w in WEAPONS),
    };
  } catch {
    return d;
  }
}

export function persist(s: SaveData) {
  try {
    localStorage.setItem(KEY, JSON.stringify(s));
  } catch {
    /* storage full or unavailable */
  }
}

export function isMapUnlocked(s: SaveData, id: MapId) {
  const req = MAPS[id].unlockAfter;
  if (!req) return true;
  return (s.stats.mapBest[req] ?? 0) >= 300;
}

// ---------------- Achievements ----------------
export interface AchievementDef {
  id: string;
  name: string;
  desc: string;
  reward: number;
  check: (s: SaveData, r: RunResult | null) => boolean;
}

const bossAch = (id: BossId): AchievementDef => ({
  id: `boss_${id}`, name: `Slayer of ${BOSSES[id].name.replace("The ", "")}`, desc: `Defeat ${BOSSES[id].name}.`, reward: 300,
  check: (s) => (s.stats.bosses[id] ?? 0) > 0,
});

export const ACHIEVEMENTS: AchievementDef[] = [
  { id: "kills_100", name: "First Blood", desc: "Defeat 100 monsters in total.", reward: 50, check: (s) => s.stats.totalKills >= 100 },
  { id: "kills_5k", name: "Exterminator", desc: "Defeat 5,000 monsters in total.", reward: 300, check: (s) => s.stats.totalKills >= 5000 },
  { id: "kills_25k", name: "Living Legend", desc: "Defeat 25,000 monsters in total.", reward: 1000, check: (s) => s.stats.totalKills >= 25000 },
  { id: "run_1000", name: "One-Person Army", desc: "Defeat 1,000 monsters in one run.", reward: 250, check: (_s, r) => !!r && r.kills >= 1000 },
  { id: "survive_5", name: "Still Standing", desc: "Survive 5 minutes in a run.", reward: 100, check: (_s, r) => !!r && r.time >= 300 },
  { id: "survive_10", name: "Hardened", desc: "Survive 10 minutes in a run.", reward: 250, check: (_s, r) => !!r && r.time >= 600 },
  { id: "win_classic", name: "Eclipse Breaker", desc: "Win a Classic Survival run.", reward: 800, check: (s) => (s.stats.wins["classic"] ?? 0) > 0 },
  { id: "win_nightmare", name: "Nightmare Walker", desc: "Win Classic Survival on Nightmare.", reward: 2500, check: (s) => (s.stats.wins["classic_nightmare"] ?? 0) > 0 },
  { id: "win_bossrush", name: "Gauntlet Champion", desc: "Complete Boss Rush.", reward: 1000, check: (s) => (s.stats.wins["bossrush"] ?? 0) > 0 },
  { id: "win_challenge", name: "Rule Breaker", desc: "Complete any Challenge.", reward: 400, check: (s) => Object.keys(s.stats.wins).some((k) => k.startsWith("challenge_")) },
  { id: "endless_20", name: "Eternal", desc: "Survive 20 minutes in Endless.", reward: 1200, check: (_s, r) => !!r && r.mode === "endless" && r.time >= 1200 },
  { id: "evolve_1", name: "Evolution", desc: "Evolve a weapon.", reward: 150, check: (s) => s.stats.evolutions >= 1 },
  { id: "evolve_3", name: "Arsenal of Gods", desc: "Evolve 3 weapons in one run.", reward: 600, check: (_s, r) => !!r && r.evolutions >= 3 },
  { id: "level_30", name: "Ascended", desc: "Reach level 30 in a run.", reward: 300, check: (s) => s.stats.maxLevel >= 30 },
  { id: "rich", name: "Treasure Hoarder", desc: "Hold 5,000 coins at once.", reward: 250, check: (s) => s.coins >= 5000 },
  { id: "all_maps", name: "Worldwalker", desc: "Unlock every arena.", reward: 500, check: (s) => MAP_IDS.every((m) => isMapUnlocked(s, m)) },
  { id: "all_chars", name: "Full Roster", desc: "Unlock every character.", reward: 1500, check: (s) => CHAR_IDS.every((c) => s.chars.includes(c)) },
  bossAch("plague_queen"), bossAch("infernal_beast"), bossAch("bone_king"), bossAch("destroyer"), bossAch("void_titan"),
];

// ---------------- Daily challenges ----------------
export interface DailyDef { id: string; text: string; reward: number; check: (r: RunResult) => boolean }

export function todayKey(d = new Date()) {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

export function getDailies(date: string): DailyDef[] {
  let seed = 0;
  for (const ch of date) seed = (seed * 31 + ch.charCodeAt(0)) | 0;
  const rng = mulberry32(seed);
  const pickN = <T,>(a: T[]) => a[Math.floor(rng() * a.length)]!;
  const templates: (() => DailyDef)[] = [
    () => { const n = pickN([300, 500, 800]); return { id: `kills${n}`, text: `Defeat ${n} monsters in one run`, reward: Math.round(n / 3), check: (r) => r.kills >= n }; },
    () => { const m = pickN(MAP_IDS.slice(0, 3)); const min = pickN([4, 6]); return { id: `map_${m}_${min}`, text: `Survive ${min} minutes in ${MAPS[m].name}`, reward: 150 + min * 25, check: (r) => r.map === m && r.time >= min * 60 }; },
    () => { const l = pickN([15, 20, 25]); return { id: `lvl${l}`, text: `Reach level ${l}`, reward: l * 10, check: (r) => r.level >= l }; },
    () => ({ id: "evolve", text: "Evolve a weapon", reward: 250, check: (r) => r.evolutions >= 1 }),
    () => ({ id: "boss", text: "Defeat any boss", reward: 220, check: (r) => r.bossesKilled.length >= 1 }),
    () => { const d = pickN(["hard", "nightmare"] as DifficultyId[]); return { id: `diff_${d}`, text: `Survive 3 minutes on ${d === "hard" ? "Hard" : "Nightmare"}`, reward: d === "hard" ? 200 : 350, check: (r) => (r.difficulty === d || (d === "hard" && r.difficulty === "nightmare")) && r.time >= 180 }; },
    () => ({ id: "rush2", text: "Defeat 2 bosses in Boss Rush", reward: 300, check: (r) => r.mode === "bossrush" && r.bossesKilled.length >= 2 }),
  ];
  const idx = templates.map((_, i) => i);
  const out: DailyDef[] = [];
  while (out.length < 3 && idx.length) {
    const i = Math.floor(rng() * idx.length);
    out.push(templates[idx[i]!]!());
    idx.splice(i, 1);
  }
  return out;
}

export interface RunSummary {
  coinsEarned: number;
  bonusCoins: number;
  newAchievements: AchievementDef[];
  dailies: DailyDef[];
  newBestTime: boolean;
  newBestScore: boolean;
  mapUnlocked: MapId | null;
}

/** Apply a finished run to the save. Pure: returns a new save and a summary. */
export function applyRunResult(prev: SaveData, r: RunResult): { save: SaveData; summary: RunSummary } {
  const s: SaveData = structuredClone(prev);
  const st = s.stats;
  const mapsBefore = MAP_IDS.filter((m) => isMapUnlocked(prev, m));
  st.totalKills += r.kills;
  st.runs += 1;
  st.totalTime += r.time;
  st.evolutions += r.evolutions;
  st.maxLevel = Math.max(st.maxLevel, r.level);
  st.maxKillsRun = Math.max(st.maxKillsRun, r.kills);
  for (const b of r.bossesKilled) st.bosses[b] = (st.bosses[b] ?? 0) + 1;
  const newBestTime = r.time > (st.bestTime[r.mode] ?? 0);
  const newBestScore = r.score > (st.bestScore[r.mode] ?? 0);
  if (newBestTime) st.bestTime[r.mode] = r.time;
  if (newBestScore) st.bestScore[r.mode] = r.score;
  st.mapBest[r.map] = Math.max(st.mapBest[r.map] ?? 0, r.time);

  let bonus = 0;
  if (r.won) {
    const key = r.mode === "challenge" ? `challenge_${r.challenge}` : r.mode;
    st.wins[key] = (st.wins[key] ?? 0) + 1;
    if (r.mode === "classic") st.wins[`classic_${r.difficulty}`] = (st.wins[`classic_${r.difficulty}`] ?? 0) + 1;
    bonus += r.mode === "bossrush" ? 800 : r.mode === "classic" ? 600 : 400;
  }
  s.coins += r.coins + bonus;

  // dailies
  const today = todayKey();
  if (s.daily.date !== today) s.daily = { date: today, done: [] };
  const dailies: DailyDef[] = [];
  for (const d of getDailies(today)) {
    if (!s.daily.done.includes(d.id) && d.check(r)) {
      s.daily.done.push(d.id);
      s.coins += d.reward;
      dailies.push(d);
    }
  }
  // achievements
  const newAchievements: AchievementDef[] = [];
  for (const a of ACHIEVEMENTS) {
    if (!s.achievements.includes(a.id) && a.check(s, r)) {
      s.achievements.push(a.id);
      s.coins += a.reward;
      newAchievements.push(a);
    }
  }
  const mapUnlocked = MAP_IDS.find((m) => !mapsBefore.includes(m) && isMapUnlocked(s, m)) ?? null;
  return { save: s, summary: { coinsEarned: r.coins, bonusCoins: bonus, newAchievements, dailies, newBestTime, newBestScore, mapUnlocked } };
}

/** Check achievements that can unlock from menu actions (purchases). */
export function checkMenuAchievements(prev: SaveData): { save: SaveData; unlocked: AchievementDef[] } {
  const s = structuredClone(prev);
  const unlocked: AchievementDef[] = [];
  for (const a of ACHIEVEMENTS) {
    if (!s.achievements.includes(a.id) && a.check(s, null)) {
      s.achievements.push(a.id);
      s.coins += a.reward;
      unlocked.push(a);
    }
  }
  return { save: s, unlocked };
}
