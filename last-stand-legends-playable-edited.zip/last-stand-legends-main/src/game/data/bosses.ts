import type { DamageType } from "./common";

export type BossId = "plague_queen" | "infernal_beast" | "bone_king" | "destroyer" | "void_titan";
export type AttackId =
  | "radial" | "spiral" | "volley" | "charge" | "slam" | "summon" | "laser"
  | "puddles" | "teleport" | "meteors" | "ring" | "gravity";

export interface BossDef {
  id: BossId;
  name: string;
  title: string;
  hp: number;
  speed: number;
  dmg: number;
  r: number;
  color: string;
  color2: string;
  proj: "poison" | "fire" | "bone" | "missile" | "void";
  phases: AttackId[][];
  resist?: Partial<Record<DamageType, number>>;
}

export const BOSSES: Record<BossId, BossDef> = {
  plague_queen: {
    id: "plague_queen", name: "The Plague Queen", title: "Mother of the Rotting Swarm",
    hp: 3800, speed: 70, dmg: 20, r: 54, color: "#7dff4a", color2: "#3a1a4a", proj: "poison",
    phases: [["volley", "summon", "puddles"], ["volley", "spiral", "charge", "puddles"], ["spiral", "radial", "charge", "summon", "puddles", "ring"]],
    resist: { poison: 0.3 },
  },
  infernal_beast: {
    id: "infernal_beast", name: "The Infernal Beast", title: "Heart of the Molten Wastes",
    hp: 4600, speed: 80, dmg: 26, r: 60, color: "#ff5a1a", color2: "#3a0a06", proj: "fire",
    phases: [["charge", "slam", "volley"], ["charge", "radial", "meteors", "slam"], ["charge", "spiral", "meteors", "radial", "ring"]],
    resist: { fire: 0.3 },
  },
  bone_king: {
    id: "bone_king", name: "The Bone King", title: "Frozen Lord of the Dead",
    hp: 4300, speed: 62, dmg: 22, r: 52, color: "#e8f4ff", color2: "#4ab8ff", proj: "bone",
    phases: [["radial", "summon", "volley"], ["ring", "teleport", "volley", "radial"], ["spiral", "slam", "ring", "teleport", "summon"]],
    resist: { ice: 0.3 },
  },
  destroyer: {
    id: "destroyer", name: "The Ancient Destroyer", title: "War Engine of the Fallen City",
    hp: 5200, speed: 58, dmg: 24, r: 62, color: "#c8c0a8", color2: "#ff3a2a", proj: "missile",
    phases: [["volley", "laser", "slam"], ["laser", "spiral", "slam", "volley"], ["laser", "radial", "summon", "meteors", "spiral"]],
    resist: { physical: 0.75 },
  },
  void_titan: {
    id: "void_titan", name: "The Void Titan", title: "Devourer Beyond the Stars",
    hp: 6200, speed: 55, dmg: 28, r: 70, color: "#b05aff", color2: "#0a0414", proj: "void",
    phases: [["laser", "radial", "teleport"], ["gravity", "spiral", "laser", "teleport"], ["ring", "gravity", "laser", "spiral", "summon"]],
    resist: { shadow: 0.3, arcane: 0.6 },
  },
};

export const BOSS_IDS = Object.keys(BOSSES) as BossId[];
