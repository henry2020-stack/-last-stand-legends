export type ShopId =
  | "might" | "vitality" | "armor" | "swift" | "magnet" | "greed"
  | "growth" | "recovery" | "haste" | "crit" | "reroll" | "revival";

export interface ShopDef { id: ShopId; name: string; desc: string; max: number; base: number }

export const SHOP: Record<ShopId, ShopDef> = {
  might: { id: "might", name: "Might", desc: "+5% damage per rank", max: 5, base: 120 },
  vitality: { id: "vitality", name: "Vitality", desc: "+10 max health per rank", max: 5, base: 100 },
  armor: { id: "armor", name: "Armor", desc: "+1 armor per rank", max: 3, base: 220 },
  swift: { id: "swift", name: "Swiftness", desc: "+4% move speed per rank", max: 5, base: 110 },
  magnet: { id: "magnet", name: "Magnet", desc: "+15% pickup range per rank", max: 4, base: 90 },
  greed: { id: "greed", name: "Greed", desc: "+10% coins per rank", max: 5, base: 150 },
  growth: { id: "growth", name: "Growth", desc: "+6% XP per rank", max: 5, base: 130 },
  recovery: { id: "recovery", name: "Recovery", desc: "+0.2 HP/s per rank", max: 3, base: 180 },
  haste: { id: "haste", name: "Haste", desc: "-3% cooldowns per rank", max: 5, base: 160 },
  crit: { id: "crit", name: "Precision", desc: "+3% crit chance per rank", max: 3, base: 200 },
  reroll: { id: "reroll", name: "Reroll", desc: "+1 level-up reroll per run", max: 3, base: 250 },
  revival: { id: "revival", name: "Revival", desc: "Revive once per run at 50% health", max: 1, base: 1500 },
};

export const SHOP_IDS = Object.keys(SHOP) as ShopId[];

export function shopCost(id: ShopId, rank: number) {
  return Math.round(SHOP[id].base * Math.pow(rank + 1, 1.35));
}
