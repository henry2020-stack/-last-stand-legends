export type DamageType = "physical" | "fire" | "ice" | "lightning" | "poison" | "shadow" | "arcane";

export const DAMAGE_COLORS: Record<DamageType, string> = {
  physical: "#f4f1ea",
  fire: "#ffb347",
  ice: "#9be7ff",
  lightning: "#fff27a",
  poison: "#9dff6a",
  shadow: "#d59bff",
  arcane: "#ff8fe4",
};
