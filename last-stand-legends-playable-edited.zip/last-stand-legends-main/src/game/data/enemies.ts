import type { DamageType } from "./common";

export type EnemyId =
  | "zombie" | "brute" | "slime" | "stalker" | "exploder" | "bat" | "knight" | "demon"
  | "icemonster" | "bug" | "spider" | "mage" | "phantom" | "hunter" | "guardian";

export interface EnemyDef {
  id: EnemyId;
  name: string;
  desc: string;
  hp: number;
  speed: number;
  dmg: number;
  r: number;
  xp: number;
  mass: number; // knockback resistance
  color: string;
  color2: string;
  coin: number; // coin drop chance
  resist?: Partial<Record<DamageType, number>>; // damage multiplier, e.g. 0.5 = half damage
}

export const ENEMIES: Record<EnemyId, EnemyDef> = {
  zombie: { id: "zombie", name: "Zombie Runner", desc: "Fast but fragile. Comes in numbers.", hp: 12, speed: 92, dmg: 8, r: 14, xp: 1, mass: 1, color: "#6f8f5a", color2: "#3f5536", coin: 0.03 },
  brute: { id: "brute", name: "Giant Brute", desc: "Slow and enormous. Telegraphed ground slams.", hp: 130, speed: 48, dmg: 22, r: 30, xp: 9, mass: 5, color: "#8f3a3a", color2: "#4e1d24", coin: 0.25 },
  slime: { id: "slime", name: "Toxic Slime", desc: "Leaves acid puddles and splits on death.", hp: 30, speed: 55, dmg: 10, r: 18, xp: 3, mass: 1.5, color: "#7dff4a", color2: "#2c9a3a", coin: 0.06, resist: { poison: 0.4 } },
  stalker: { id: "stalker", name: "Shadow Stalker", desc: "Blinks toward you after a shimmer.", hp: 34, speed: 82, dmg: 14, r: 15, xp: 4, mass: 1.2, color: "#4b2a7a", color2: "#1a0e2e", coin: 0.08, resist: { shadow: 0.4 } },
  exploder: { id: "exploder", name: "Exploder", desc: "Detonates near you or when killed. Hurts other monsters too.", hp: 20, speed: 108, dmg: 28, r: 15, xp: 3, mass: 1, color: "#ff8a2a", color2: "#a33a12", coin: 0.06 },
  bat: { id: "bat", name: "Flying Bat", desc: "Erratic flier, hard to predict.", hp: 8, speed: 150, dmg: 6, r: 10, xp: 1, mass: 0.6, color: "#5a4a6a", color2: "#2a1f33", coin: 0.03 },
  knight: { id: "knight", name: "Armored Knight", desc: "Shield blocks 80% of frontal projectiles. Flank it!", hp: 75, speed: 62, dmg: 15, r: 20, xp: 6, mass: 3, color: "#a8b3c4", color2: "#4b5566", coin: 0.15 },
  demon: { id: "demon", name: "Fire Demon", desc: "Keeps its distance and hurls fireballs.", hp: 42, speed: 76, dmg: 12, r: 17, xp: 5, mass: 1.3, color: "#ff4a2a", color2: "#7a1410", coin: 0.1, resist: { fire: 0.3 } },
  icemonster: { id: "icemonster", name: "Ice Monster", desc: "Freezing aura slows you. Fires frost shards.", hp: 58, speed: 58, dmg: 12, r: 20, xp: 5, mass: 2.5, color: "#9be7ff", color2: "#3a7fb8", coin: 0.1, resist: { ice: 0.3 } },
  bug: { id: "bug", name: "Swarm Bug", desc: "Tiny, weak, and never alone.", hp: 5, speed: 128, dmg: 4, r: 8, xp: 1, mass: 0.5, color: "#d6b24a", color2: "#6a4a1a", coin: 0.015 },
  spider: { id: "spider", name: "Poison Spider", desc: "Spits venom that pools on the ground.", hp: 30, speed: 92, dmg: 10, r: 16, xp: 4, mass: 1.2, color: "#6a3a8a", color2: "#9dff6a", coin: 0.08, resist: { poison: 0.4 } },
  mage: { id: "mage", name: "Dark Mage", desc: "Summons minions from afar. Priority target!", hp: 45, speed: 55, dmg: 10, r: 17, xp: 8, mass: 1.2, color: "#3a2a5a", color2: "#ff5ad0", coin: 0.2, resist: { arcane: 0.5 } },
  phantom: { id: "phantom", name: "Phantom", desc: "Briefly turns intangible and invulnerable.", hp: 40, speed: 86, dmg: 12, r: 16, xp: 5, mass: 0.8, color: "#e6f0ff", color2: "#8aa6d6", coin: 0.1 },
  hunter: { id: "hunter", name: "Elite Hunter", desc: "Predicts your movement and lunges. Dodge the dash!", hp: 95, speed: 118, dmg: 18, r: 17, xp: 12, mass: 2, color: "#d62a3a", color2: "#1a0a0e", coin: 0.4 },
  guardian: { id: "guardian", name: "Ancient Guardian", desc: "Colossal stone sentinel. Drops a treasure chest.", hp: 1300, speed: 38, dmg: 28, r: 44, xp: 90, mass: 20, color: "#8a8270", color2: "#5affd6", coin: 1 },
};

export const ENEMY_IDS = Object.keys(ENEMIES) as EnemyId[];
