import type { DamageType } from "./common";
import type { PassiveId } from "./passives";

export type WeaponId =
  | "plasma" | "lightning" | "nova" | "daggers" | "ice" | "meteor"
  | "poison" | "beam" | "missiles" | "mines" | "boomerang" | "dragon";

export interface WeaponLevel {
  dmg: number;
  cd: number;
  count: number;
  area: number;
  speed: number;
  pierce: number;
  dur: number;
}

export interface WeaponDef {
  id: WeaponId;
  name: string;
  evoName: string;
  evoPassive: PassiveId;
  dtype: DamageType;
  color: string;
  color2: string;
  desc: string;
  evoDesc: string;
  levelDesc: string[]; // descriptions for reaching level 2..5
  levels: WeaponLevel[]; // 5 levels
  evo: WeaponLevel;
  cost: number; // coin cost to unlock in collection (0 = unlocked)
}

const L = (dmg: number, cd: number, count: number, area: number, speed: number, pierce: number, dur: number): WeaponLevel => ({ dmg, cd, count, area, speed, pierce, dur });

export const MAX_WEAPON_LEVEL = 5;

export const WEAPONS: Record<WeaponId, WeaponDef> = {
  plasma: {
    id: "plasma", name: "Plasma Blades", evoName: "Galaxy Edge", evoPassive: "area", dtype: "physical",
    color: "#59f3ff", color2: "#2a7bff", cost: 0,
    desc: "Energy blades orbit you, slicing anything they touch.",
    evoDesc: "Twin counter-rotating rings of starlight blades.",
    levelDesc: ["+1 blade", "+40% damage", "+1 blade, +15% radius", "+1 blade, +40% damage"],
    levels: [L(10, 0, 2, 1, 3, 99, 0), L(10, 0, 3, 1, 3, 99, 0), L(14, 0, 3, 1, 3.3, 99, 0), L(14, 0, 4, 1.15, 3.5, 99, 0), L(20, 0, 5, 1.15, 3.8, 99, 0)],
    evo: L(30, 0, 7, 1.45, 4.6, 99, 0),
  },
  lightning: {
    id: "lightning", name: "Lightning Orb", evoName: "Thunderstorm", evoPassive: "haste", dtype: "lightning",
    color: "#fff27a", color2: "#7ab8ff", cost: 0,
    desc: "Launches crackling orbs that zap nearby enemies.",
    evoDesc: "Orbs plus a raging storm of sky-bolts that chain between foes.",
    levelDesc: ["+35% damage", "+1 orb", "Faster, zaps 3 targets", "+1 orb, +50% damage"],
    levels: [L(12, 2.2, 1, 1, 150, 2, 3), L(16, 2.2, 1, 1, 150, 2, 3), L(16, 2.2, 2, 1, 150, 2, 3), L(17, 1.8, 2, 1.1, 160, 3, 3.2), L(25, 1.8, 3, 1.1, 160, 3, 3.4)],
    evo: L(32, 1.5, 3, 1.25, 170, 4, 3.6),
  },
  nova: {
    id: "nova", name: "Fire Nova", evoName: "Inferno", evoPassive: "might", dtype: "fire",
    color: "#ff8a3d", color2: "#ff3d2e", cost: 0,
    desc: "Erupts a ring of fire that blasts enemies away.",
    evoDesc: "Double infernal waves that leave the ground burning.",
    levelDesc: ["+35% damage", "+20% radius", "Faster pulses", "+60% damage, +15% radius"],
    levels: [L(15, 3, 1, 1, 460, 0, 0), L(20, 3, 1, 1, 460, 0, 0), L(20, 3, 1, 1.2, 480, 0, 0), L(22, 2.4, 1, 1.2, 500, 0, 0), L(32, 2.4, 1, 1.38, 520, 0, 0)],
    evo: L(46, 1.8, 2, 1.6, 560, 0, 0),
  },
  daggers: {
    id: "daggers", name: "Shadow Daggers", evoName: "Void Blades", evoPassive: "precision", dtype: "shadow",
    color: "#c27bff", color2: "#5a1fbf", cost: 0,
    desc: "Throws a fan of daggers toward your aim.",
    evoDesc: "Endlessly piercing blades that return. Crits tear open void rifts.",
    levelDesc: ["+1 dagger", "+35% damage", "Faster, +1 pierce", "+2 daggers, +35% damage"],
    levels: [L(8, 0.8, 2, 1, 720, 1, 0.9), L(8, 0.8, 3, 1, 720, 1, 0.9), L(11, 0.8, 3, 1, 740, 1, 0.9), L(11, 0.6, 3, 1, 760, 2, 0.9), L(15, 0.6, 5, 1, 780, 2, 0.9)],
    evo: L(22, 0.45, 6, 1.2, 820, 99, 0.55),
  },
  ice: {
    id: "ice", name: "Ice Storm", evoName: "Absolute Zero", evoPassive: "armor", dtype: "ice",
    color: "#9be7ff", color2: "#3fa9ff", cost: 0,
    desc: "Bursts of ice shards in every direction. Slows enemies.",
    evoDesc: "Spiraling shard waves that freeze solid, with a chilling aura.",
    levelDesc: ["+2 shards", "+45% damage", "+2 shards, faster", "+40% damage, +1 pierce"],
    levels: [L(9, 2, 8, 1, 380, 2, 0.9), L(9, 2, 10, 1, 380, 2, 0.9), L(13, 2, 10, 1, 390, 2, 0.9), L(13, 1.6, 12, 1.1, 400, 2, 1), L(18, 1.6, 12, 1.1, 410, 3, 1)],
    evo: L(26, 1.3, 16, 1.25, 430, 4, 1.1),
  },
  meteor: {
    id: "meteor", name: "Meteor Strike", evoName: "Armageddon", evoPassive: "wisdom", dtype: "fire",
    color: "#ff6a2a", color2: "#ffd04a", cost: 350,
    desc: "Calls meteors down on enemy clusters.",
    evoDesc: "A relentless meteor shower that leaves molten craters.",
    levelDesc: ["+1 meteor", "+40% damage", "+1 meteor, +25% blast", "Faster, +35% damage"],
    levels: [L(40, 3.5, 1, 1, 0, 0, 0.8), L(40, 3.5, 2, 1, 0, 0, 0.8), L(56, 3.5, 2, 1, 0, 0, 0.8), L(56, 3.5, 3, 1.25, 0, 0, 0.8), L(75, 2.8, 3, 1.25, 0, 0, 0.75)],
    evo: L(110, 2.1, 6, 1.4, 0, 0, 0.7),
  },
  poison: {
    id: "poison", name: "Poison Cloud", evoName: "Plague Miasma", evoPassive: "recovery", dtype: "poison",
    color: "#9dff6a", color2: "#2fae4a", cost: 300,
    desc: "Spawns lingering toxic clouds on enemies.",
    evoDesc: "A huge plague aura follows you; poisoned kills heal you.",
    levelDesc: ["+35% damage", "+1 cloud", "+30% size, longer", "+1 cloud, +50% damage"],
    levels: [L(6, 3, 1, 1, 0, 0, 4), L(8, 3, 1, 1, 0, 0, 4), L(8, 3, 2, 1, 0, 0, 4), L(9, 3, 2, 1.3, 0, 0, 5), L(13, 3, 3, 1.3, 0, 0, 5)],
    evo: L(18, 2.4, 3, 1.5, 0, 0, 6),
  },
  beam: {
    id: "beam", name: "Energy Beam", evoName: "Prism Lance", evoPassive: "multishot", dtype: "arcane",
    color: "#ff6bd6", color2: "#ffd1f3", cost: 450,
    desc: "Fires a sustained laser toward your aim. Skill-shot weapon.",
    evoDesc: "Three massive prismatic beams.",
    levelDesc: ["Longer beam", "+50% damage", "Faster, +30% width", "+45% damage, longer"],
    levels: [L(6, 3, 1, 1, 0, 0, 1.2), L(6, 3, 1, 1, 0, 0, 1.5), L(9, 3, 1, 1, 0, 0, 1.5), L(9, 2.4, 1, 1.3, 0, 0, 1.6), L(13, 2.4, 1, 1.3, 0, 0, 2)],
    evo: L(18, 2, 3, 1.8, 0, 0, 2.5),
  },
  missiles: {
    id: "missiles", name: "Magic Missiles", evoName: "Starfall", evoPassive: "magnet", dtype: "arcane",
    color: "#7ad7ff", color2: "#b48cff", cost: 0,
    desc: "Homing arcane missiles seek out enemies.",
    evoDesc: "A swarm of star missiles that explode on impact.",
    levelDesc: ["+1 missile", "+35% damage", "Faster, +1 missile", "+1 missile, +35% damage"],
    levels: [L(14, 1.4, 2, 1, 420, 0, 2.5), L(14, 1.4, 3, 1, 420, 0, 2.5), L(19, 1.4, 3, 1, 440, 0, 2.5), L(19, 1.1, 4, 1, 460, 0, 2.5), L(26, 1.1, 5, 1, 480, 0, 2.5)],
    evo: L(32, 0.9, 8, 1.2, 520, 0, 2.6),
  },
  mines: {
    id: "mines", name: "Explosive Mines", evoName: "Cluster Nukes", evoPassive: "reflexes", dtype: "fire",
    color: "#ffcf3a", color2: "#ff5a2a", cost: 400,
    desc: "Drops proximity mines behind you. Lure enemies in.",
    evoDesc: "Huge blasts that scatter cluster bomblets.",
    levelDesc: ["+35% damage", "+1 mine", "Faster, +30% blast", "+1 mine, +40% damage"],
    levels: [L(45, 2, 1, 1, 0, 0, 14), L(60, 2, 1, 1, 0, 0, 14), L(60, 2, 2, 1, 0, 0, 14), L(62, 1.6, 2, 1.3, 0, 0, 14), L(85, 1.6, 3, 1.3, 0, 0, 14)],
    evo: L(130, 1.4, 3, 1.6, 0, 0, 16),
  },
  boomerang: {
    id: "boomerang", name: "Boomerang Blades", evoName: "Twin Cyclones", evoPassive: "swift", dtype: "physical",
    color: "#ffe08a", color2: "#ff9d2a", cost: 0,
    desc: "Spinning blades fly out toward your aim and return.",
    evoDesc: "Cyclones that linger, drag enemies in and shred them.",
    levelDesc: ["+30% damage", "+1 blade", "Faster, +30% size", "+1 blade, +40% damage"],
    levels: [L(16, 1.6, 1, 1, 540, 99, 4), L(21, 1.6, 1, 1, 540, 99, 4), L(21, 1.6, 2, 1, 560, 99, 4), L(22, 1.3, 2, 1.3, 580, 99, 4), L(30, 1.3, 3, 1.3, 600, 99, 4)],
    evo: L(40, 1.2, 4, 1.7, 420, 99, 5),
  },
  dragon: {
    id: "dragon", name: "Dragon Breath", evoName: "Ancient Dragonfire", evoPassive: "vitality", dtype: "fire",
    color: "#ff7a1a", color2: "#ffe14a", cost: 550,
    desc: "Breathe a cone of fire toward your aim. Sets enemies ablaze.",
    evoDesc: "A colossal firestorm; burning enemies explode on death.",
    levelDesc: ["+40% damage", "Longer breath", "+30% cone, faster", "+55% damage"],
    levels: [L(5, 2.5, 1, 1, 360, 2, 1.4), L(7, 2.5, 1, 1, 360, 2, 1.4), L(7, 2.5, 1, 1, 370, 2, 1.8), L(7, 2, 1, 1.3, 390, 2, 1.8), L(11, 2, 1, 1.3, 400, 3, 2)],
    evo: L(16, 1.6, 1, 1.7, 480, 4, 2.6),
  },
};

export const WEAPON_IDS = Object.keys(WEAPONS) as WeaponId[];
