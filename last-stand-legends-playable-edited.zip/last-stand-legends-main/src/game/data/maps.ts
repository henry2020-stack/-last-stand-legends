import type { BossId } from "./bosses";
import type { EnemyId } from "./enemies";

export type MapId = "forest" | "lava" | "frozen" | "city" | "void";
export type HazardKind = "thorns" | "eruptions" | "ice" | "blackout" | "rifts";
export type AmbientKind = "fireflies" | "embers" | "snow" | "rain" | "motes";

export interface MapDef {
  id: MapId;
  name: string;
  desc: string;
  challenge: string;
  boss: BossId;
  enemies: EnemyId[]; // ordered by unlock time
  hazard: HazardKind;
  ambient: AmbientKind;
  ground: string;
  ground2: string;
  detail: string;
  accent: string;
  fog: string; // vignette color (rgba)
  musicRoot: number; // midi root note
  unlockAfter: MapId | null; // survive 5:00 on this map to unlock
}

export const MAPS: Record<MapId, MapDef> = {
  forest: {
    id: "forest", name: "Cursed Forest", desc: "Moss, mushrooms and whispering fog.",
    challenge: "Thorn thickets slow and cut you.", boss: "plague_queen",
    enemies: ["zombie", "bat", "slime", "bug", "spider", "exploder", "knight", "mage", "phantom", "hunter"],
    hazard: "thorns", ambient: "fireflies",
    ground: "#1b2a1c", ground2: "#223522", detail: "#2f4a2a", accent: "#b6ff6a", fog: "rgba(6,18,10,", musicRoot: 45, unlockAfter: null,
  },
  lava: {
    id: "lava", name: "Lava Wasteland", desc: "Cracked obsidian over rivers of fire.",
    challenge: "The ground erupts beneath you.", boss: "infernal_beast",
    enemies: ["zombie", "demon", "bat", "exploder", "brute", "stalker", "knight", "mage", "hunter"],
    hazard: "eruptions", ambient: "embers",
    ground: "#1e1210", ground2: "#2a1612", detail: "#3a1d14", accent: "#ff6a2a", fog: "rgba(30,6,2,", musicRoot: 43, unlockAfter: "forest",
  },
  frozen: {
    id: "frozen", name: "Frozen Kingdom", desc: "A dead empire under endless snow.",
    challenge: "Ice patches make you slide.", boss: "bone_king",
    enemies: ["zombie", "bat", "icemonster", "bug", "knight", "phantom", "brute", "mage", "hunter"],
    hazard: "ice", ambient: "snow",
    ground: "#1a2433", ground2: "#22304a", detail: "#3a5478", accent: "#9be7ff", fog: "rgba(8,14,30,", musicRoot: 47, unlockAfter: "lava",
  },
  city: {
    id: "city", name: "Abandoned City", desc: "Rain-soaked ruins of a fallen metropolis.",
    challenge: "Blackouts plunge the city into darkness.", boss: "destroyer",
    enemies: ["zombie", "bug", "exploder", "stalker", "spider", "knight", "demon", "brute", "mage", "hunter"],
    hazard: "blackout", ambient: "rain",
    ground: "#1a1c22", ground2: "#22252d", detail: "#353a46", accent: "#ffd84a", fog: "rgba(6,8,12,", musicRoot: 40, unlockAfter: "frozen",
  },
  void: {
    id: "void", name: "Dark Dimension", desc: "Reality frays at the edge of the universe.",
    challenge: "Gravity rifts drag you toward the abyss.", boss: "void_titan",
    enemies: ["stalker", "bat", "phantom", "bug", "slime", "icemonster", "demon", "mage", "brute", "hunter"],
    hazard: "rifts", ambient: "motes",
    ground: "#120a1e", ground2: "#1a0e2c", detail: "#2e1a4a", accent: "#c27bff", fog: "rgba(10,2,20,", musicRoot: 42, unlockAfter: "city",
  },
};

export const MAP_IDS = Object.keys(MAPS) as MapId[];
