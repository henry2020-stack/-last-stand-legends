export type ModeId = "classic" | "endless" | "bossrush" | "challenge";
export type DifficultyId = "easy" | "normal" | "hard" | "nightmare";
export type ChallengeId = "glass" | "swarm" | "frenzy" | "cursed";

export interface ModeDef { id: ModeId; name: string; desc: string; goal: string }
export interface DifficultyDef { id: DifficultyId; name: string; hp: number; dmg: number; coin: number; desc: string }
export interface ChallengeDef {
  id: ChallengeId; name: string; desc: string; reward: number;
  hpMul: number; dmgMul: number; enemyHp: number; enemySpeed: number; spawn: number;
  playerSpeed: number; cdMul: number; xpMul: number; noHeal: boolean; coin: number;
}

export const CLASSIC_DURATION = 15 * 60;
export const CHALLENGE_DURATION = 10 * 60;

export const MODES: Record<ModeId, ModeDef> = {
  classic: { id: "classic", name: "Classic Survival", desc: "Survive 15 minutes, then defeat the final boss.", goal: "Survive 15:00 and slay the final boss" },
  endless: { id: "endless", name: "Endless", desc: "Enemies grow stronger forever. How long can you last?", goal: "Survive as long as you can" },
  bossrush: { id: "bossrush", name: "Boss Rush", desc: "Face all five bosses back-to-back.", goal: "Defeat all 5 bosses" },
  challenge: { id: "challenge", name: "Challenge", desc: "Twisted rules, bigger rewards. Survive 10 minutes.", goal: "Survive 10:00" },
};

export const DIFFICULTIES: Record<DifficultyId, DifficultyDef> = {
  easy: { id: "easy", name: "Easy", hp: 0.7, dmg: 0.6, coin: 0.7, desc: "Learn the ropes" },
  normal: { id: "normal", name: "Normal", hp: 1, dmg: 1, coin: 1, desc: "The intended experience" },
  hard: { id: "hard", name: "Hard", hp: 1.5, dmg: 1.4, coin: 1.5, desc: "For seasoned survivors" },
  nightmare: { id: "nightmare", name: "Nightmare", hp: 2.3, dmg: 2, coin: 2.5, desc: "Pure skill. No mercy." },
};

const C = (p: Partial<ChallengeDef> & Pick<ChallengeDef, "id" | "name" | "desc" | "reward">): ChallengeDef => ({
  hpMul: 1, dmgMul: 1, enemyHp: 1, enemySpeed: 1, spawn: 1, playerSpeed: 1, cdMul: 1, xpMul: 1, noHeal: false, coin: 1.8, ...p,
});

export const CHALLENGES: Record<ChallengeId, ChallengeDef> = {
  glass: C({ id: "glass", name: "Glass Cannon", desc: "30% max health, double damage.", reward: 600, hpMul: 0.3, dmgMul: 2, coin: 2 }),
  swarm: C({ id: "swarm", name: "Endless Swarm", desc: "Triple the monsters at half health.", reward: 500, spawn: 3, enemyHp: 0.5, xpMul: 0.6 }),
  frenzy: C({ id: "frenzy", name: "Frenzy", desc: "Monsters move 40% faster. You move 15% faster.", reward: 550, enemySpeed: 1.4, playerSpeed: 1.15 }),
  cursed: C({ id: "cursed", name: "Cursed Blood", desc: "No healing at all, but weapons fire 35% faster.", reward: 650, noHeal: true, cdMul: 0.65, coin: 2 }),
};
