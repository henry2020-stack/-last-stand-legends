import type { WeaponId } from "./weapons";

export type CharId = "kael" | "lyra" | "ignis" | "nyx" | "bjorn" | "vex" | "rook" | "drakon";
export type Accessory = "helm" | "hood" | "hat" | "mask" | "horns" | "goggles" | "crown" | "bandana";

export interface CharStats {
  hp: number;
  speed: number; // multiplier
  armor: number;
  might: number; // multiplier
  haste: number; // cooldown multiplier (<1 is faster)
  crit: number;
  area: number;
  magnet: number;
  proj: number;
}

export interface CharacterDef {
  id: CharId;
  name: string;
  title: string;
  desc: string;
  weapon: WeaponId;
  ability: { name: string; desc: string; cd: number };
  cost: number;
  strengths: string;
  weakness: string;
  stats: CharStats;
  body: string;
  trim: string;
  skin: string;
  glow: string;
  accessory: Accessory;
}

const S = (p: Partial<CharStats>): CharStats => ({ hp: 100, speed: 1, armor: 0, might: 1, haste: 1, crit: 0.05, area: 1, magnet: 1, proj: 0, ...p });

export const CHARACTERS: Record<CharId, CharacterDef> = {
  kael: {
    id: "kael", name: "Kael", title: "The Vanguard", weapon: "plasma", cost: 0,
    desc: "A disciplined blade-knight who thrives in the thick of battle.",
    ability: { name: "Blade Storm", desc: "Unleash a spiral of 24 piercing plasma blades and become briefly untouchable.", cd: 16 },
    strengths: "Balanced, sturdy", weakness: "No standout stat",
    stats: S({ hp: 120, armor: 1 }), body: "#2a7bff", trim: "#59f3ff", skin: "#f2c9a0", glow: "#59f3ff", accessory: "helm",
  },
  lyra: {
    id: "lyra", name: "Lyra", title: "Stormcaller", weapon: "lightning", cost: 400,
    desc: "A sky-witch who bends the storm to her will.",
    ability: { name: "Chain Surge", desc: "Lightning arcs through up to 15 enemies, stunning them.", cd: 14 },
    strengths: "Faster cooldowns", weakness: "Fragile",
    stats: S({ hp: 85, haste: 0.88, speed: 1.05 }), body: "#3a3aa8", trim: "#fff27a", skin: "#ffe0c4", glow: "#fff27a", accessory: "hat",
  },
  ignis: {
    id: "ignis", name: "Ignis", title: "Pyromancer", weapon: "nova", cost: 600,
    desc: "Born in a volcano, he burns hotter than anyone alive.",
    ability: { name: "Supernova", desc: "A colossal fire explosion that sets everything ablaze.", cd: 18 },
    strengths: "+15% damage", weakness: "Low armor",
    stats: S({ hp: 100, might: 1.15, armor: -1 }), body: "#a8281a", trim: "#ffb347", skin: "#e8b08a", glow: "#ff8a3d", accessory: "hood",
  },
  nyx: {
    id: "nyx", name: "Nyx", title: "Shadow Dancer", weapon: "daggers", cost: 900,
    desc: "An assassin who walks between shadows.",
    ability: { name: "Shadow Step", desc: "Teleport toward your aim, blasting both points. Invulnerable briefly.", cd: 7 },
    strengths: "Very fast, +10% crit", weakness: "Very fragile",
    stats: S({ hp: 75, speed: 1.2, crit: 0.15 }), body: "#2a1a3a", trim: "#c27bff", skin: "#d8c0e8", glow: "#c27bff", accessory: "mask",
  },
  bjorn: {
    id: "bjorn", name: "Bjorn", title: "Frost Warden", weapon: "ice", cost: 1200,
    desc: "A giant of the north, armored in glacier ice.",
    ability: { name: "Glacial Prison", desc: "Freeze every enemy around you solid for 3 seconds.", cd: 22 },
    strengths: "Huge health, +3 armor", weakness: "Slow",
    stats: S({ hp: 160, armor: 3, speed: 0.88 }), body: "#5a7a9a", trim: "#9be7ff", skin: "#f0d0b0", glow: "#9be7ff", accessory: "horns",
  },
  vex: {
    id: "vex", name: "Vex", title: "Plague Alchemist", weapon: "poison", cost: 1500,
    desc: "A mad chemist whose brews melt flesh and bone.",
    ability: { name: "Toxic Flask", desc: "Hurl a flask that creates a massive poison swamp.", cd: 11 },
    strengths: "+20% area, +30% pickup", weakness: "Low damage up front",
    stats: S({ hp: 100, area: 1.2, magnet: 1.3 }), body: "#2a5a2a", trim: "#9dff6a", skin: "#c8d8b0", glow: "#9dff6a", accessory: "goggles",
  },
  rook: {
    id: "rook", name: "Rook", title: "Demolitionist", weapon: "mines", cost: 2000,
    desc: "A scrapper engineer with a bag full of explosives.",
    ability: { name: "Sentry Turret", desc: "Deploy a rapid-fire turret for 10 seconds.", cd: 18 },
    strengths: "+1 projectile, +1 armor", weakness: "Slightly slow",
    stats: S({ hp: 110, armor: 1, proj: 1, speed: 0.95 }), body: "#8a6a2a", trim: "#ffcf3a", skin: "#d8a878", glow: "#ffcf3a", accessory: "bandana",
  },
  drakon: {
    id: "drakon", name: "Drakon", title: "Dragonborn", weapon: "dragon", cost: 3000,
    desc: "Last heir of the dragon kings. Fire runs in his veins.",
    ability: { name: "Dragon Form", desc: "Transform for 6s: +50% damage, +30% speed, fire aura, half damage taken.", cd: 24 },
    strengths: "+10% damage, high health", weakness: "Slow cooldowns",
    stats: S({ hp: 140, might: 1.1, haste: 1.08 }), body: "#7a1a1a", trim: "#ffe14a", skin: "#d89a6a", glow: "#ff7a1a", accessory: "crown",
  },
};

export const CHAR_IDS = Object.keys(CHARACTERS) as CharId[];
