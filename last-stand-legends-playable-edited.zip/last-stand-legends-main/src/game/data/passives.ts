export type PassiveId =
  | "might" | "haste" | "swift" | "precision" | "vitality" | "armor"
  | "magnet" | "reflexes" | "area" | "recovery" | "multishot" | "wisdom";

export interface PassiveDef {
  id: PassiveId;
  name: string;
  category: string;
  desc: string; // per level
  max: number;
  color: string;
}

export const PASSIVES: Record<PassiveId, PassiveDef> = {
  might: { id: "might", name: "Might", category: "Damage", desc: "+10% damage", max: 5, color: "#ff5a4a" },
  haste: { id: "haste", name: "Haste", category: "Attack speed", desc: "-8% weapon cooldowns", max: 5, color: "#ffd84a" },
  swift: { id: "swift", name: "Swiftness", category: "Movement", desc: "+8% movement speed", max: 5, color: "#6aff9a" },
  precision: { id: "precision", name: "Precision", category: "Critical", desc: "+5% crit chance, +10% crit damage", max: 5, color: "#ffb13d" },
  vitality: { id: "vitality", name: "Vitality", category: "Max health", desc: "+20 max health", max: 5, color: "#ff6b8a" },
  armor: { id: "armor", name: "Armor", category: "Defense", desc: "+1 armor (flat damage reduction)", max: 5, color: "#b9c6d6" },
  magnet: { id: "magnet", name: "Magnet", category: "Pickup range", desc: "+30% XP collection range", max: 5, color: "#5ab8ff" },
  reflexes: { id: "reflexes", name: "Reflexes", category: "Dodge", desc: "-12% dash cooldown, longer i-frames", max: 5, color: "#7affea" },
  area: { id: "area", name: "Amplifier", category: "Area", desc: "+10% weapon area", max: 5, color: "#c48bff" },
  recovery: { id: "recovery", name: "Recovery", category: "Regeneration", desc: "+0.4 health per second", max: 5, color: "#7dff6a" },
  multishot: { id: "multishot", name: "Multishot", category: "Projectiles", desc: "+1 projectile to most weapons", max: 2, color: "#ff8ae0" },
  wisdom: { id: "wisdom", name: "Wisdom", category: "Experience", desc: "+10% XP gained", max: 5, color: "#8ae8ff" },
};

export const PASSIVE_IDS = Object.keys(PASSIVES) as PassiveId[];
