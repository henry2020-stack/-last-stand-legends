import type { Poolable } from "../core/pool";
import type { DamageType } from "../data/common";
import type { AttackId, BossDef } from "../data/bosses";
import type { EnemyDef, EnemyId } from "../data/enemies";
import type { WeaponId } from "../data/weapons";
import type { PassiveId } from "../data/passives";

export interface Stats {
  maxHp: number;
  speed: number;
  armor: number;
  might: number;
  cdMul: number;
  area: number;
  crit: number;
  critMul: number;
  magnet: number;
  dashCd: number;
  dashIframe: number;
  regen: number;
  proj: number;
  xpMul: number;
  coinMul: number;
}

export interface Player {
  x: number; y: number; vx: number; vy: number; r: number;
  hp: number;
  facing: number; // movement facing angle
  iframes: number;
  hurtT: number;
  dashT: number; dashX: number; dashY: number;
  walkT: number;
  slowT: number; slowAmt: number;
  dotT: number; dotDps: number; dotTick: number;
  dragonT: number;
  hazardTick: number;
}

export interface BossRt {
  def: BossDef;
  phase: number;
  atk: AttackId | null;
  atkT: number;
  atkStep: number;
  cd: number;
  last: AttackId | null;
  ang: number;
  dirX: number; dirY: number;
  final: boolean;
  enraged: boolean;
}

export interface Enemy {
  id: number;
  type: EnemyId | "boss";
  def: EnemyDef | null;
  x: number; y: number; vx: number; vy: number; kx: number; ky: number;
  r: number; hp: number; maxHp: number; dmg: number; speed: number; xp: number; mass: number;
  color: string; color2: string;
  t: number; hitFlash: number; facing: number; spawnT: number;
  st: number; stT: number; cd: number; cd2: number; tx: number; ty: number;
  slowT: number; slowAmt: number; freezeT: number;
  burnT: number; burnDps: number; poisonT: number; poisonDps: number; dotTick: number;
  invuln: boolean; elite: boolean; mini: boolean; summoned: boolean; dead: boolean;
  hitCd: Map<string, number>;
  boss: BossRt | null;
  resist: Partial<Record<DamageType, number>> | undefined;
}

export type ProjKind = "dagger" | "void" | "shard" | "missile" | "orb" | "boomerang" | "cyclone" | "flame" | "bullet" | "blade";

export interface Proj extends Poolable {
  kind: ProjKind;
  x: number; y: number; vx: number; vy: number; r: number;
  dmg: number; dtype: DamageType; pierce: number;
  life: number; max: number;
  color: string;
  src: WeaponId | "ability" | "turret";
  hits: Set<number>;
  t: number; a: number; b: number; st: number;
  target: Enemy | null;
  evo: boolean;
}

export interface EProj extends Poolable {
  kind: "fire" | "frost" | "poison" | "bone" | "void" | "missile" | "orb" | "spit";
  x: number; y: number; vx: number; vy: number; r: number;
  dmg: number; life: number; color: string;
  effect: 0 | 1 | 2 | 3; // none, slow, poison, burn
  t: number; accel: number; tx: number; ty: number; lob: number;
}

export type ZoneKind =
  | "puddle" | "telegraph" | "nova" | "burn" | "cloud" | "miasma" | "meteor" | "lava" | "mine"
  | "rift" | "eruption" | "gravity" | "turret" | "summon" | "ringwarn" | "freezeAura";

export interface Zone {
  alive: boolean;
  kind: ZoneKind;
  x: number; y: number; r: number; maxR: number;
  t: number; life: number; delay: number; delayMax: number;
  dmg: number; tick: number; tickT: number;
  color: string;
  a: number; b: number;
  evo: boolean;
  src: string;
}

export type PickupKind = "gem" | "coin" | "heart" | "magnet" | "bomb" | "chest";
export interface Pickup {
  alive: boolean;
  kind: PickupKind;
  x: number; y: number; vx: number; vy: number;
  value: number; tier: number; mag: boolean; t: number;
}

export interface Particle extends Poolable {
  x: number; y: number; vx: number; vy: number;
  life: number; max: number; size: number; color: string;
  kind: 0 | 1 | 2 | 3; // glow, spark, smoke, shard
  drag: number; grav: number; rot: number;
}

export interface DmgText extends Poolable {
  x: number; y: number; vy: number; life: number; max: number;
  text: string; color: string; size: number;
}

export interface Ring { x: number; y: number; r: number; max: number; life: number; maxLife: number; color: string; width: number }
export interface Bolt { pts: number[]; life: number; max: number; color: string; width: number }

export interface WeaponRt {
  id: WeaponId;
  level: number;
  evolved: boolean;
  timer: number;
  activeT: number;
  angle: number;
  aux: number;
  aux2: number;
  pts: number[];
}

export type UpgradeKind = "weapon" | "newWeapon" | "passive" | "newPassive" | "evolution" | "gold" | "heal";
export interface UpgradeChoice {
  kind: UpgradeKind;
  id: WeaponId | PassiveId | "gold" | "heal";
  name: string;
  desc: string;
  level: number;
  rarity: "common" | "rare" | "epic" | "legendary";
  color: string;
  tag: string;
}

export interface HudSnapshot {
  hp: number; maxHp: number;
  xp: number; xpNext: number; level: number;
  time: number; kills: number; coins: number;
  weapons: { id: WeaponId; level: number; evolved: boolean; ready: number }[];
  passives: { id: PassiveId; level: number }[];
  ability: number; abilityReady: boolean; abilityActive: boolean;
  dash: number;
  boss: { name: string; title: string; hp: number; max: number; phase: number; color: string } | null;
  goal: string;
  rerolls: number;
  revives: number;
  hazardText: string | null;
}

export interface Banner { text: string; sub?: string; kind: "boss" | "evolve" | "warning" | "info" | "victory" }
