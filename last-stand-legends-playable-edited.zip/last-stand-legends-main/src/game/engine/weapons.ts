import { TAU, angleDiff, dist2, rand, segDist2 } from "../core/math";
import { WEAPONS, type WeaponId, type WeaponLevel } from "../data/weapons";
import type { Game } from "./game";
import type { Enemy, Proj, WeaponRt } from "./types";

const B: Enemy[] = [];

export function addWeapon(g: Game, id: WeaponId) {
  g.weapons.push({ id, level: 1, evolved: false, timer: 0.4, activeT: 0, angle: 0, aux: 0, aux2: 1, pts: [] });
}
export function wl(w: WeaponRt): WeaponLevel {
  const d = WEAPONS[w.id];
  return w.evolved ? d.evo : d.levels[w.level - 1]!;
}

function cooldown(g: Game, w: WeaponRt, L: WeaponLevel, dt: number): boolean {
  w.timer -= dt;
  const cd = L.cd * g.stats.cdMul;
  w.aux2 = Math.max(0, Math.min(1, 1 - w.timer / cd));
  if (w.timer <= 0) { w.timer = cd; return true; }
  return false;
}

export function updateWeapons(g: Game, dt: number) {
  const p = g.player, s = g.stats;
  for (const w of g.weapons) {
    const L = wl(w);
    const d = WEAPONS[w.id];
    switch (w.id) {
      case "plasma": {
        const n = L.count + s.proj;
        const R = 78 * L.area * s.area;
        w.angle += L.speed * dt;
        w.pts.length = 0;
        w.aux2 = 1;
        const rings = w.evolved ? 2 : 1;
        const br = 15 * L.area * Math.sqrt(s.area);
        for (let k = 0; k < rings; k++) {
          const cnt = k === 0 ? n : Math.max(3, n - 2);
          const rad = k === 0 ? R : R * 1.6;
          const dir = k === 0 ? 1 : -1.3;
          for (let i = 0; i < cnt; i++) {
            const a = w.angle * dir + (i * TAU) / cnt;
            const bx = p.x + Math.cos(a) * rad, by = p.y + Math.sin(a) * rad;
            w.pts.push(bx, by, a + (dir > 0 ? Math.PI / 2 : -Math.PI / 2), k);
            for (const e of g.grid.query(bx, by, br + 50, B)) {
              if (e.dead) continue;
              const rr = br + e.r;
              if (dist2(e.x, e.y, bx, by) < rr * rr && (e.hitCd.get("plasma") ?? 0) <= g.time) {
                e.hitCd.set("plasma", g.time + 0.38);
                const dd = Math.hypot(e.x - p.x, e.y - p.y) || 1;
                g.damageEnemy(e, L.dmg, "physical", "plasma", { kx: ((e.x - p.x) / dd) * 260, ky: ((e.y - p.y) / dd) * 260, fromX: bx, fromY: by });
                g.burst(bx, by, d.color, 3, 180, 2, 0.25);
              }
            }
          }
        }
        break;
      }
      case "lightning": {
        if (cooldown(g, w, L, dt)) {
          const n = L.count + s.proj;
          for (let i = 0; i < n; i++) {
            const a = g.aimAngle + (i - (n - 1) / 2) * 0.6;
            const o = g.fireProj("orb", p.x, p.y, a, L.speed, L.dmg, "lightning", 999, 11 * s.area, L.dur, d.color, "lightning", w.evolved);
            if (o) { o.a = 0.1; o.b = L.pierce; o.st = 150 * L.area * s.area; }
          }
          g.audioPlay("zap", 0.6);
        }
        if (w.evolved) {
          w.aux -= dt;
          if (w.aux <= 0) {
            w.aux = 0.55 * s.cdMul;
            const hw = g.viewW / 2, hh = g.viewH / 2;
            const vis = g.enemies.filter((e) => !e.dead && !e.invuln && Math.abs(e.x - p.x) < hw && Math.abs(e.y - p.y) < hh);
            for (let k = 0; k < 3 && vis.length; k++) {
              const e = vis.splice(Math.floor(Math.random() * vis.length), 1)[0]!;
              g.bolt(e.x + rand(-60, 60), e.y - 520, e.x, e.y, "#fff8b0", 5, 0.25);
              g.ring(e.x, e.y, 60, "#fff27a", 0.3, 4);
              g.damageEnemy(e, L.dmg * 1.6, "lightning", "lightning", {});
              let prev = e;
              for (let c = 0; c < 2; c++) {
                const nx = g.grid.query(prev.x, prev.y, 170, B).find((o) => !o.dead && o !== prev && o !== e && dist2(o.x, o.y, prev.x, prev.y) < 170 * 170);
                if (!nx) break;
                g.bolt(prev.x, prev.y, nx.x, nx.y, "#fff27a", 3);
                g.damageEnemy(nx, L.dmg * 0.8, "lightning", "lightning", {});
                prev = nx;
              }
            }
            g.shake(2);
            g.audioPlay("zap", 0.8, 0.8);
          }
        }
        break;
      }
      case "nova": {
        if (cooldown(g, w, L, dt)) {
          const R = 180 * L.area * s.area;
          for (let k = 0; k < L.count; k++) {
            const z = g.addZone("nova", p.x, p.y, 12, { life: 5, dmg: L.dmg, color: d.color, a: L.speed, evo: w.evolved, src: "nova", delay: k * 0.28, b: g.nextId++ });
            z.maxR = R * (k ? 1.25 : 1);
          }
          if (w.evolved) for (let i = 0; i < 8; i++) {
            const a = (i / 8) * TAU + rand(-0.2, 0.2);
            g.addZone("burn", p.x + Math.cos(a) * R * 0.75, p.y + Math.sin(a) * R * 0.75, 40 * s.area, { life: 3, dmg: L.dmg * 0.25, tick: 0.4, color: "#ff6a2a", src: "nova" });
          }
          g.audioPlay("fire", 1, 0.7);
          g.shake(w.evolved ? 4 : 2);
        }
        break;
      }
      case "daggers": {
        if (cooldown(g, w, L, dt)) {
          const n = L.count + s.proj;
          for (let i = 0; i < n; i++) {
            const a = g.aimAngle + (i - (n - 1) / 2) * 0.13;
            g.fireProj(w.evolved ? "void" : "dagger", p.x, p.y, a, L.speed, L.dmg, "shadow", L.pierce, 7 * s.area, w.evolved ? 2.2 : L.dur, d.color, "daggers", w.evolved);
          }
          g.audioPlay("shoot", 0.6, 1.2);
        }
        break;
      }
      case "ice": {
        const fireWave = (off: number) => {
          const n = L.count + s.proj * 2;
          for (let i = 0; i < n; i++) {
            const a = w.angle + off + (i * TAU) / n;
            g.fireProj("shard", p.x, p.y, a, L.speed, L.dmg, "ice", L.pierce, 7 * s.area, L.dur, d.color, "ice", w.evolved);
          }
          g.audioPlay("ice", 0.8);
        };
        if (cooldown(g, w, L, dt)) {
          fireWave(0);
          w.angle += 0.26;
          if (w.evolved) w.activeT = 0.18;
        }
        if (w.activeT > 0) { w.activeT -= dt; if (w.activeT <= 0) fireWave(Math.PI / (L.count + s.proj * 2)); }
        if (w.evolved) {
          w.aux -= dt;
          const R = 125 * s.area;
          if (w.aux <= 0) {
            w.aux = 0.5;
            for (const e of g.grid.query(p.x, p.y, R + 40, B)) {
              if (e.dead || dist2(e.x, e.y, p.x, p.y) > (R + e.r) ** 2) continue;
              g.damageEnemy(e, 5, "ice", "ice", { slow: 0.55, noCrit: true, silent: true });
            }
          }
        }
        break;
      }
      case "meteor": {
        if (cooldown(g, w, L, dt)) {
          const n = L.count + s.proj;
          for (let i = 0; i < n; i++) {
            const t = g.randomEnemyNear(p.x, p.y, 480);
            const x = t ? t.x : p.x + rand(-300, 300), y = t ? t.y : p.y + rand(-300, 300);
            g.addZone("meteor", x, y, 80 * L.area * s.area, { delay: L.dur + i * 0.12, dmg: L.dmg, evo: w.evolved, color: d.color, src: "meteor" });
          }
        }
        break;
      }
      case "poison": {
        if (cooldown(g, w, L, dt)) {
          for (let i = 0; i < L.count + s.proj; i++) {
            const t = g.randomEnemyNear(p.x, p.y, 380);
            const x = t ? t.x : p.x + rand(-200, 200), y = t ? t.y : p.y + rand(-200, 200);
            g.addZone("cloud", x, y, 70 * L.area * s.area, { life: L.dur, dmg: L.dmg, tick: 0.5, color: d.color, src: "poison" });
          }
          g.audioPlay("fire", 0.5, 1.6);
        }
        if (w.evolved && !g.zones.some((z) => z.kind === "miasma")) {
          g.addZone("miasma", p.x, p.y, 140 * s.area, { life: 10, dmg: L.dmg * 0.6, tick: 0.5, color: "#7dff4a", src: "poison" });
        }
        break;
      }
      case "beam": {
        const nb = L.count + (w.evolved ? 0 : 0);
        if (w.activeT > 0) {
          w.activeT -= dt;
          w.aux2 = 1;
          const turn = 7 * dt;
          const diff = angleDiff(w.angle, g.aimAngle);
          w.angle += Math.max(-turn, Math.min(turn, diff));
          const len = 560 * Math.sqrt(L.area);
          const width = 16 * L.area * s.area;
          w.pts.length = 0;
          w.aux -= dt;
          const tick = w.aux <= 0;
          if (tick) w.aux = 0.1;
          for (let k = 0; k < nb; k++) {
            const a = w.angle + (k - (nb - 1) / 2) * 0.33;
            const ex = p.x + Math.cos(a) * len, ey = p.y + Math.sin(a) * len;
            w.pts.push(a, len, width);
            if (!tick) continue;
            for (const e of g.grid.query((p.x + ex) / 2, (p.y + ey) / 2, len / 2 + 40, B)) {
              if (e.dead) continue;
              if (segDist2(e.x, e.y, p.x, p.y, ex, ey) < (width / 2 + e.r) ** 2) {
                g.damageEnemy(e, L.dmg, "arcane", "beam", { fromX: p.x, fromY: p.y, kx: Math.cos(a) * 50, ky: Math.sin(a) * 50, silent: Math.random() < 0.5 });
                g.particle(e.x, e.y, rand(-120, 120), rand(-120, 120), d.color, 0.3, 4, 1);
              }
            }
          }
          if (tick) g.audioPlay("beam", 0.5);
          if (w.activeT <= 0) w.pts.length = 0;
        } else if (cooldown(g, w, L, dt)) {
          w.activeT = L.dur;
          w.angle = g.aimAngle;
          w.aux = 0;
        }
        break;
      }
      case "missiles": {
        if (cooldown(g, w, L, dt)) {
          const n = L.count + s.proj;
          for (let i = 0; i < n; i++) {
            const a = g.aimAngle + rand(-1.4, 1.4);
            const m = g.fireProj("missile", p.x, p.y, a, L.speed * 0.5, L.dmg, "arcane", 0, 6, L.dur, w.evolved ? "#ffe9a0" : d.color, "missiles", w.evolved);
            if (m) { m.b = L.speed; m.target = g.randomEnemyNear(p.x, p.y, 500) ?? g.nearestEnemy(p.x, p.y, 700); }
          }
          g.audioPlay("shoot", 0.5, 0.8);
        }
        break;
      }
      case "mines": {
        if (cooldown(g, w, L, dt)) {
          for (let i = 0; i < L.count + s.proj; i++) {
            g.addZone("mine", p.x + rand(-34, 34), p.y + rand(-34, 34), 90 * L.area * s.area, { delay: 0.5, life: L.dur, dmg: L.dmg, evo: w.evolved, color: d.color, src: "mines" });
          }
          const mines = g.zones.filter((z) => z.kind === "mine" && z.alive);
          const cap = 12 + L.count * 4;
          for (let i = 0; i < mines.length - cap; i++) mines[i]!.alive = false;
        }
        break;
      }
      case "boomerang": {
        if (cooldown(g, w, L, dt)) {
          const n = L.count + s.proj;
          for (let i = 0; i < n; i++) {
            const a = g.aimAngle + (i - (n - 1) / 2) * 0.45;
            const r = (w.evolved ? 26 : 14) * L.area * s.area;
            const b = g.fireProj(w.evolved ? "cyclone" : "boomerang", p.x, p.y, a, L.speed, L.dmg, "physical", 999, r, 7, d.color, "boomerang", w.evolved);
            if (b) b.b = L.speed;
          }
          g.audioPlay("dash", 0.4);
        }
        break;
      }
      case "dragon": {
        if (w.activeT > 0) {
          w.activeT -= dt;
          w.aux2 = 1;
          w.aux -= dt;
          const cone = (w.evolved ? 1.05 : 0.62) * Math.sqrt(L.area);
          while (w.aux <= 0) {
            w.aux += 0.032;
            const a = g.aimAngle + rand(-cone / 2, cone / 2);
            const sp = L.speed * rand(0.8, 1.1) * (w.evolved ? 1.2 : 1);
            g.fireProj("flame", p.x + Math.cos(g.aimAngle) * 14, p.y + Math.sin(g.aimAngle) * 14, a, sp, L.dmg, "fire", L.pierce, 10 * s.area, 0.55, d.color, "dragon", w.evolved);
          }
          g.audioPlay("fire", 0.5);
        } else if (cooldown(g, w, L, dt)) {
          w.activeT = L.dur;
          w.aux = 0;
        }
        break;
      }
    }
  }
}

export function updateProjectiles(g: Game, dt: number) {
  const pl = g.player;
  for (const p of g.projs.items) {
    p.t += dt;
    p.life -= dt;
    if (p.life <= 0) { p.alive = false; continue; }
    switch (p.kind) {
      case "orb": {
        const k = Math.exp(-0.7 * dt);
        p.vx *= k; p.vy *= k;
        p.a -= dt;
        if (p.a <= 0) {
          p.a = 0.28;
          let n = 0;
          for (const e of g.grid.query(p.x, p.y, p.st, B)) {
            if (e.dead || e.invuln || dist2(e.x, e.y, p.x, p.y) > p.st * p.st) continue;
            g.bolt(p.x, p.y, e.x, e.y, "#fff27a", 2.5);
            g.damageEnemy(e, p.dmg, "lightning", "lightning", {});
            if (++n >= p.b) break;
          }
          if (n) g.audioPlay("zap", 0.35);
        }
        break;
      }
      case "missile": {
        if (!p.target || p.target.dead) { if (p.t % 0.2 < dt) p.target = g.nearestEnemy(p.x, p.y, 700); }
        const sp = Math.min(p.b, Math.hypot(p.vx, p.vy) + 900 * dt);
        let a = Math.atan2(p.vy, p.vx);
        if (p.target) {
          const ta = Math.atan2(p.target.y - p.y, p.target.x - p.x);
          const d = angleDiff(a, ta);
          const turn = 7 * dt;
          a += Math.max(-turn, Math.min(turn, d));
        }
        p.vx = Math.cos(a) * sp; p.vy = Math.sin(a) * sp;
        if (Math.random() < 0.6) g.particle(p.x, p.y, -p.vx * 0.05, -p.vy * 0.05, p.color, 0.3, 4, 0);
        break;
      }
      case "boomerang": case "cyclone": {
        const sp = Math.hypot(p.vx, p.vy);
        if (p.st === 0) {
          const ns = sp - (p.kind === "cyclone" ? 520 : 950) * dt;
          if (ns <= 20) {
            p.st = p.kind === "cyclone" ? 2 : 1;
            p.a = 1.1;
            p.hits.clear();
            p.vx *= 0.01; p.vy *= 0.01;
          } else { p.vx = (p.vx / sp) * ns; p.vy = (p.vy / sp) * ns; }
        } else if (p.st === 2) {
          p.a -= dt;
          if (p.t % 0.25 < dt) p.hits.clear();
          for (const e of g.grid.query(p.x, p.y, 150, B)) {
            if (e.dead || e.boss) continue;
            const d = Math.sqrt(dist2(e.x, e.y, p.x, p.y)) || 1;
            if (d < 150) { e.x += ((p.x - e.x) / d) * 180 * dt; e.y += ((p.y - e.y) / d) * 180 * dt; }
          }
          if (p.a <= 0) { p.st = 1; p.hits.clear(); }
        } else {
          const dx = pl.x - p.x, dy = pl.y - p.y, d = Math.hypot(dx, dy) || 1;
          const ns = Math.min(800, sp + 1400 * dt);
          p.vx = (dx / d) * ns; p.vy = (dy / d) * ns;
          if (d < 24) { p.alive = false; continue; }
        }
        p.a += 0;
        break;
      }
      case "void": {
        if (p.st === 0 && p.t > 0.45) { p.st = 1; p.hits.clear(); }
        if (p.st === 1) {
          const dx = pl.x - p.x, dy = pl.y - p.y, d = Math.hypot(dx, dy) || 1;
          const sp = Math.hypot(p.vx, p.vy);
          const a = Math.atan2(p.vy, p.vx) + Math.max(-9 * dt, Math.min(9 * dt, angleDiff(Math.atan2(p.vy, p.vx), Math.atan2(dy, dx))));
          p.vx = Math.cos(a) * sp; p.vy = Math.sin(a) * sp;
          if (d < 22) { p.alive = false; continue; }
        }
        if (Math.random() < 0.5) g.particle(p.x, p.y, 0, 0, "#7a3aff", 0.25, 5, 0);
        break;
      }
      case "flame": {
        const k = Math.exp(-2.2 * dt);
        p.vx *= k; p.vy *= k;
        p.r += 30 * dt;
        break;
      }
      case "shard":
        if (Math.random() < 0.25) g.particle(p.x, p.y, 0, 0, "#cff4ff", 0.25, 3, 0);
        break;
      default: break;
    }
    p.x += p.vx * dt;
    p.y += p.vy * dt;
    if (p.kind === "orb") continue;
    collide(g, p);
  }
  g.projs.sweep();
}

function collide(g: Game, p: Proj) {
  for (const e of g.grid.query(p.x, p.y, p.r + 50, B)) {
    if (e.dead || p.hits.has(e.id)) continue;
    const rr = p.r + e.r;
    if (dist2(e.x, e.y, p.x, p.y) >= rr * rr) continue;
    if (e.invuln) continue;
    p.hits.add(e.id);
    const sp = Math.hypot(p.vx, p.vy) || 1;
    const nx = p.vx / sp, ny = p.vy / sp;
    const kn = p.kind === "flame" ? 40 : p.kind === "shard" ? 90 : 170;
    const o: Parameters<Game["damageEnemy"]>[4] = { kx: nx * kn, ky: ny * kn, fromX: e.x - nx * 50, fromY: e.y - ny * 50 };
    if (p.src === "ice") { if (p.evo) o.freeze = 1.0; else o.slow = 0.45; }
    if (p.src === "dragon") { o.burn = p.dmg * 0.6; o.silent = Math.random() < 0.7; }
    g.damageEnemy(e, p.dmg, p.dtype, p.src, o);
    g.burst(p.x, p.y, p.color, p.kind === "flame" ? 1 : 4, 160, 2.5, 0.25);
    if (p.kind === "missile" && p.evo) g.explode(p.x, p.y, 60 * g.stats.area, 0, p.dmg * 0.6, p.color, "missiles");
    p.pierce--;
    if (p.pierce < 0) { p.alive = false; return; }
  }
}
