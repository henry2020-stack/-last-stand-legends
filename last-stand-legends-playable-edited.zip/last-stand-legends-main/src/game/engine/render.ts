import type { Game } from "./game";
import { drawGlow } from "./draw-utils";

const TAU = Math.PI * 2;
const fmt = (n: number) => `${Math.floor(n / 60)}:${String(Math.floor(n % 60)).padStart(2, "0")}`;

/** Canvas renderer for the arena. World coordinates are translated by the camera. */
export function render(g: Game) {
  const { ctx, w, h, dpr, zoom, map } = g;
  if (!w || !h) return;
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.clearRect(0, 0, w, h);
  ctx.fillStyle = map.ground;
  ctx.fillRect(0, 0, w, h);
  ctx.save();
  ctx.scale(zoom, zoom);
  const vw = w / zoom, vh = h / zoom;
  const ox = vw / 2 - g.camX + g.shakeX;
  const oy = vh / 2 - g.camY + g.shakeY;
  ctx.translate(ox, oy);
  const left = g.camX - vw / 2 - 120, top = g.camY - vh / 2 - 120;
  // Subtle tile grid and scattered ground marks.
  const tile = 96;
  ctx.strokeStyle = map.detail + "55";
  ctx.lineWidth = 1;
  ctx.beginPath();
  for (let x = Math.floor(left / tile) * tile; x < left + vw + 240; x += tile) { ctx.moveTo(x, top); ctx.lineTo(x, top + vh + 240); }
  for (let y = Math.floor(top / tile) * tile; y < top + vh + 240; y += tile) { ctx.moveTo(left, y); ctx.lineTo(left + vw + 240, y); }
  ctx.stroke();
  for (let i = 0; i < 80; i++) {
    const x = Math.floor((left + i * 173) / 71) * 71;
    const y = Math.floor((top + i * 97) / 71) * 71;
    ctx.fillStyle = map.detail + "44";
    ctx.fillRect(x, y, 3, 3);
  }
  // Ground hazards and zones.
  for (const z of g.zones) {
    if (z.delay > 0 && z.kind === "telegraph") ctx.globalAlpha = 0.25 + Math.sin(g.time * 14) * 0.15;
    else ctx.globalAlpha = 0.28;
    ctx.fillStyle = z.color;
    ctx.beginPath(); ctx.arc(z.x, z.y, Math.max(3, z.r), 0, TAU); ctx.fill();
    ctx.globalAlpha = 0.8; ctx.strokeStyle = z.color; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.arc(z.x, z.y, Math.max(3, z.r), 0, TAU); ctx.stroke();
  }
  ctx.globalAlpha = 1;
  // Pickups.
  for (const p of g.pickups) {
    if (!p.alive) continue;
    const colors: Record<string, string> = { gem: "#59f3ff", coin: "#ffd84a", heart: "#ff6484", magnet: "#9d7bff", bomb: "#ff8a3d", chest: "#ffe14a" };
    const c = colors[p.kind] ?? "#fff";
    drawGlow(ctx, c, p.x, p.y, p.kind === "chest" ? 25 : 13);
    ctx.fillStyle = c;
    if (p.kind === "chest") { ctx.fillRect(p.x - 10, p.y - 8, 20, 16); ctx.fillStyle = "#75451d"; ctx.fillRect(p.x - 10, p.y - 1, 20, 4); }
    else { ctx.beginPath(); ctx.arc(p.x, p.y, p.kind === "gem" ? 5 : 6, 0, TAU); ctx.fill(); }
  }
  // Enemies.
  for (const e of g.enemies) {
    if (e.dead) continue;
    drawGlow(ctx, e.color, e.x, e.y, e.r * (e.boss ? 2.1 : 1.35));
    ctx.fillStyle = e.hitFlash > 0 ? "#ffffff" : e.color2;
    ctx.beginPath(); ctx.arc(e.x, e.y, e.r, 0, TAU); ctx.fill();
    ctx.fillStyle = e.hitFlash > 0 ? "#ffffff" : e.color;
    ctx.beginPath(); ctx.arc(e.x, e.y, e.r * 0.72, 0, TAU); ctx.fill();
    if (e.boss || e.elite || e.maxHp > 90) {
      const bw = e.r * 2.4, by = e.y - e.r - 11;
      ctx.fillStyle = "#170e19"; ctx.fillRect(e.x - bw / 2, by, bw, 5);
      ctx.fillStyle = e.boss ? "#ff5368" : "#ffb84a"; ctx.fillRect(e.x - bw / 2, by, bw * Math.max(0, e.hp / e.maxHp), 5);
    }
  }
  // Enemy projectiles and player projectiles.
  for (const p of g.eprojs.items) if (p.alive) {
    drawGlow(ctx, p.color, p.x, p.y, p.r * 2.8);
    ctx.fillStyle = p.color; ctx.beginPath(); ctx.arc(p.x, p.y, p.r, 0, TAU); ctx.fill();
  }
  for (const p of g.projs.items) if (p.alive) {
    drawGlow(ctx, p.color, p.x, p.y, p.r * 2.5);
    ctx.fillStyle = p.color; ctx.beginPath(); ctx.arc(p.x, p.y, p.r, 0, TAU); ctx.fill();
  }
  // Particle effects.
  for (const p of g.parts.items) if (p.alive) {
    ctx.globalAlpha = Math.max(0, p.life / Math.max(0.001, p.max));
    ctx.fillStyle = p.color; ctx.beginPath(); ctx.arc(p.x, p.y, Math.max(1, p.size), 0, TAU); ctx.fill();
  }
  ctx.globalAlpha = 1;
  // Weapon rings and lightning bolts.
  for (const r of g.rings) { ctx.globalAlpha = Math.max(0, r.life / r.maxLife); ctx.strokeStyle = r.color; ctx.lineWidth = r.width; ctx.beginPath(); ctx.arc(r.x, r.y, r.r, 0, TAU); ctx.stroke(); }
  ctx.globalAlpha = 1;
  for (const b of g.bolts) { ctx.globalAlpha = Math.max(0, b.life / b.max); ctx.strokeStyle = b.color; ctx.lineWidth = b.width; ctx.beginPath(); for (let i = 0; i < b.pts.length; i += 2) i ? ctx.lineTo(b.pts[i]!, b.pts[i + 1]!) : ctx.moveTo(b.pts[i]!, b.pts[i + 1]!); ctx.stroke(); }
  ctx.globalAlpha = 1;
  // Player avatar.
  const p = g.player;
  drawGlow(ctx, g.char.glow, p.x, p.y, 42);
  ctx.save();
  if (p.iframes > 0 && Math.floor(g.realT * 18) % 2 === 0) ctx.globalAlpha = 0.45;
  ctx.fillStyle = g.char.body; ctx.beginPath(); ctx.arc(p.x, p.y, p.r, 0, TAU); ctx.fill();
  ctx.strokeStyle = g.char.trim; ctx.lineWidth = 3; ctx.stroke();
  ctx.fillStyle = g.char.skin; ctx.beginPath(); ctx.arc(p.x + Math.cos(p.facing) * 5, p.y + Math.sin(p.facing) * 5, 4, 0, TAU); ctx.fill();
  ctx.restore();
  // Floating damage text.
  for (const t of g.texts.items) if (t.alive) {
    ctx.globalAlpha = Math.max(0, t.life / t.max); ctx.fillStyle = t.color; ctx.font = `bold ${t.size}px system-ui`; ctx.textAlign = "center"; ctx.fillText(t.text, t.x, t.y);
  }
  ctx.globalAlpha = 1;
  ctx.restore();
  // Edge vignette, top-level HUD labels.
  const grad = ctx.createRadialGradient(w / 2, h / 2, Math.min(w, h) * 0.2, w / 2, h / 2, Math.max(w, h) * 0.72);
  grad.addColorStop(0, "transparent"); grad.addColorStop(1, map.fog + "0.72)");
  ctx.fillStyle = grad; ctx.fillRect(0, 0, w, h);
  ctx.fillStyle = "rgba(5,8,16,.7)"; ctx.fillRect(12, 12, 250, 54);
  ctx.fillStyle = "#fff"; ctx.font = "700 14px system-ui"; ctx.textAlign = "left";
  ctx.fillText(`LEVEL ${g.level}   •   ${fmt(g.time)}`, 25, 34);
  ctx.font = "12px system-ui"; ctx.fillStyle = "#b8c6d9"; ctx.fillText(`${g.kills} KILLS   •   ${Math.floor(g.coins)} COINS`, 25, 53);
  // Health and XP bars.
  const barW = Math.min(260, w * 0.32), bx = 18, by = h - 36;
  ctx.fillStyle = "rgba(0,0,0,.65)"; ctx.fillRect(bx, by, barW, 10);
  ctx.fillStyle = "#ff5575"; ctx.fillRect(bx, by, barW * Math.max(0, p.hp / g.stats.maxHp), 10);
  ctx.fillStyle = "rgba(0,0,0,.65)"; ctx.fillRect(bx, by + 13, barW, 5);
  ctx.fillStyle = "#59e8ff"; ctx.fillRect(bx, by + 13, barW * Math.min(1, g.xp / Math.max(1, g.xpNext)), 5);
  if (g.boss) {
    const bw = Math.min(420, w * 0.55), x = (w - bw) / 2;
    ctx.fillStyle = "rgba(0,0,0,.8)"; ctx.fillRect(x, 18, bw, 22);
    ctx.fillStyle = g.boss.color; ctx.fillRect(x + 2, 20, (bw - 4) * Math.max(0, g.boss.hp / g.boss.maxHp), 18);
    ctx.strokeStyle = "#fff8"; ctx.strokeRect(x, 18, bw, 22);
    ctx.fillStyle = "#fff"; ctx.font = "bold 11px system-ui"; ctx.textAlign = "center"; ctx.fillText(g.boss.boss?.def.name ?? "BOSS", w / 2, 14);
  }
  if (g.flashT > 0) { ctx.globalAlpha = Math.min(0.35, g.flashT * 0.6); ctx.fillStyle = g.flashColor; ctx.fillRect(0, 0, w, h); ctx.globalAlpha = 1; }
}
