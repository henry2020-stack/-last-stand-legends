import type { CharId } from "../data/characters";
import type { MapId } from "../data/maps";
import type { ChallengeId, DifficultyId, ModeId } from "../data/modes";
import type { SaveData } from "../save";

export interface GameConfigInput {
  mode: ModeId;
  map: MapId;
  char: CharId;
  difficulty: DifficultyId;
  challenge: ChallengeId;
  save: SaveData;
}
