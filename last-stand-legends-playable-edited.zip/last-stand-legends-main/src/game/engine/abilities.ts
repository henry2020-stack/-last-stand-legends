import { TAU, clamp, dist2, rand } from "../core/math";
import type { Game } from "./game";
import type { Enemy } from "./types";

/** Character special abilities (Space). */
export function useAbility(g: Game) {
  const p = g.player;
  const c = g.char;
  g.audioPlay("ability");
  g.ring(p.x, p.y, 90, c.glow, 0.35, 5);
  switch (c.id) {
    case "kael": {
      for (let w = 0; w < 2; w++) for (let i = 0; i < 12; i++) {
        const a = (i / 12) * TAU + w * 0.26;
        const b = g.fireProj("blade", p.x, p.y, a, 520 + w * 160, 38, "physical", 6, 14, 1.1, "#59f3ff", "ability");
        if (b) b.t = -w * 0.1;
      }
      p.iframes = Math.max(p.iframes, 0.8);
      g.shake(6);
      break;
    }
    case "lyra": {
      const targets = g.enemies.filter((e) => !e.dead && dist2(e.x, e.y, p.x, p.y) < 520 * 520).sort((a, b) => dist2(a.x, a.y, p.x, p.y) - dist2(b.x, b.y, p.x, p.y)).slice(0, 15);
      let px = p.x, py = p.y;
      for (const e of targets) {
        g.bolt(px, py, e.x, e.y, "#fff8b0", 4, 0.35);
        g.damageEnemy(e, 65, "lightning", "ability", { freeze: 0.9 });
        px = e.x; py = e.y;
      }
      g.flash("#fff27a", 0.2);
      g.shake(6);
      g.audioPlay("zap", 1, 0.7);
      break;
    }
    case "ignis": {
      const z = g.addZone("nova", p.x, p.y, 20, { life: 5, dmg: 90, color: "#ff5a1a", a: 700, evo: true, src: "ability", b: g.nextId++ });
      z.maxR = 420 * g.stats.area;
      g.flash("#ff8a3d", 0.3);
      g.shake(12);
      g.audioPlay("explosion", 1.2, 0.6);
      break;
    }
    case "nyx": {
      const dx = g.aimX - p.x, dy = g.aimY - p.y;
      const d = Math.hypot(dx, dy) || 1;
      const len = clamp(d, 80, 300);
      const ox = p.x, oy = p.y;
      let nx = p.x + (dx / d) * len, ny = p.y + (dy / d) * len;
      if (g.arena) {
        const ax = nx - g.arena.x, ay = ny - g.arena.y, ad = Math.hypot(ax, ay);
        if (ad > g.arena.r - 20) { nx = g.arena.x + (ax / ad) * (g.arena.r - 20); ny = g.arena.y + (ay / ad) * (g.arena.r - 20); }
      }
      for (let i = 0; i < 10; i++) g.particle(ox + (nx - ox) * (i / 10), oy + (ny - oy) * (i / 10), rand(-40, 40), rand(-40, 40), "#c27bff", 0.5, 10, 0);
      p.x = nx; p.y = ny;
      p.iframes = Math.max(p.iframes, 0.7);
      for (const [x, y] of [[ox, oy], [nx, ny]] as [number, number][]) {
        g.ring(x, y, 120, "#c27bff", 0.35, 6);
        g.burst(x, y, "#c27bff", 20, 300, 4, 0.5);
        for (const e of g.grid.query(x, y, 160, [] as Enemy[])) if (!e.dead && dist2(e.x, e.y, x, y) < (115 + e.r) ** 2) g.damageEnemy(e, 55, "shadow", "ability", { kx: (e.x - x) * 4, ky: (e.y - y) * 4 });
      }
      g.audioPlay("dash", 1, 0.6);
      break;
    }
    case "bjorn": {
      for (const e of g.enemies) {
        if (e.dead || dist2(e.x, e.y, p.x, p.y) > 640 * 640) continue;
        if (e.boss) { e.slowT = 2; e.slowAmt = 0.6; }
        else e.freezeT = 3;
        g.damageEnemy(e, 22, "ice", "ability", { noCrit: true, silent: true });
      }
      g.flash("#9be7ff", 0.35);
      g.ring(p.x, p.y, 640, "#cff4ff", 0.6, 10);
      g.burst(p.x, p.y, "#cff4ff", 60, 500, 4, 0.8, 3);
      g.audioPlay("ice", 1.2, 0.5);
      break;
    }
    case "vex": {
      const dx = g.aimX - p.x, dy = g.aimY - p.y, d = Math.hypot(dx, dy) || 1;
      const len = Math.min(d, 340);
      const x = p.x + (dx / d) * len, y = p.y + (dy / d) * len;
      g.addZone("cloud", x, y, 165 * g.stats.area, { life: 6, dmg: 16, tick: 0.4, color: "#9dff6a", src: "ability" });
      g.burst(x, y, "#9dff6a", 40, 340, 6, 0.8, 2);
      g.ring(x, y, 170, "#9dff6a", 0.4, 6);
      g.audioPlay("explosion", 0.8, 1.5);
      break;
    }
    case "rook": {
      g.addZone("turret", p.x, p.y, 18, { life: 10, color: "#ffcf3a", src: "turret" });
      g.burst(p.x, p.y, "#ffcf3a", 20, 200, 3, 0.4);
      break;
    }
    case "drakon": {
      p.dragonT = 6;
      g.flash("#ff7a1a", 0.3);
      g.ring(p.x, p.y, 260, "#ff7a1a", 0.6, 10);
      g.audioPlay("roar", 0.7);
      g.shake(8);
      break;
    }
  }
}
