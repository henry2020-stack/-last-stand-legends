import { dist2, hash2, rand } from "../core/math";
import type { MapId } from "../data/maps";
import type { Game } from "./game";

export const CHUNK = 520;

export interface Deco { x: number; y: number; kind: number; s: number; rot: number; v: number }
export interface Patch { x: number; y: number; r: number }
export interface Chunk { deco: Deco[]; patches: Patch[] }

const cache = new Map<string, Chunk>();
const seedOf: Record<MapId, number> = { forest: 11, lava: 23, frozen: 37, city: 41, void: 53 };

export function getChunk(map: MapId, cx: number, cy: number): Chunk {
  const key = `${map}:${cx}:${cy}`;
  let c = cache.get(key);
  if (c) return c;
  if (cache.size > 600) cache.clear();
  const seed = seedOf[map];
  const deco: Deco[] = [];
  const n = 6 + Math.floor(hash2(cx, cy, seed) * 8);
  for (let i = 0; i < n; i++) {
    const h1 = hash2(cx * 31 + i, cy * 17 - i, seed + 1);
    const h2 = hash2(cx * 7 - i, cy * 29 + i, seed + 2);
    const h3 = hash2(cx + i * 13, cy - i * 5, seed + 3);
    deco.push({ x: cx * CHUNK + h1 * CHUNK, y: cy * CHUNK + h2 * CHUNK, kind: Math.floor(h3 * 6), s: 0.6 + hash2(i, cx + cy, seed) * 0.9, rot: h1 * 6.28, v: h2 });
  }
  const patches: Patch[] = [];
  const near0 = Math.abs(cx) <= 0 && Math.abs(cy) <= 0;
  if ((map === "forest" || map === "frozen") && !near0) {
    const h = hash2(cx, cy, seed + 9);
    const count = h < 0.45 ? 1 : h < 0.6 ? 2 : 0;
    for (let i = 0; i < count; i++) {
      patches.push({
        x: cx * CHUNK + 80 + hash2(cx + i, cy, seed + 10) * (CHUNK - 160),
        y: cy * CHUNK + 80 + hash2(cx, cy + i, seed + 11) * (CHUNK - 160),
        r: 60 + hash2(cx - i, cy + i, seed + 12) * (map === "frozen" ? 110 : 60),
      });
    }
  }
  c = { deco, patches };
  cache.set(key, c);
  return c;
}

function inPatch(map: MapId, x: number, y: number): boolean {
  const cx = Math.floor(x / CHUNK), cy = Math.floor(y / CHUNK);
  for (let i = -1; i <= 1; i++) for (let j = -1; j <= 1; j++) {
    for (const p of getChunk(map, cx + i, cy + j).patches) if (dist2(p.x, p.y, x, y) < p.r * p.r) return true;
  }
  return false;
}

export function updateHazards(g: Game, dt: number) {
  const p = g.player;
  const m = g.minutes;
  const map = g.map.id;
  g.onIce = false;
  g.hazardText = null;
  switch (g.map.hazard) {
    case "thorns": {
      if (inPatch(map, p.x, p.y)) {
        p.slowT = Math.max(p.slowT, 0.1);
        p.slowAmt = Math.max(p.slowAmt, 0.4);
        p.hazardTick -= dt;
        g.hazardText = "Thorns!";
        if (p.hazardTick <= 0) { p.hazardTick = 0.6; g.hurtRaw(2 + m * 0.4, "#b6ff6a"); }
      }
      break;
    }
    case "ice": {
      if (inPatch(map, p.x, p.y)) { g.onIce = true; g.hazardText = "Slippery ice"; }
      break;
    }
    case "eruptions": {
      g.hazardT -= dt;
      if (g.hazardT <= 0 && !g.intro) {
        g.hazardT = Math.max(2.4, 6 - m * 0.25);
        const n = 2 + Math.min(4, Math.floor(m / 3));
        for (let i = 0; i < n; i++) {
          const a = rand(0, 6.28), d = i === 0 ? rand(0, 40) : rand(80, 300);
          g.addZone("eruption", p.x + Math.cos(a) * d + p.vx * 0.6, p.y + Math.sin(a) * d + p.vy * 0.6, 72, { delay: 1.3, dmg: 14 * g.dmgScale() * g.diff.dmg, color: "#ff6a2a", src: "hazard" });
        }
      }
      break;
    }
    case "blackout": {
      g.hazardT -= dt;
      if (g.blackoutT > 0) { g.blackoutT -= dt; g.hazardText = "Blackout"; }
      if (g.hazardT <= 0 && m > 0.6) {
        g.hazardT = 55;
        g.blackoutT = 12;
        g.banner({ text: "Blackout", sub: "The lights die. Stay sharp.", kind: "warning" });
        g.audioPlay("warn");
      }
      break;
    }
    case "rifts": {
      g.hazardT -= dt;
      if (g.hazardT <= 0 && m > 0.3 && !g.intro) {
        g.hazardT = Math.max(7, 14 - m * 0.4);
        const a = rand(0, 6.28), d = rand(220, 320);
        g.addZone("gravity", p.x + Math.cos(a) * d, p.y + Math.sin(a) * d, 260, { life: 7, a: 95, dmg: 10 * g.dmgScale() * g.diff.dmg, tick: 0.5, color: "#c27bff", src: "hazard" });
        g.audioPlay("warn", 0.4);
      }
      if (g.zones.some((z) => z.kind === "gravity" && z.src === "hazard" && dist2(z.x, z.y, p.x, p.y) < z.r * z.r)) g.hazardText = "Gravity rift";
      break;
    }
  }
}
