import { PASSIVES, PASSIVE_IDS, type PassiveId } from "../data/passives";
import { MAX_WEAPON_LEVEL, WEAPONS, type WeaponId } from "../data/weapons";
import { shuffle, weighted } from "../core/math";
import type { Game } from "./game";
import type { UpgradeChoice, WeaponRt } from "./types";
import { addWeapon } from "./weapons";

const MAX_SLOTS = 6;

export function evolutionsAvailable(g: Game): WeaponRt[] {
  return g.weapons.filter((w) => !w.evolved && w.level >= MAX_WEAPON_LEVEL && (g.passives[WEAPONS[w.id].evoPassive] ?? 0) > 0);
}

function availableWeapons(g: Game): WeaponId[] {
  const set = new Set<WeaponId>([...g.cfg.save.weapons, g.char.weapon]);
  return [...set].filter((id) => !g.weapons.some((w) => w.id === id));
}

export function genChoices(g: Game, n = 3): UpgradeChoice[] {
  const pool: { c: UpgradeChoice; w: number }[] = [];
  const evos = evolutionsAvailable(g).map((w): UpgradeChoice => {
    const d = WEAPONS[w.id];
    return { kind: "evolution", id: w.id, name: d.evoName, desc: d.evoDesc, level: 0, rarity: "legendary", color: d.color, tag: "EVOLUTION" };
  });
  for (const w of g.weapons) {
    if (w.evolved || w.level >= MAX_WEAPON_LEVEL) continue;
    const d = WEAPONS[w.id];
    const hint = w.level + 1 === MAX_WEAPON_LEVEL ? ` · Max level evolves with ${PASSIVES[d.evoPassive].name}` : "";
    pool.push({ c: { kind: "weapon", id: w.id, name: d.name, desc: d.levelDesc[w.level - 1] + hint, level: w.level + 1, rarity: "rare", color: d.color, tag: `LV ${w.level + 1}` }, w: 1.4 });
  }
  if (g.weapons.length < MAX_SLOTS) {
    for (const id of availableWeapons(g)) {
      const d = WEAPONS[id];
      pool.push({ c: { kind: "newWeapon", id, name: d.name, desc: d.desc, level: 1, rarity: "epic", color: d.color, tag: "NEW WEAPON" }, w: g.weapons.length < 3 ? 1.6 : 0.8 });
    }
  }
  const owned = PASSIVE_IDS.filter((id) => (g.passives[id] ?? 0) > 0);
  for (const id of owned) {
    const lv = g.passives[id] ?? 0;
    const d = PASSIVES[id];
    if (lv >= d.max) continue;
    pool.push({ c: { kind: "passive", id, name: d.name, desc: d.desc, level: lv + 1, rarity: "common", color: d.color, tag: `${d.category} · LV ${lv + 1}` }, w: 1.1 });
  }
  if (owned.length < MAX_SLOTS) {
    for (const id of PASSIVE_IDS) {
      if (owned.includes(id)) continue;
      const d = PASSIVES[id];
      // boost passives that unlock an evolution for an owned weapon
      const helps = g.weapons.some((w) => !w.evolved && WEAPONS[w.id].evoPassive === id);
      pool.push({ c: { kind: "newPassive", id, name: d.name, desc: d.desc + (helps ? " · Enables an evolution!" : ""), level: 1, rarity: helps ? "rare" : "common", color: d.color, tag: d.category }, w: helps ? 1.2 : 0.8 });
    }
  }
  const out: UpgradeChoice[] = [];
  if (evos.length) out.push(evos[0]!);
  const p2 = shuffle([...pool]);
  while (out.length < n && p2.length) {
    const pick = weighted(p2, (x) => x.w);
    out.push(pick.c);
    p2.splice(p2.indexOf(pick), 1);
  }
  if (out.length < n) out.push({ kind: "heal", id: "heal", name: "Elixir", desc: "Restore 50% health", level: 0, rarity: "common", color: "#ff6b8a", tag: "CONSUMABLE" });
  if (out.length < n) out.push({ kind: "gold", id: "gold", name: "Gold Pouch", desc: "+40 coins", level: 0, rarity: "common", color: "#ffd84a", tag: "CONSUMABLE" });
  return out;
}

export function applyChoice(g: Game, c: UpgradeChoice) {
  switch (c.kind) {
    case "evolution": {
      const w = g.weapons.find((x) => x.id === c.id);
      if (w) applyEvolution(g, w);
      break;
    }
    case "weapon": {
      const w = g.weapons.find((x) => x.id === c.id);
      if (w) w.level = Math.min(MAX_WEAPON_LEVEL, w.level + 1);
      break;
    }
    case "newWeapon": addWeapon(g, c.id as WeaponId); break;
    case "passive": case "newPassive": {
      const id = c.id as PassiveId;
      g.passives[id] = Math.min(PASSIVES[id].max, (g.passives[id] ?? 0) + 1);
      g.recomputeStats();
      break;
    }
    case "heal": if (!g.chal?.noHeal) g.player.hp = Math.min(g.stats.maxHp, g.player.hp + g.stats.maxHp * 0.5); break;
    case "gold": g.coins += 40; break;
  }
}

export function applyEvolution(g: Game, w: WeaponRt) {
  if (w.evolved) return;
  w.evolved = true;
  w.timer = 0.2;
  g.evolutions++;
  const d = WEAPONS[w.id];
  const p = g.player;
  g.slowT = 0.8;
  g.flash(d.color, 0.5);
  g.shake(12);
  for (let i = 0; i < 4; i++) g.ring(p.x, p.y, 140 + i * 110, i % 2 ? "#ffffff" : d.color, 0.5 + i * 0.15, 8);
  g.burst(p.x, p.y, d.color, 70, 480, 6, 1.1);
  g.audioPlay("evolve");
  g.banner({ text: d.evoName, sub: `${d.name} has evolved!`, kind: "evolve" });
}
