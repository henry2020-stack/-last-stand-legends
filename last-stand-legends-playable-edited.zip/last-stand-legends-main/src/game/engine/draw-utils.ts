const rgbCache = new Map<string, [number, number, number]>();
export function hexRgb(hex: string): [number, number, number] {
  let c = rgbCache.get(hex);
  if (c) return c;
  const h = hex.replace("#", "");
  const n = parseInt(h.length === 3 ? h.split("").map((x) => x + x).join("") : h, 16);
  c = [(n >> 16) & 255, (n >> 8) & 255, n & 255];
  rgbCache.set(hex, c);
  return c;
}
const rgbaCache = new Map<string, string>();
export function rgba(hex: string, a: number): string {
  const q = Math.round(a * 20) / 20;
  const k = hex + q;
  let s = rgbaCache.get(k);
  if (s) return s;
  const [r, g, b] = hexRgb(hex);
  s = `rgba(${r},${g},${b},${q})`;
  rgbaCache.set(k, s);
  return s;
}

const glowCache = new Map<string, HTMLCanvasElement>();
/** Pre-rendered radial glow sprite, drawn additively — far cheaper than shadowBlur. */
export function glow(color: string): HTMLCanvasElement {
  let c = glowCache.get(color);
  if (c) return c;
  c = document.createElement("canvas");
  c.width = c.height = 64;
  const x = c.getContext("2d")!;
  const gr = x.createRadialGradient(32, 32, 0, 32, 32, 32);
  gr.addColorStop(0, rgba(color, 1));
  gr.addColorStop(0.25, rgba(color, 0.6));
  gr.addColorStop(0.6, rgba(color, 0.15));
  gr.addColorStop(1, rgba(color, 0));
  x.fillStyle = gr;
  x.fillRect(0, 0, 64, 64);
  glowCache.set(color, c);
  return c;
}
export function drawGlow(ctx: CanvasRenderingContext2D, color: string, x: number, y: number, r: number) {
  ctx.drawImage(glow(color), x - r, y - r, r * 2, r * 2);
}
