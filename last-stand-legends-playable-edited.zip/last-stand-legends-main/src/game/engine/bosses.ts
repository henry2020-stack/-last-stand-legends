import { TAU, angleDiff, rand, segDist2 } from "../core/math";
import type { AttackId } from "../data/bosses";
import type { EnemyId } from "../data/enemies";
import type { Game } from "./game";
import type { Enemy, EProj } from "./types";

const PROJ_COLOR: Record<string, string> = { poison: "#9dff6a", fire: "#ff6a2a", bone: "#e8f4ff", missile: "#ff3a2a", void: "#c27bff" };
const PROJ_EFFECT: Record<string, 0 | 1 | 2 | 3> = { poison: 2, fire: 3, bone: 1, missile: 0, void: 0 };

function shoot(g: Game, b: Enemy, ang: number, speed: number, dmgMul = 0.7, r = 10) {
  const def = b.boss!.def;
  const kind: EProj["kind"] = def.proj === "missile" ? "missile" : def.proj === "bone" ? "bone" : def.proj === "void" ? "void" : def.proj === "fire" ? "fire" : "poison";
  return g.fireEProj(kind, b.x + Math.cos(ang) * b.r * 0.6, b.y + Math.sin(ang) * b.r * 0.6, ang, speed, b.dmg * dmgMul, PROJ_COLOR[def.proj]!, PROJ_EFFECT[def.proj]!, r, 6);
}

const DURATION: Record<AttackId, number> = {
  radial: 1.4, spiral: 3, volley: 1.4, charge: 1.6, slam: 1.6, summon: 1.2, laser: 3.2,
  puddles: 1.2, teleport: 1.5, meteors: 1.8, ring: 2.6, gravity: 3.5,
};

export function updateBoss(g: Game, e: Enemy, dt: number) {
  const b = e.boss!;
  const p = g.player;
  e.t += dt;
  if (e.spawnT > 0) e.spawnT -= dt;
  if (e.slowT > 0) { e.slowT -= dt; if (e.slowT <= 0) e.slowAmt = 0; }
  if (e.burnT > 0 || e.poisonT > 0) {
    e.dotTick -= dt;
    if (e.dotTick <= 0) {
      e.dotTick = 0.5;
      if (e.burnT > 0) g.damageEnemy(e, e.burnDps * 0.5, "fire", "dragon", { noCrit: true, silent: true });
      if (e.poisonT > 0) g.damageEnemy(e, e.poisonDps * 0.5, "poison", "poison", { noCrit: true, silent: true });
    }
    e.burnT -= dt; e.poisonT -= dt;
  }
  if (e.dead) return;
  const sm = 1 - e.slowAmt * 0.6;
  const dx = p.x - e.x, dy = p.y - e.y, d = Math.hypot(dx, dy) || 1;
  const toP = Math.atan2(dy, dx);
  // phase transitions
  const frac = e.hp / e.maxHp;
  const want = frac < 0.33 ? 2 : frac < 0.66 ? 1 : 0;
  if (want > b.phase) {
    b.phase = want;
    b.atk = null;
    b.cd = 1.4;
    g.slowT = 0.6;
    g.shake(16);
    g.flash(b.def.color, 0.4);
    g.ring(e.x, e.y, 400, b.def.color, 0.8, 12);
    g.audioPlay("roar");
    g.banner({ text: want === 2 ? "Final Phase" : "Phase 2", sub: `${b.def.name} grows furious!`, kind: "warning" });
    g.eprojs.clear();
    // knock player back a bit
    p.vx += (dx / d) * 500; p.vy += (dy / d) * 500;
  }
  const speedMul = 1 + b.phase * 0.18;
  if (!b.atk) {
    // reposition toward a comfortable distance
    const desired = 260;
    const tx = d > desired ? p.x : e.x - dx;
    const ty = d > desired ? p.y : e.y - dy;
    const ddx = tx - e.x, ddy = ty - e.y, dl = Math.hypot(ddx, ddy) || 1;
    e.vx += ((ddx / dl) * e.speed * speedMul - e.vx) * Math.min(1, dt * 3);
    e.vy += ((ddy / dl) * e.speed * speedMul - e.vy) * Math.min(1, dt * 3);
    e.facing = toP;
    b.cd -= dt;
    if (b.cd <= 0) {
      const list = b.def.phases[b.phase]!;
      let next = list[Math.floor(Math.random() * list.length)]!;
      if (next === b.last && list.length > 1) next = list[(list.indexOf(next) + 1) % list.length]!;
      b.atk = next; b.last = next; b.atkT = 0; b.atkStep = 0;
      b.ang = toP;
    }
  } else {
    e.vx *= Math.exp(-4 * dt); e.vy *= Math.exp(-4 * dt);
    runAttack(g, e, dt, toP, d);
    b.atkT += dt;
    if (b.atk && b.atkT >= DURATION[b.atk] && b.atk !== "charge" && b.atk !== "laser") endAttack(e);
  }
  e.x += (e.vx * sm + e.kx) * dt;
  e.y += (e.vy * sm + e.ky) * dt;
  e.kx *= Math.exp(-6 * dt); e.ky *= Math.exp(-6 * dt);
  // contact damage handled by Game.separate
}

function endAttack(e: Enemy) {
  const b = e.boss!;
  b.atk = null;
  b.cd = Math.max(0.5, rand(1.2, 1.9) - b.phase * 0.35);
}

function runAttack(g: Game, e: Enemy, dt: number, toP: number, dist: number) {
  const b = e.boss!;
  const p = g.player;
  const t = b.atkT;
  const ph = b.phase;
  const step = (at: number) => { if (b.atkStep === at && t >= 0) { return true; } return false; };
  switch (b.atk) {
    case "radial": {
      const waves = 2 + ph;
      const k = Math.floor(t / 0.4);
      if (k > b.atkStep - 1 && b.atkStep < waves && t >= b.atkStep * 0.4) {
        const n = 16 + ph * 6;
        const off = b.atkStep * (Math.PI / n);
        for (let i = 0; i < n; i++) shoot(g, e, (i / n) * TAU + off, 190 + ph * 25);
        b.atkStep++;
        g.audioPlay("enemyShot", 0.8, 0.6);
        g.ring(e.x, e.y, e.r * 2, b.def.color, 0.3, 4);
      }
      break;
    }
    case "spiral": {
      b.ang += dt * (2.2 + ph * 0.5);
      if (t - b.atkStep * 0.07 >= 0) {
        b.atkStep++;
        const arms = 3 + ph;
        for (let i = 0; i < arms; i++) shoot(g, e, b.ang + (i / arms) * TAU, 210, 0.55, 8);
        if (b.atkStep % 3 === 0) g.audioPlay("enemyShot", 0.4, 0.9);
      }
      break;
    }
    case "volley": {
      const shots = 3 + ph;
      if (b.atkStep < shots && t >= b.atkStep * 0.35) {
        const lead = Math.atan2(p.y + p.vy * 0.3 - e.y, p.x + p.vx * 0.3 - e.x);
        const n = 5 + ph * 2;
        for (let i = 0; i < n; i++) shoot(g, e, lead + (i - (n - 1) / 2) * 0.16, 330 + ph * 40, 0.7, 9);
        b.atkStep++;
        g.audioPlay("enemyShot", 0.7, 0.8);
      }
      break;
    }
    case "charge": {
      // st 0: telegraph, 1: dash, 2: recover
      if (b.atkStep === 0) {
        b.ang = toP;
        b.dirX = Math.cos(toP); b.dirY = Math.sin(toP);
        b.atkStep = 1;
        g.audioPlay("warn", 0.6);
      }
      if (b.atkStep === 1 && t < 0.75) {
        // aim tracks for first half
        if (t < 0.4) { b.ang = toP; b.dirX = Math.cos(toP); b.dirY = Math.sin(toP); }
      } else if (b.atkStep === 1) {
        b.atkStep = 2;
        g.audioPlay("roar", 0.5);
      }
      if (b.atkStep === 2) {
        const sp = 900 + ph * 120;
        e.vx = b.dirX * sp; e.vy = b.dirY * sp;
        g.particle(e.x + rand(-e.r, e.r), e.y + rand(-e.r, e.r), 0, 0, b.def.color, 0.5, 14, 0);
        if (Math.random() < 0.3 && b.def.proj === "fire") g.addZone("burn", e.x, e.y, 30, { life: 0.1, color: "#ff5a1a" });
        if (t > 1.3 || (g.arena && Math.hypot(e.x - g.arena.x, e.y - g.arena.y) > g.arena.r + 40)) {
          b.atkStep = 3;
          e.vx *= 0.1; e.vy *= 0.1;
          g.shake(10);
          if (ph >= 1) for (let i = 0; i < 12; i++) shoot(g, e, (i / 12) * TAU, 220);
        }
      }
      if (b.atkStep === 3 && t > 1.7) {
        if (ph >= 2 && b.enraged === false) { b.enraged = true; b.atkT = 0; b.atkStep = 0; }
        else { b.enraged = false; endAttack(e); }
      }
      break;
    }
    case "slam": {
      if (b.atkStep === 0) {
        const n = 3 + ph * 2;
        for (let i = 0; i < n; i++) {
          const ox = i === 0 ? p.x : p.x + rand(-220, 220), oy = i === 0 ? p.y : p.y + rand(-220, 220);
          g.addZone("telegraph", ox, oy, 95, { delay: 1 + i * 0.08, dmg: e.dmg, color: b.def.color, src: "enemy" });
        }
        b.atkStep = 1;
        g.audioPlay("warn", 0.6);
      }
      break;
    }
    case "meteors": {
      if (b.atkStep < 10 + ph * 4 && t >= b.atkStep * 0.1) {
        g.addZone("eruption", p.x + rand(-300, 300), p.y + rand(-300, 300), 80, { delay: 1.1, dmg: e.dmg * 0.9, color: "#ff6a2a", src: "enemy" });
        if (b.atkStep === 0) g.addZone("eruption", p.x, p.y, 80, { delay: 1.2, dmg: e.dmg * 0.9, color: "#ff6a2a", src: "enemy" });
        b.atkStep++;
      }
      break;
    }
    case "summon": {
      if (b.atkStep === 0) {
        const pool: EnemyId[] = b.def.id === "plague_queen" ? ["bug", "slime"] : b.def.id === "bone_king" ? ["zombie", "phantom"] : b.def.id === "destroyer" ? ["exploder", "knight"] : b.def.id === "void_titan" ? ["stalker", "phantom"] : ["demon", "exploder"];
        const n = 6 + ph * 3;
        for (let i = 0; i < n; i++) {
          const a = (i / n) * TAU;
          const id = pool[i % pool.length]!;
          g.addZone("summon", e.x + Math.cos(a) * 110, e.y + Math.sin(a) * 110, 22, { delay: 1, color: b.def.color, src: id });
        }
        b.atkStep = 1;
        g.audioPlay("roar", 0.4);
      }
      break;
    }
    case "puddles": {
      if (b.atkStep < 5 + ph * 2 && t >= b.atkStep * 0.12) {
        const tx = p.x + rand(-200, 200), ty = p.y + rand(-200, 200);
        const dd = Math.hypot(tx - e.x, ty - e.y);
        const s = g.fireEProj("spit", e.x, e.y, Math.atan2(ty - e.y, tx - e.x), dd / 0.9, e.dmg * 0.6, "#9dff6a", 2, 12, 0.9);
        if (s) s.lob = 0.9;
        b.atkStep++;
      }
      break;
    }
    case "teleport": {
      if (b.atkStep === 0) {
        const a = rand(0, TAU);
        e.tx = p.x + Math.cos(a) * 200; e.ty = p.y + Math.sin(a) * 200;
        if (g.arena) {
          const ax = e.tx - g.arena.x, ay = e.ty - g.arena.y, ad = Math.hypot(ax, ay);
          if (ad > g.arena.r - 80) { e.tx = g.arena.x + (ax / ad) * (g.arena.r - 80); e.ty = g.arena.y + (ay / ad) * (g.arena.r - 80); }
        }
        g.addZone("telegraph", e.tx, e.ty, e.r + 30, { delay: 0.7, dmg: e.dmg, color: b.def.color, src: "enemy" });
        e.invuln = true;
        b.atkStep = 1;
      }
      if (b.atkStep === 1) { if (Math.random() < 0.8) g.particle(e.x + rand(-e.r, e.r), e.y + rand(-e.r, e.r), 0, -80, b.def.color, 0.5, 10, 0); }
      if (b.atkStep === 1 && t > 0.7) {
        g.burst(e.x, e.y, b.def.color, 30, 300, 6, 0.5);
        e.x = e.tx; e.y = e.ty;
        e.invuln = false;
        g.burst(e.x, e.y, b.def.color, 30, 300, 6, 0.5);
        const n = 12 + ph * 4;
        for (let i = 0; i < n; i++) shoot(g, e, (i / n) * TAU, 200);
        b.atkStep = 2;
        g.shake(8);
      }
      break;
    }
    case "ring": {
      if (b.atkStep === 0) {
        const n = 34;
        const gap = rand(0, TAU);
        const R = 360;
        for (let i = 0; i < n; i++) {
          const a = (i / n) * TAU;
          if (Math.abs(angleDiff(a, gap)) < 0.38) continue;
          const x = p.x + Math.cos(a) * R, y = p.y + Math.sin(a) * R;
          const pr = g.fireEProj(b.def.proj === "bone" ? "bone" : "orb", x, y, a + Math.PI, 0, e.dmg * 0.6, PROJ_COLOR[b.def.proj]!, 0, 10, 3.2);
          if (pr) { pr.accel = 150; pr.vx = Math.cos(a + Math.PI) * 30; pr.vy = Math.sin(a + Math.PI) * 30; }
        }
        b.atkStep = 1;
        g.audioPlay("warn", 0.5);
      }
      break;
    }
    case "gravity": {
      if (b.atkStep === 0) {
        g.addZone("gravity", e.x, e.y, 520, { life: 3.4, a: 150 + ph * 30, dmg: e.dmg, tick: 0.5, color: "#c27bff", src: "enemy" });
        b.atkStep = 1;
      }
      if (t - b.atkStep * 0.6 >= 0 && b.atkStep < 6) {
        b.atkStep++;
        const n = 10;
        for (let i = 0; i < n; i++) shoot(g, e, (i / n) * TAU + t, 170, 0.5);
      }
      break;
    }
    case "laser": {
      // atkStep 0 aim, 1 telegraph, 2 firing
      const beams = ph >= 2 ? 2 : 1;
      if (b.atkStep === 0) { b.ang = toP; b.atkStep = 1; g.audioPlay("warn", 0.7); }
      if (b.atkStep === 1) {
        b.ang += Math.max(-dt * 1.5, Math.min(dt * 1.5, angleDiff(b.ang, toP)));
        if (t > 1.0) { b.atkStep = 2; g.audioPlay("beam", 1, 0.5); g.shake(6); }
      } else if (b.atkStep === 2) {
        const turn = (0.55 + ph * 0.15) * dt;
        b.ang += Math.max(-turn, Math.min(turn, angleDiff(b.ang, toP)));
        const len = 1200, w = 26;
        for (let k = 0; k < beams; k++) {
          const a = b.ang + k * Math.PI;
          const ex = e.x + Math.cos(a) * len, ey = e.y + Math.sin(a) * len;
          if (segDist2(p.x, p.y, e.x, e.y, ex, ey) < (w + p.r - 4) ** 2) g.hurtPlayer(e.dmg * 0.9, e.x, e.y);
          if (Math.random() < 0.5) {
            const tt = Math.random();
            g.particle(e.x + Math.cos(a) * len * tt, e.y + Math.sin(a) * len * tt, rand(-60, 60), rand(-60, 60), b.def.color, 0.4, 6, 0);
          }
        }
        if (Math.floor(t * 10) % 2 === 0) g.audioPlay("beam", 0.4, 0.5);
        if (t > 3.2) endAttack(e);
      }
      break;
    }
    default: break;
  }
  void step; void dist;
}
