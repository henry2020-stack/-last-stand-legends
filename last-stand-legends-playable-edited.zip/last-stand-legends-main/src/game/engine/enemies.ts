import { TAU, angleDiff, dist2, lerp, rand } from "../core/math";
import type { EnemyId } from "../data/enemies";
import type { Game } from "./game";
import type { Enemy } from "./types";

function steer(e: Enemy, tx: number, ty: number, speed: number, dt: number, resp = 5) {
  const dx = tx - e.x, dy = ty - e.y, d = Math.hypot(dx, dy) || 1;
  const k = 1 - Math.exp(-resp * dt);
  e.vx = lerp(e.vx, (dx / d) * speed, k);
  e.vy = lerp(e.vy, (dy / d) * speed, k);
}

/** Common status handling. Returns movement multiplier (0 when frozen). */
function statuses(g: Game, e: Enemy, dt: number): number {
  e.t += dt;
  if (e.spawnT > 0) e.spawnT -= dt;
  if (e.burnT > 0 || e.poisonT > 0) {
    e.dotTick -= dt;
    if (e.dotTick <= 0) {
      e.dotTick = 0.5;
      if (e.burnT > 0) g.damageEnemy(e, e.burnDps * 0.5, "fire", "dragon", { noCrit: true, silent: Math.random() < 0.5 });
      if (e.poisonT > 0 && !e.dead) g.damageEnemy(e, e.poisonDps * 0.5, "poison", "poison", { noCrit: true, silent: Math.random() < 0.5 });
      if (e.burnT > 0 && Math.random() < 0.8) g.particle(e.x + rand(-6, 6), e.y - e.r * 0.5, 0, -60, "#ff8a2a", 0.4, 6, 0);
    }
    e.burnT -= dt;
    e.poisonT -= dt;
    if (e.burnT <= 0) e.burnDps = 0;
    if (e.poisonT <= 0) e.poisonDps = 0;
  }
  if (e.slowT > 0) { e.slowT -= dt; if (e.slowT <= 0) e.slowAmt = 0; }
  if (e.freezeT > 0) { e.freezeT -= dt; return 0; }
  return 1 - e.slowAmt;
}

function integrate(e: Enemy, dt: number, sm: number) {
  e.x += (e.vx * sm + e.kx) * dt;
  e.y += (e.vy * sm + e.ky) * dt;
  const k = Math.exp(-9 * dt);
  e.kx *= k; e.ky *= k;
}

export function updateEnemy(g: Game, e: Enemy, dt: number) {
  const sm = statuses(g, e, dt);
  if (e.dead) return;
  const p = g.player;
  const dx = p.x - e.x, dy = p.y - e.y;
  const d = Math.hypot(dx, dy) || 1;
  const toP = Math.atan2(dy, dx);
  if (sm === 0) { integrate(e, dt, 0); return; }
  e.cd -= dt * sm;
  e.cd2 -= dt * sm;
  const type = e.type as EnemyId;
  switch (type) {
    case "zombie": {
      const wob = Math.sin(e.t * 3 + e.id) * 0.35;
      const a = toP + wob;
      steer(e, e.x + Math.cos(a) * 100, e.y + Math.sin(a) * 100, e.speed, dt, 6);
      e.facing = toP;
      break;
    }
    case "bug": {
      const a = toP + Math.sin(e.t * 9 + e.id * 1.7) * 0.6;
      steer(e, e.x + Math.cos(a) * 100, e.y + Math.sin(a) * 100, e.speed, dt, 8);
      e.facing = Math.atan2(e.vy, e.vx);
      break;
    }
    case "bat": {
      const a = toP + Math.sin(e.t * 2.3 + e.id) * 1.1 + Math.sin(e.t * 5.1 + e.id * 3) * 0.4;
      steer(e, e.x + Math.cos(a) * 100, e.y + Math.sin(a) * 100, e.speed * (0.8 + 0.4 * Math.sin(e.t * 4 + e.id)), dt, 4);
      e.facing = Math.atan2(e.vy, e.vx);
      break;
    }
    case "brute": {
      if (e.st === 0) {
        steer(e, p.x, p.y, e.speed, dt, 3);
        e.facing = toP;
        if (d < 130 && e.cd <= 0) {
          e.st = 1; e.stT = 0.85; e.vx = e.vy = 0;
          g.addZone("telegraph", e.x + (dx / d) * 30, e.y + (dy / d) * 30, 115, { delay: 0.85, dmg: e.dmg * 1.3, color: "#ff5a3a", src: "enemy" });
        }
      } else {
        e.stT -= dt;
        e.vx *= 0.8; e.vy *= 0.8;
        if (e.stT <= 0) { e.st = 0; e.cd = 3.6; }
      }
      break;
    }
    case "slime": {
      const hop = Math.max(0, Math.sin(e.t * 4 + e.id));
      steer(e, p.x, p.y, e.speed * (0.3 + hop * 1.3), dt, 6);
      if (e.cd <= 0 && !e.mini) {
        e.cd = 2.6;
        g.addZone("puddle", e.x, e.y, 32, { life: 4.5, dmg: e.dmg * 0.4, tick: 0.5, color: "#7dff4a", src: "enemy" });
      }
      break;
    }
    case "stalker": {
      if (e.st === 0) {
        steer(e, p.x, p.y, e.speed, dt, 5);
        if (e.cd <= 0 && d > 140 && d < 700) {
          e.st = 1; e.stT = 0.65;
          const a = toP + Math.PI + rand(-0.9, 0.9);
          const rr = rand(90, 130);
          e.tx = p.x + Math.cos(a) * rr; e.ty = p.y + Math.sin(a) * rr;
        }
      } else {
        e.stT -= dt;
        e.vx *= 0.85; e.vy *= 0.85;
        if (Math.random() < 0.6) g.particle(e.tx + rand(-14, 14), e.ty + rand(-14, 14), 0, -40, "#8a5aff", 0.4, 5, 0);
        if (e.stT <= 0) {
          g.burst(e.x, e.y, "#4b2a7a", 12, 180, 4, 0.4);
          e.x = e.tx; e.y = e.ty;
          g.burst(e.x, e.y, "#a87aff", 14, 200, 4, 0.4);
          e.st = 0; e.cd = rand(4, 5.5); e.spawnT = 0.2;
        }
      }
      break;
    }
    case "exploder": {
      if (e.st === 0) {
        steer(e, p.x, p.y, e.speed, dt, 6);
        if (d < 65) { e.st = 1; e.stT = 0.8; g.audioPlay("warn", 0.4); }
      } else {
        e.vx *= 0.85; e.vy *= 0.85;
        e.stT -= dt;
        if (e.stT <= 0) { e.hp = 0; g.killEnemy(e, "self"); }
      }
      break;
    }
    case "knight": {
      const turn = 1.8 * dt;
      e.facing += Math.max(-turn, Math.min(turn, angleDiff(e.facing, toP)));
      steer(e, e.x + Math.cos(e.facing) * 100, e.y + Math.sin(e.facing) * 100, e.speed, dt, 4);
      break;
    }
    case "demon": {
      e.facing = toP;
      const perp = toP + Math.PI / 2 * (e.id % 2 ? 1 : -1);
      if (d > 380) steer(e, p.x, p.y, e.speed, dt, 3);
      else if (d < 260) steer(e, e.x - dx, e.y - dy, e.speed, dt, 3);
      else steer(e, e.x + Math.cos(perp) * 100, e.y + Math.sin(perp) * 100, e.speed * 0.7, dt, 2);
      if (e.st === 0 && e.cd <= 0 && d < 560) { e.st = 1; e.stT = 0.4; }
      if (e.st === 1) {
        e.stT -= dt;
        if (e.stT <= 0) {
          e.st = 0; e.cd = rand(2, 2.8);
          g.fireEProj("fire", e.x, e.y, toP, 250, e.dmg, "#ff6a2a", 3, 9, 3.5);
          g.audioPlay("enemyShot", 0.5, 0.8);
        }
      }
      break;
    }
    case "icemonster": {
      steer(e, p.x, p.y, e.speed, dt, 3);
      e.facing = toP;
      if (d < 140) { p.slowT = Math.max(p.slowT, 0.15); p.slowAmt = Math.max(p.slowAmt, 0.3); }
      if (e.cd <= 0 && d < 480) {
        e.cd = rand(3.2, 4);
        for (let i = -1; i <= 1; i++) g.fireEProj("frost", e.x, e.y, toP + i * 0.25, 230, e.dmg * 0.8, "#9be7ff", 1, 7, 3);
        g.audioPlay("ice", 0.4, 0.7);
      }
      break;
    }
    case "spider": {
      e.facing = toP;
      const burst = Math.sin(e.t * 6 + e.id) > 0.2 ? 1.3 : 0.2;
      if (d > 300) steer(e, p.x, p.y, e.speed * burst, dt, 6);
      else if (d < 200) steer(e, e.x - dx, e.y - dy, e.speed * burst, dt, 6);
      else { const a = toP + Math.PI / 2; steer(e, e.x + Math.cos(a) * 100, e.y + Math.sin(a) * 100, e.speed * burst * 0.8, dt, 6); }
      if (e.cd <= 0 && d < 420) {
        e.cd = rand(2.6, 3.4);
        const tx = p.x + p.vx * 0.5, ty = p.y + p.vy * 0.5;
        const dd = Math.hypot(tx - e.x, ty - e.y);
        const t = 0.8;
        const s = g.fireEProj("spit", e.x, e.y, Math.atan2(ty - e.y, tx - e.x), dd / t, e.dmg, "#9dff6a", 2, 8, t);
        if (s) s.lob = t;
        g.audioPlay("enemyShot", 0.4, 1.4);
      }
      break;
    }
    case "mage": {
      e.facing = toP;
      if (d > 360) steer(e, p.x, p.y, e.speed, dt, 3);
      else if (d < 240) steer(e, e.x - dx, e.y - dy, e.speed * 1.3, dt, 3);
      else { e.vx *= 0.9; e.vy *= 0.9; }
      if (e.cd <= 0 && d < 650 && g.enemies.length < 380) {
        e.cd = rand(5.5, 7);
        const pool: EnemyId[] = g.map.enemies.filter((x) => x === "zombie" || x === "bat" || x === "bug" || x === "stalker" || x === "phantom");
        const kind = pool[Math.floor(Math.random() * pool.length)] ?? "zombie";
        for (let i = 0; i < 3; i++) {
          const a = (i / 3) * TAU + e.t;
          g.addZone("summon", e.x + Math.cos(a) * 50, e.y + Math.sin(a) * 50, 22, { delay: 1, color: "#ff5ad0", src: kind });
        }
      }
      break;
    }
    case "phantom": {
      e.cd2 -= 0;
      if (!e.invuln && e.cd <= 0) { e.invuln = true; e.stT = 1.5; }
      if (e.invuln) { e.stT -= dt; if (e.stT <= 0) { e.invuln = false; e.cd = rand(3, 4.5); } }
      const a = toP + Math.sin(e.t * 2 + e.id) * 0.5;
      steer(e, e.x + Math.cos(a) * 100, e.y + Math.sin(a) * 100, e.speed * (e.invuln ? 1.6 : 1), dt, 4);
      e.facing = toP;
      break;
    }
    case "hunter": {
      if (e.st === 0) {
        const tx = p.x + p.vx * 0.6, ty = p.y + p.vy * 0.6;
        steer(e, tx, ty, e.speed, dt, 5);
        e.facing = Math.atan2(ty - e.y, tx - e.x);
        if (d < 320 && e.cd <= 0) {
          e.st = 1; e.stT = 0.6;
          const lx = p.x + p.vx * 0.35, ly = p.y + p.vy * 0.35;
          e.facing = Math.atan2(ly - e.y, lx - e.x);
        }
      } else if (e.st === 1) {
        e.stT -= dt;
        e.vx *= 0.8; e.vy *= 0.8;
        if (e.stT <= 0) { e.st = 2; e.stT = 0.42; e.vx = Math.cos(e.facing) * 680; e.vy = Math.sin(e.facing) * 680; g.audioPlay("dash", 0.5, 1.4); }
      } else if (e.st === 2) {
        e.stT -= dt;
        if (Math.random() < 0.7) g.particle(e.x, e.y, 0, 0, "#d62a3a", 0.3, 8, 0);
        if (e.stT <= 0) { e.st = 3; e.stT = 0.5; }
      } else {
        e.stT -= dt;
        e.vx *= 0.88; e.vy *= 0.88;
        if (e.stT <= 0) { e.st = 0; e.cd = rand(2.4, 3.2); }
      }
      if (e.st === 2) { e.x += e.kx * dt; e.y += e.ky * dt; e.x += e.vx * dt; e.y += e.vy * dt; e.kx *= 0.9; e.ky *= 0.9; return; }
      break;
    }
    case "guardian": {
      steer(e, p.x, p.y, e.speed, dt, 2);
      e.facing = toP;
      if (e.cd <= 0) {
        e.cd = 3.2;
        e.st = (e.st + 1) % 2;
        if (e.st === 0) {
          const n = 14;
          for (let i = 0; i < n; i++) g.fireEProj("orb", e.x, e.y, (i / n) * TAU + e.t, 170, e.dmg * 0.7, "#5affd6", 0, 9, 5);
          g.audioPlay("enemyShot", 0.7, 0.6);
        } else {
          g.addZone("telegraph", e.x, e.y, 175, { delay: 1.1, dmg: e.dmg, color: "#5affd6", src: "enemy" });
        }
      }
      break;
    }
  }
  integrate(e, dt, sm);
}

export { dist2 };
