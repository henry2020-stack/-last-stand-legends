import { audio } from "../core/audio";
import { Input } from "../core/input";
import { Pool } from "../core/pool";
import { TAU, clamp, dist2, lerp, rand, randInt, shuffle, weighted, chance } from "../core/math";
import { BOSSES, BOSS_IDS, type BossId } from "../data/bosses";
import { CHARACTERS, type CharacterDef } from "../data/characters";
import type { DamageType } from "../data/common";
import { DAMAGE_COLORS } from "../data/common";
import { ENEMIES, type EnemyId } from "../data/enemies";
import { MAPS, type MapDef } from "../data/maps";
import { CHALLENGES, CHALLENGE_DURATION, CLASSIC_DURATION, DIFFICULTIES, MODES, type ChallengeDef, type DifficultyDef } from "../data/modes";
import { PASSIVES, type PassiveId } from "../data/passives";
import { WEAPONS, type WeaponId } from "../data/weapons";
import type { GameConfigInput } from "./config";
import { useAbility } from "./abilities";
import { updateBoss } from "./bosses";
import { updateEnemy } from "./enemies";
import { render } from "./render";
import { genChoices, applyChoice, evolutionsAvailable, applyEvolution } from "./upgrades";
import { updateWeapons, updateProjectiles, addWeapon } from "./weapons";
import { updateHazards } from "./world";
import type {
  Banner, Bolt, DmgText, EProj, Enemy, HudSnapshot, Particle, Pickup, PickupKind, Player, Proj, Ring, Stats,
  UpgradeChoice, WeaponRt, Zone, ZoneKind,
} from "./types";
import type { RunResult } from "../save";

export interface GameCallbacks {
  onLevelUp: (choices: UpgradeChoice[] | null) => void;
  onHud: (h: HudSnapshot) => void;
  onBanner: (b: Banner) => void;
  onPause: (paused: boolean) => void;
  onEnd: (r: RunResult) => void;
}

export type GameState = "playing" | "levelup" | "paused" | "over";

const makeProj = (): Proj => ({ alive: false, kind: "dagger", x: 0, y: 0, vx: 0, vy: 0, r: 0, dmg: 0, dtype: "physical", pierce: 0, life: 0, max: 0, color: "#fff", src: "plasma", hits: new Set(), t: 0, a: 0, b: 0, st: 0, target: null, evo: false });
const makeEProj = (): EProj => ({ alive: false, kind: "fire", x: 0, y: 0, vx: 0, vy: 0, r: 0, dmg: 0, life: 0, color: "#fff", effect: 0, t: 0, accel: 0, tx: 0, ty: 0, lob: 0 });
const makePart = (): Particle => ({ alive: false, x: 0, y: 0, vx: 0, vy: 0, life: 0, max: 0, size: 0, color: "#fff", kind: 0, drag: 0, grav: 0, rot: 0 });
const makeText = (): DmgText => ({ alive: false, x: 0, y: 0, vy: 0, life: 0, max: 0, text: "", color: "#fff", size: 14 });

export const xpFor = (level: number) => Math.floor(6 + (level - 1) * 7 + Math.pow(level - 1, 2) * 0.32);

/** Spatial hash grid for fast enemy neighbourhood queries. */
class Grid {
  private cells = new Map<number, Enemy[]>();
  constructor(private size: number) {}
  private key(cx: number, cy: number) { return (cx + 4096) * 8192 + (cy + 4096); }
  build(list: Enemy[]) {
    for (const arr of this.cells.values()) arr.length = 0;
    for (const e of list) {
      if (e.dead) continue;
      const k = this.key(Math.floor(e.x / this.size), Math.floor(e.y / this.size));
      let a = this.cells.get(k);
      if (!a) { a = []; this.cells.set(k, a); }
      a.push(e);
    }
    if (this.cells.size > 3000) for (const [k, a] of this.cells) if (!a.length) this.cells.delete(k);
  }
  query(x: number, y: number, r: number, out: Enemy[]): Enemy[] {
    out.length = 0;
    const s = this.size;
    const x0 = Math.floor((x - r) / s), x1 = Math.floor((x + r) / s);
    const y0 = Math.floor((y - r) / s), y1 = Math.floor((y + r) / s);
    for (let cx = x0; cx <= x1; cx++) for (let cy = y0; cy <= y1; cy++) {
      const a = this.cells.get(this.key(cx, cy));
      if (a) for (const e of a) out.push(e);
    }
    return out;
  }
}

const SPAWN_WEIGHT: Partial<Record<EnemyId, number>> = { zombie: 3, bat: 2, bug: 0.9, brute: 0.45, hunter: 0.22, mage: 0.4, knight: 0.8, exploder: 0.9 };

export class Game {
  canvas: HTMLCanvasElement;
  ctx: CanvasRenderingContext2D;
  w = 0; h = 0; dpr = 1; zoom = 1;
  input = new Input();
  cfg: GameConfigInput;
  cb: GameCallbacks;
  map: MapDef; char: CharacterDef; diff: DifficultyDef; chal: ChallengeDef | null;
  state: GameState = "playing";
  time = 0; realT = 0; slowT = 0; timeScale = 1;
  camX = 0; camY = 0; shakeMag = 0; shakeX = 0; shakeY = 0; flashT = 0; flashColor = "#ffffff";
  player: Player;
  stats: Stats;
  weapons: WeaponRt[] = [];
  passives: Partial<Record<PassiveId, number>> = {};
  enemies: Enemy[] = [];
  grid = new Grid(96);
  qbuf: Enemy[] = [];
  projs = new Pool<Proj>(makeProj, 1600);
  eprojs = new Pool<EProj>(makeEProj, 1400);
  parts = new Pool<Particle>(makePart, 2600);
  texts = new Pool<DmgText>(makeText, 240);
  pickups: Pickup[] = [];
  zones: Zone[] = [];
  rings: Ring[] = [];
  bolts: Bolt[] = [];
  boss: Enemy | null = null;
  arena: { x: number; y: number; r: number; t: number } | null = null;
  intro: { t: number; max: number; x: number; y: number } | null = null;
  level = 1; xp = 0; xpNext = xpFor(1); pendingLevels = 0;
  kills = 0; coins = 0; rerolls = 0; revives = 0; evolutions = 0;
  bossesKilled: BossId[] = [];
  weaponDmg = new Map<string, number>();
  choices: UpgradeChoice[] = [];
  spawnAcc = 0; nextHorde = 60; nextElite = 100;
  events: { at: number; fn: () => void; done: boolean }[] = [];
  bossQueue: BossId[] = []; rushIndex = 0; rushBreak = -1;
  abilityCd = 2; dashCd = 0;
  aimAngle = 0; aimX = 0; aimY = 0;
  onIce = false; blackoutT = 0; hazardT = 4; hazardText: string | null = null;
  nextId = 1;
  private raf = 0; private lastFrame = 0; private hudT = 0;
  ended = false; won = false;
  fps = 60;

  constructor(canvas: HTMLCanvasElement, cfg: GameConfigInput, cb: GameCallbacks) {
    this.canvas = canvas;
    this.ctx = canvas.getContext("2d", { alpha: false })!;
    this.cfg = cfg;
    this.cb = cb;
    this.map = MAPS[cfg.map];
    this.char = CHARACTERS[cfg.char];
    this.diff = DIFFICULTIES[cfg.difficulty];
    this.chal = cfg.mode === "challenge" ? CHALLENGES[cfg.challenge ?? "glass"] : null;
    this.player = { x: 0, y: 0, vx: 0, vy: 0, r: 13, hp: 100, facing: 0, iframes: 1, hurtT: 0, dashT: 0, dashX: 0, dashY: 0, walkT: 0, slowT: 0, slowAmt: 0, dotT: 0, dotDps: 0, dotTick: 0, dragonT: 0, hazardTick: 0 };
    this.stats = { maxHp: 100, speed: 210, armor: 0, might: 1, cdMul: 1, area: 1, crit: 0.05, critMul: 2, magnet: 90, dashCd: 2.2, dashIframe: 0.3, regen: 0, proj: 0, xpMul: 1, coinMul: 1 };
    this.recomputeStats();
    this.player.hp = this.stats.maxHp;
    this.rerolls = cfg.save.shop.reroll ?? 0;
    this.revives = cfg.save.shop.revival ?? 0;
    addWeapon(this, this.char.weapon);
    this.setupEvents();
  }

  // ---------------------------------------------------------------- lifecycle
  start() {
    this.input.attach(this.canvas);
    this.resize();
    window.addEventListener("resize", this.resize);
    document.addEventListener("visibilitychange", this.onVis);
    const a = audio();
    a.setTrack("battle", this.map.musicRoot);
    this.lastFrame = performance.now();
    this.raf = requestAnimationFrame(this.loop);
    this.banner({ text: this.map.name, sub: MODES[this.cfg.mode].goal, kind: "info" });
    if (this.cfg.mode === "bossrush") {
      this.pendingLevels = 3;
      this.openLevelUp();
    }
  }
  destroy() {
    cancelAnimationFrame(this.raf);
    this.input.detach();
    window.removeEventListener("resize", this.resize);
    document.removeEventListener("visibilitychange", this.onVis);
  }
  private onVis = () => { if (document.hidden && this.state === "playing") this.setPaused(true); };
  resize = () => {
    const c = this.canvas;
    this.w = c.clientWidth || window.innerWidth;
    this.h = c.clientHeight || window.innerHeight;
    this.dpr = Math.min(2, window.devicePixelRatio || 1);
    c.width = Math.floor(this.w * this.dpr);
    c.height = Math.floor(this.h * this.dpr);
    this.zoom = clamp(Math.min(this.w, this.h) / 760, 0.55, 1.25);
  };
  get viewW() { return this.w / this.zoom; }
  get viewH() { return this.h / this.zoom; }

  setPaused(p: boolean) {
    if (this.state === "over" || this.state === "levelup") return;
    this.state = p ? "paused" : "playing";
    this.input.clearQueued();
    this.cb.onPause(p);
  }

  private loop = (now: number) => {
    this.raf = requestAnimationFrame(this.loop);
    const dt = Math.min(0.05, (now - this.lastFrame) / 1000);
    this.lastFrame = now;
    this.fps = lerp(this.fps, 1 / Math.max(0.001, dt), 0.05);
    if (this.input.takePause()) {
      if (this.state === "playing") this.setPaused(true);
      else if (this.state === "paused") this.setPaused(false);
    }
    if (this.state === "playing") this.update(dt);
    else if (this.state === "over") this.updateEffects(dt * 0.3);
    render(this);
    this.hudT -= dt;
    if (this.hudT <= 0) {
      this.hudT = 0.1;
      this.cb.onHud(this.hud());
    }
  };

  // ---------------------------------------------------------------- stats
  recomputeStats() {
    const c = this.char.stats, sh = this.cfg.save.shop, p = (id: PassiveId) => this.passives[id] ?? 0;
    const ch = this.chal, s = this.stats;
    const oldMax = s.maxHp;
    s.maxHp = Math.round((c.hp + (sh.vitality ?? 0) * 10 + p("vitality") * 20) * (ch?.hpMul ?? 1));
    s.speed = 205 * c.speed * (1 + (sh.swift ?? 0) * 0.04 + p("swift") * 0.08) * (ch?.playerSpeed ?? 1);
    s.armor = c.armor + (sh.armor ?? 0) + p("armor");
    s.might = c.might * (1 + (sh.might ?? 0) * 0.05 + p("might") * 0.1) * (ch?.dmgMul ?? 1);
    s.cdMul = c.haste * (1 - (sh.haste ?? 0) * 0.03) * (1 - p("haste") * 0.08) * (ch?.cdMul ?? 1);
    s.area = c.area * (1 + p("area") * 0.1);
    s.crit = c.crit + (sh.crit ?? 0) * 0.03 + p("precision") * 0.05;
    s.critMul = 2 + p("precision") * 0.1;
    s.magnet = 85 * c.magnet * (1 + (sh.magnet ?? 0) * 0.15 + p("magnet") * 0.3);
    s.dashCd = 2.2 * (1 - p("reflexes") * 0.12);
    s.dashIframe = 0.3 + p("reflexes") * 0.04;
    s.regen = ch?.noHeal ? 0 : (sh.recovery ?? 0) * 0.2 + p("recovery") * 0.4;
    s.proj = c.proj + p("multishot");
    s.xpMul = (1 + (sh.growth ?? 0) * 0.06) * (1 + p("wisdom") * 0.1) * (ch?.xpMul ?? 1);
    s.coinMul = (1 + (sh.greed ?? 0) * 0.1) * this.diff.coin * (ch?.coin ?? 1);
    if (s.maxHp > oldMax && this.player) this.player.hp += s.maxHp - oldMax;
    if (this.player) this.player.hp = Math.min(this.player.hp, s.maxHp);
  }
  get minutes() { return this.time / 60; }
  hpScale() { const m = this.minutes; return 1 + 0.16 * m + 0.014 * m * m; }
  dmgScale() { return 1 + 0.07 * this.minutes; }
  hasPassive(id: PassiveId) { return (this.passives[id] ?? 0) > 0; }

  // ---------------------------------------------------------------- events / modes
  private setupEvents() {
    const mode = this.cfg.mode;
    const add = (at: number, fn: () => void) => this.events.push({ at, fn, done: false });
    const others = shuffle(BOSS_IDS.filter((b) => b !== this.map.boss));
    if (mode === "classic") {
      add(180, () => this.spawnGuardian());
      add(300, () => this.spawnBoss(others[0]!, false));
      add(480, () => this.spawnGuardian());
      add(600, () => this.spawnBoss(others[1]!, false));
      add(750, () => this.spawnGuardian());
      add(CLASSIC_DURATION - 10, () => this.banner({ text: "The Eclipse Peaks", sub: "The final boss approaches...", kind: "warning" }));
      add(CLASSIC_DURATION, () => this.spawnBoss(this.map.boss, true));
    } else if (mode === "endless") {
      const order = [this.map.boss, ...others];
      for (let i = 0; i < 40; i++) {
        add(300 * (i + 1), () => this.spawnBoss(order[i % order.length]!, false));
        add(150 + 300 * i, () => this.spawnGuardian());
      }
    } else if (mode === "challenge") {
      add(180, () => this.spawnGuardian());
      add(300, () => this.spawnBoss(this.map.boss, false));
      add(450, () => this.spawnGuardian());
      add(CHALLENGE_DURATION, () => this.victory());
    } else {
      this.bossQueue = [...others, this.map.boss];
      this.rushBreak = 5;
      this.nextHorde = 1e9;
      this.nextElite = 1e9;
    }
  }

  private updateSpawner(dt: number) {
    for (const ev of this.events) if (!ev.done && this.time >= ev.at) { ev.done = true; ev.fn(); }
    const m = this.minutes;
    const mode = this.cfg.mode;
    if (mode === "bossrush" && !this.boss && this.rushBreak >= 0) {
      this.rushBreak -= dt;
      if (this.rushBreak < 0) {
        const id = this.bossQueue[this.rushIndex];
        if (id) this.spawnBoss(id, this.rushIndex === this.bossQueue.length - 1);
      }
    }
    const spawnMul = this.chal?.spawn ?? 1;
    let rate = (1.1 + m * 0.85 + m * m * 0.035) * spawnMul;
    if (mode === "bossrush") rate = (0.8 + this.rushIndex * 0.35) * spawnMul;
    if (this.boss) rate *= 0.3;
    const cap = Math.min(420, 110 + m * 22) * (spawnMul > 1 ? 1.4 : 1);
    this.spawnAcc += rate * dt;
    while (this.spawnAcc >= 1) {
      this.spawnAcc -= 1;
      if (this.enemies.length >= cap) { this.spawnAcc = 0; break; }
      const id = this.pickEnemyType();
      const [x, y] = this.offscreenPos();
      if (id === "bug") this.spawnGroup("bug", x, y, randInt(6, 10) + Math.floor(m));
      else this.spawnEnemy(id, x, y);
    }
    if (this.time >= this.nextHorde) { this.nextHorde += 50; this.horde(); }
    if (this.time >= this.nextElite) {
      this.nextElite += 80;
      const n = 1 + Math.floor(m / 5);
      for (let i = 0; i < n; i++) { const [x, y] = this.offscreenPos(); this.spawnEnemy("hunter", x, y, { elite: true }); }
    }
  }

  private pickEnemyType(): EnemyId {
    const pool = this.map.enemies;
    const m = this.cfg.mode === "bossrush" ? 3 + this.rushIndex * 2 : this.minutes;
    const avail = Math.min(pool.length, 2 + Math.floor(m * 1.1));
    const cands = pool.slice(0, avail).filter((id) => id !== "hunter" || m > 4);
    return weighted(cands, (id) => SPAWN_WEIGHT[id] ?? 1);
  }

  offscreenPos(extra = 0): [number, number] {
    const a = rand(0, TAU);
    const d = Math.hypot(this.viewW, this.viewH) / 2 + 40 + rand(0, 90) + extra;
    return [this.player.x + Math.cos(a) * d, this.player.y + Math.sin(a) * d];
  }

  private horde() {
    const m = this.minutes;
    const kind = randInt(0, 2);
    const p = this.player;
    this.audioPlay("warn");
    if (kind === 0) {
      const n = Math.min(70, 22 + Math.floor(m * 4));
      const R = Math.hypot(this.viewW, this.viewH) / 2 + 30;
      const id: EnemyId = this.map.enemies.includes("zombie") ? "zombie" : "stalker";
      for (let i = 0; i < n; i++) { const a = (i / n) * TAU; this.spawnEnemy(id, p.x + Math.cos(a) * R, p.y + Math.sin(a) * R); }
      this.banner({ text: "Surrounded!", sub: "A horde closes in from all sides", kind: "warning" });
    } else if (kind === 1) {
      const a = rand(0, TAU);
      const R = Math.hypot(this.viewW, this.viewH) / 2 + 60;
      for (let i = 0; i < 26 + m * 3; i++) this.spawnEnemy("bat", p.x + Math.cos(a) * R + rand(-140, 140), p.y + Math.sin(a) * R + rand(-140, 140));
      this.banner({ text: "Bat Swarm!", sub: "Incoming from the darkness", kind: "warning" });
    } else {
      for (let k = 0; k < 4; k++) { const [x, y] = this.offscreenPos(); this.spawnGroup("bug", x, y, 12 + Math.floor(m * 1.5)); }
      this.banner({ text: "The Swarm Awakens", sub: "Thousands of tiny legs...", kind: "warning" });
    }
  }

  spawnGroup(id: EnemyId, x: number, y: number, n: number) {
    for (let i = 0; i < n; i++) this.spawnEnemy(id, x + rand(-50, 50), y + rand(-50, 50));
  }

  spawnEnemy(id: EnemyId, x: number, y: number, o: { elite?: boolean; summoned?: boolean; mini?: boolean } = {}): Enemy {
    const d = ENEMIES[id];
    const elite = !!o.elite;
    const mini = !!o.mini;
    const extra = this.cfg.mode === "bossrush" ? 1 + this.rushIndex * 0.5 : 1;
    const hp = d.hp * this.hpScale() * this.diff.hp * (this.chal?.enemyHp ?? 1) * (elite ? 2.2 : 1) * (mini ? 0.35 : 1) * extra;
    const e: Enemy = {
      id: this.nextId++, type: id, def: d, x, y, vx: 0, vy: 0, kx: 0, ky: 0,
      r: d.r * (elite ? 1.2 : 1) * (mini ? 0.62 : 1), hp, maxHp: hp,
      dmg: d.dmg * this.dmgScale() * this.diff.dmg * (elite ? 1.3 : 1),
      speed: d.speed * (this.chal?.enemySpeed ?? 1) * rand(0.92, 1.08) * (mini ? 1.25 : 1),
      xp: d.xp * (o.summoned ? 0.3 : 1) * (mini ? 0.4 : 1) * (elite ? 2 : 1), mass: d.mass,
      color: d.color, color2: d.color2,
      t: rand(0, 10), hitFlash: 0, facing: 0, spawnT: 0.35,
      st: 0, stT: 0, cd: rand(1, 3), cd2: rand(1, 4), tx: 0, ty: 0,
      slowT: 0, slowAmt: 0, freezeT: 0, burnT: 0, burnDps: 0, poisonT: 0, poisonDps: 0, dotTick: 0,
      invuln: false, elite, mini, summoned: !!o.summoned, dead: false,
      hitCd: new Map(), boss: null, resist: d.resist,
    };
    this.enemies.push(e);
    return e;
  }

  spawnGuardian() {
    const [x, y] = this.offscreenPos(-60);
    const g = this.spawnEnemy("guardian", x, y, { elite: false });
    g.elite = true;
    this.banner({ text: "Ancient Guardian", sub: "A colossus awakens — slay it for treasure", kind: "warning" });
    this.audioPlay("roar", 0.7);
  }

  spawnBoss(id: BossId, final: boolean) {
    const def = BOSSES[id];
    const p = this.player;
    const scale = this.cfg.mode === "bossrush" ? 1 + this.rushIndex * 0.45 : 1 + this.minutes * 0.12;
    const hp = def.hp * scale * this.diff.hp * (final ? 1.3 : 1) * (this.chal?.enemyHp ?? 1);
    const a = this.aimAngle;
    const x = p.x + Math.cos(a) * 360, y = p.y + Math.sin(a) * 360;
    const e: Enemy = {
      id: this.nextId++, type: "boss", def: null, x, y, vx: 0, vy: 0, kx: 0, ky: 0,
      r: def.r, hp, maxHp: hp, dmg: def.dmg * this.diff.dmg * (1 + this.minutes * 0.04), speed: def.speed, xp: 300, mass: 60,
      color: def.color, color2: def.color2, t: 0, hitFlash: 0, facing: 0, spawnT: 0.8,
      st: 0, stT: 0, cd: 0, cd2: 0, tx: 0, ty: 0, slowT: 0, slowAmt: 0, freezeT: 0, burnT: 0, burnDps: 0, poisonT: 0, poisonDps: 0, dotTick: 0,
      invuln: false, elite: true, mini: false, summoned: false, dead: false, hitCd: new Map(),
      boss: { def, phase: 0, atk: null, atkT: 0, atkStep: 0, cd: 2.2, last: null, ang: 0, dirX: 0, dirY: 0, final, enraged: false },
      resist: def.resist,
    };
    this.enemies.push(e);
    this.boss = e;
    this.arena = { x: p.x, y: p.y, r: 680, t: 0 };
    this.intro = { t: 0, max: 2.8, x, y };
    // shove regular monsters away from the fight
    for (const o of this.enemies) {
      if (o === e || o.dead || o.type === "guardian") continue;
      const d = Math.sqrt(dist2(o.x, o.y, p.x, p.y)) || 1;
      if (d < 420) { o.kx += ((o.x - p.x) / d) * 900; o.ky += ((o.y - p.y) / d) * 900; this.damageEnemy(o, o.maxHp * 0.6, "arcane", "boss", { noCrit: true, silent: true }); }
    }
    this.ring(x, y, 500, def.color, 1.2, 10);
    this.shake(14);
    this.flash(def.color, 0.35);
    const a2 = audio();
    a2.setTrack("boss", this.map.musicRoot);
    this.audioPlay("bossIntro");
    this.audioPlay("roar");
    this.banner({ text: def.name, sub: def.title, kind: "boss" });
  }

  onBossDeath(e: Enemy) {
    const b = e.boss!;
    this.bossesKilled.push(b.def.id);
    this.boss = null;
    this.arena = null;
    this.slowT = 1.4;
    this.shake(24);
    this.flash("#ffffff", 0.5);
    for (let i = 0; i < 6; i++) this.ring(e.x, e.y, 120 + i * 90, i % 2 ? b.def.color : "#ffffff", 0.6 + i * 0.15, 8);
    this.burst(e.x, e.y, b.def.color, 120, 520, 7, 1.4);
    this.burst(e.x, e.y, "#ffffff", 50, 300, 5, 1);
    this.audioPlay("explosion", 1.4, 0.6);
    this.audioPlay("victory");
    this.dropPickup("chest", e.x, e.y, 1);
    for (let i = 0; i < 30; i++) this.dropPickup("gem", e.x + rand(-90, 90), e.y + rand(-90, 90), Math.ceil(e.xp / 30) * (1 + this.minutes * 0.1));
    for (let i = 0; i < 14; i++) this.dropPickup("coin", e.x + rand(-80, 80), e.y + rand(-80, 80), 10);
    this.dropPickup("heart", e.x + 40, e.y, 1);
    this.banner({ text: "Boss Defeated", sub: b.def.name, kind: "victory" });
    audio().setTrack("battle", this.map.musicRoot);
    if (b.final && this.cfg.mode === "classic") this.victory(2.5);
    if (this.cfg.mode === "bossrush") {
      this.rushIndex++;
      if (this.rushIndex >= this.bossQueue.length) this.victory(2.5);
      else { this.rushBreak = 14; this.pendingLevels += 1; }
    }
  }

  victory(delay = 0) {
    if (this.ended) return;
    this.won = true;
    this.banner({ text: "Victory", sub: "The eclipse has been broken", kind: "victory" });
    window.setTimeout(() => this.endRun(true), delay * 1000);
  }

  // ---------------------------------------------------------------- update
  update(dt: number) {
    this.realT += dt;
    let ts = 1;
    if (this.slowT > 0) { this.slowT -= dt; ts = 0.3; }
    if (this.intro) {
      this.intro.t += dt;
      ts = 0.12;
      if (this.intro.t >= this.intro.max) this.intro = null;
    }
    this.timeScale = ts;
    const gdt = dt * ts;
    if (!this.intro) this.time += gdt;
    this.updatePlayer(gdt);
    this.grid.build(this.enemies);
    if (!this.intro) {
      this.updateSpawner(gdt);
      updateWeapons(this, gdt);
    }
    for (const e of this.enemies) {
      if (e.dead) continue;
      if (e.boss) { if (!this.intro) updateBoss(this, e, gdt); else e.t += gdt; }
      else updateEnemy(this, e, gdt);
    }
    this.separate();
    updateProjectiles(this, gdt);
    this.updateEProjs(gdt);
    this.updateZones(gdt);
    this.updatePickups(gdt);
    updateHazards(this, gdt);
    this.updateEffects(gdt);
    // cleanup
    let j = 0;
    for (const e of this.enemies) {
      if (e.dead) continue;
      const far = dist2(e.x, e.y, this.player.x, this.player.y) > 2400 * 2400;
      if (far && !e.boss && e.type !== "guardian") { const [x, y] = this.offscreenPos(); e.x = x; e.y = y; }
      this.enemies[j++] = e;
    }
    this.enemies.length = j;
    if (this.arena) this.arena.t += dt;
    this.updateCamera(dt);
    if (this.pendingLevels > 0 && this.state === "playing" && !this.intro) this.openLevelUp();
  }

  private updatePlayer(dt: number) {
    const p = this.player, s = this.stats, inp = this.input;
    const mv = inp.move();
    p.slowT -= dt;
    let spd = s.speed * (p.slowT > 0 ? 1 - p.slowAmt : 1) * (p.dragonT > 0 ? 1.3 : 1);
    if (p.dashT > 0) {
      p.dashT -= dt;
      p.vx = p.dashX * 820;
      p.vy = p.dashY * 820;
      if (Math.random() < 0.9) this.particle(p.x + rand(-6, 6), p.y + rand(-6, 6), -p.vx * 0.1, -p.vy * 0.1, this.char.glow, 0.3, 9, 0);
    } else {
      const accel = this.onIce ? 2.2 : 16;
      const k = 1 - Math.exp(-accel * dt);
      p.vx = lerp(p.vx, mv.x * spd, k);
      p.vy = lerp(p.vy, mv.y * spd, k);
    }
    p.x += p.vx * dt;
    p.y += p.vy * dt;
    const moving = Math.abs(mv.x) + Math.abs(mv.y) > 0.05;
    if (moving) { p.facing = Math.atan2(mv.y, mv.x); p.walkT += dt * 9; }
    if (this.arena) {
      const a = this.arena;
      const dx = p.x - a.x, dy = p.y - a.y, d = Math.hypot(dx, dy);
      if (d > a.r - p.r) { p.x = a.x + (dx / d) * (a.r - p.r); p.y = a.y + (dy / d) * (a.r - p.r); }
    }
    // aim
    const useMouse = !inp.touchMode && inp.mouseActive && !this.cfg.save.settings.autoAim;
    if (useMouse) {
      this.aimX = this.camX + (inp.mouseX - this.w / 2) / this.zoom;
      this.aimY = this.camY + (inp.mouseY - this.h / 2) / this.zoom;
      this.aimAngle = Math.atan2(this.aimY - p.y, this.aimX - p.x);
    } else {
      const t = this.nearestEnemy(p.x, p.y, 650);
      const a = t ? Math.atan2(t.y - p.y, t.x - p.x) : p.facing;
      this.aimAngle = a;
      this.aimX = t ? t.x : p.x + Math.cos(a) * 200;
      this.aimY = t ? t.y : p.y + Math.sin(a) * 200;
    }
    // dash
    this.dashCd -= dt;
    if (inp.takeDash() && this.dashCd <= 0 && !this.intro) {
      const a = moving ? Math.atan2(mv.y, mv.x) : this.aimAngle;
      p.dashX = Math.cos(a); p.dashY = Math.sin(a);
      p.dashT = 0.17;
      p.iframes = Math.max(p.iframes, s.dashIframe);
      this.dashCd = s.dashCd;
      this.audioPlay("dash");
      this.ring(p.x, p.y, 50, this.char.glow, 0.3, 3);
    }
    // ability
    this.abilityCd -= dt;
    if (inp.takeAbility() && this.abilityCd <= 0 && !this.intro) {
      useAbility(this);
      this.abilityCd = this.char.ability.cd * Math.max(0.5, s.cdMul);
    }
    p.iframes -= dt;
    p.hurtT -= dt;
    if (s.regen > 0) p.hp = Math.min(s.maxHp, p.hp + s.regen * dt);
    if (p.dotT > 0) {
      p.dotT -= dt;
      p.dotTick -= dt;
      if (p.dotTick <= 0) { p.dotTick = 0.5; this.hurtRaw(p.dotDps * 0.5, "#9dff6a"); }
    }
    if (p.dragonT > 0) {
      p.dragonT -= dt;
      if (Math.random() < 0.6) this.particle(p.x + rand(-20, 20), p.y + rand(-20, 20), rand(-30, 30), rand(-90, -40), pickFire(), 0.5, rand(5, 10), 0);
      p.hazardTick -= 0;
      const key = "dragonaura";
      for (const e of this.grid.query(p.x, p.y, 110, this.qbuf)) {
        if (e.dead) continue;
        if (dist2(e.x, e.y, p.x, p.y) < (100 + e.r) ** 2 && (e.hitCd.get(key) ?? 0) <= this.time) {
          e.hitCd.set(key, this.time + 0.3);
          this.damageEnemy(e, 14, "fire", "ability", { burn: 4 });
        }
      }
    }
  }

  private separate() {
    const list = this.enemies;
    const buf: Enemy[] = [];
    for (let i = 0; i < list.length; i++) {
      const e = list[i];
      if (e.dead || e.type === "bat") continue;
      this.grid.query(e.x, e.y, e.r + 30, buf);
      for (const o of buf) {
        if (o === e || o.dead || o.id < e.id || o.type === "bat") continue;
        const dx = o.x - e.x, dy = o.y - e.y;
        const rr = e.r + o.r;
        const d2 = dx * dx + dy * dy;
        if (d2 < rr * rr && d2 > 0.01) {
          const d = Math.sqrt(d2);
          const push = (rr - d) * 0.5;
          const nx = dx / d, ny = dy / d;
          const tm = e.mass + o.mass;
          e.x -= nx * push * (o.mass / tm) * 1.6; e.y -= ny * push * (o.mass / tm) * 1.6;
          o.x += nx * push * (e.mass / tm) * 1.6; o.y += ny * push * (e.mass / tm) * 1.6;
        }
      }
      // player contact
      const p = this.player;
      const pr = e.r + p.r - 2;
      if (dist2(e.x, e.y, p.x, p.y) < pr * pr && !e.invuln && e.freezeT <= 0 && e.spawnT <= 0) {
        this.hurtPlayer(e.dmg, e.x, e.y);
      }
    }
  }

  private updateCamera(dt: number) {
    const p = this.player;
    let tx = p.x, ty = p.y;
    if (this.intro && this.boss) {
      const k = Math.sin(Math.min(1, this.intro.t / this.intro.max) * Math.PI);
      tx = lerp(p.x, this.boss.x, k * 0.7);
      ty = lerp(p.y, this.boss.y, k * 0.7);
    }
    const f = 1 - Math.exp(-10 * dt);
    this.camX = lerp(this.camX, tx, this.intro ? 1 - Math.exp(-4 * dt) : f);
    this.camY = lerp(this.camY, ty, this.intro ? 1 - Math.exp(-4 * dt) : f);
    if (Math.abs(this.camX - tx) > 600) { this.camX = tx; this.camY = ty; }
    const sm = this.cfg.save.settings.shake ? this.shakeMag : 0;
    this.shakeX = (Math.random() - 0.5) * sm * 2;
    this.shakeY = (Math.random() - 0.5) * sm * 2;
    this.shakeMag *= Math.exp(-9 * dt);
    if (this.flashT > 0) this.flashT -= dt;
  }

  // ---------------------------------------------------------------- combat
  nearestEnemy(x: number, y: number, maxD: number): Enemy | null {
    let best: Enemy | null = null, bd = maxD * maxD;
    for (const e of this.enemies) {
      if (e.dead || e.invuln) continue;
      const d = dist2(e.x, e.y, x, y);
      if (d < bd) { bd = d; best = e; }
    }
    return best;
  }
  randomEnemyNear(x: number, y: number, r: number): Enemy | null {
    const list = this.grid.query(x, y, r, this.qbuf).filter((e) => !e.dead && !e.invuln && dist2(e.x, e.y, x, y) < r * r);
    if (!list.length) return null;
    // bias toward denser groups: pick 3, choose one with most neighbours
    return list[Math.floor(Math.random() * list.length)]!;
  }

  damageEnemy(
    e: Enemy, amount: number, dtype: DamageType, src: string,
    o: { kx?: number; ky?: number; fromX?: number; fromY?: number; noCrit?: boolean; silent?: boolean; slow?: number; freeze?: number; burn?: number; poison?: number } = {},
  ): number {
    if (e.dead) return 0;
    if (e.invuln) {
      if (Math.random() < 0.08) this.text(e.x, e.y - e.r, "IMMUNE", "#c8d8ff", 11);
      return 0;
    }
    let dmg = amount * this.stats.might * (this.player.dragonT > 0 ? 1.5 : 1);
    const crit = !o.noCrit && Math.random() < this.stats.crit;
    if (crit) dmg *= this.stats.critMul;
    const res = e.resist?.[dtype];
    if (res !== undefined) dmg *= res;
    if (e.freezeT > 0) dmg *= 1.25;
    let blocked = false;
    if (e.type === "knight" && o.fromX !== undefined && o.fromY !== undefined) {
      const ang = Math.atan2(o.fromY - e.y, o.fromX - e.x);
      let diff = Math.abs(((ang - e.facing + Math.PI * 3) % TAU) - Math.PI);
      if (diff < 1.05) { dmg *= 0.2; blocked = true; }
    }
    dmg = Math.max(1, dmg);
    e.hp -= dmg;
    e.hitFlash = 0.09;
    this.weaponDmg.set(src, (this.weaponDmg.get(src) ?? 0) + dmg);
    if (o.kx || o.ky) { const m = 1 / e.mass; e.kx += (o.kx ?? 0) * m; e.ky += (o.ky ?? 0) * m; }
    if (o.slow) { e.slowT = Math.max(e.slowT, 1.6); e.slowAmt = Math.max(e.slowAmt, o.slow); }
    if (o.freeze && !e.boss) e.freezeT = Math.max(e.freezeT, o.freeze);
    if (o.freeze && e.boss) { e.slowT = 1.2; e.slowAmt = 0.5; }
    if (o.burn) { e.burnT = 2.5; e.burnDps = Math.max(e.burnDps, o.burn); }
    if (o.poison) { e.poisonT = 3; e.poisonDps = Math.max(e.poisonDps, o.poison); }
    if (blocked) {
      if (Math.random() < 0.3) this.text(e.x, e.y - e.r - 4, "BLOCK", "#d8e2f0", 11);
      this.burst(e.x + Math.cos(e.facing) * e.r, e.y + Math.sin(e.facing) * e.r, "#ffffff", 3, 160, 2, 0.2);
      this.audioPlay("block", 0.6);
    }
    if (!o.silent && this.cfg.save.settings.damageNumbers) {
      if (crit) this.text(e.x + rand(-8, 8), e.y - e.r - 6, `${Math.round(dmg)}!`, "#ffe14a", 20);
      else this.text(e.x + rand(-8, 8), e.y - e.r - 4, `${Math.round(dmg)}`, DAMAGE_COLORS[dtype], 13);
    }
    if (crit) {
      this.burst(e.x, e.y, "#ffe14a", 6, 260, 3, 0.3);
      this.audioPlay("crit", 0.7);
      if (src === "daggers") this.onVoidCrit(e);
    } else if (!o.silent) this.audioPlay("hit", 0.6);
    if (e.hp <= 0) this.killEnemy(e, src);
    return dmg;
  }

  private onVoidCrit(e: Enemy) {
    const w = this.weapons.find((x) => x.id === "daggers");
    if (!w?.evolved || Math.random() > 0.35) return;
    this.addZone("rift", e.x, e.y, 60 * this.stats.area, { life: 1.4, dmg: 10, tick: 0.25, color: "#c27bff", src: "daggers" });
  }

  killEnemy(e: Enemy, src: string) {
    if (e.dead) return;
    e.dead = true;
    if (e.boss) { this.onBossDeath(e); return; }
    this.kills++;
    const c = e.color;
    this.burst(e.x, e.y, c, e.r > 25 ? 26 : 10, 220, 4, 0.5);
    this.burst(e.x, e.y, e.color2, 4, 120, 6, 0.6, 2);
    if (e.elite) this.ring(e.x, e.y, e.r * 3, c, 0.4, 4);
    this.audioPlay("kill", 0.5, e.r > 25 ? 0.6 : 1);
    // drops
    const gemV = e.xp * (1 + this.minutes * 0.08);
    this.dropPickup("gem", e.x, e.y, gemV);
    const coinC = (e.def?.coin ?? 0) * (e.elite ? 3 : 1);
    if (Math.random() < coinC) this.dropPickup("coin", e.x + rand(-6, 6), e.y + rand(-6, 6), e.elite ? randInt(3, 8) : 1);
    if (!this.chal?.noHeal && Math.random() < (e.elite ? 0.18 : 0.005)) this.dropPickup("heart", e.x, e.y, 1);
    if (Math.random() < (e.elite ? 0.05 : 0.0012)) this.dropPickup("magnet", e.x, e.y, 1);
    if (Math.random() < (e.elite ? 0.05 : 0.0012)) this.dropPickup("bomb", e.x, e.y, 1);
    if (e.type === "guardian") {
      this.dropPickup("chest", e.x, e.y, 1);
      this.shake(14);
      this.slowT = 0.5;
      this.banner({ text: "Guardian Slain", sub: "Grab the treasure chest!", kind: "victory" });
    }
    if (e.type === "exploder") this.explode(e.x, e.y, 90, e.dmg, 40, "#ff8a2a");
    if (e.type === "slime" && !e.mini) {
      for (let i = 0; i < 2; i++) this.spawnEnemy("slime", e.x + rand(-14, 14), e.y + rand(-14, 14), { mini: true });
    }
    if (e.burnT > 0) {
      const dw = this.weapons.find((w) => w.id === "dragon" && w.evolved);
      if (dw) this.explode(e.x, e.y, 70 * this.stats.area, 0, 30, "#ff7a1a", "dragon");
    }
    if (e.poisonT > 0 || src === "poison") {
      const pw = this.weapons.find((w) => w.id === "poison" && w.evolved);
      if (pw && !this.chal?.noHeal) this.player.hp = Math.min(this.stats.maxHp, this.player.hp + 0.6);
    }
  }

  explode(x: number, y: number, r: number, playerDmg: number, enemyDmg: number, color: string, src = "explosion") {
    this.ring(x, y, r, color, 0.4, 6);
    this.burst(x, y, color, 22, 340, 5, 0.6);
    this.burst(x, y, "#ffe9b0", 8, 200, 7, 0.35);
    this.burst(x, y, "#3a2a2a", 8, 90, 14, 0.9, 2);
    this.shake(7);
    this.audioPlay("explosion", 0.8);
    const p = this.player;
    if (playerDmg > 0 && dist2(x, y, p.x, p.y) < (r + p.r) ** 2) this.hurtPlayer(playerDmg, x, y);
    if (enemyDmg > 0) {
      for (const e of this.grid.query(x, y, r + 50, [])) {
        if (e.dead) continue;
        const d2 = dist2(x, y, e.x, e.y);
        if (d2 < (r + e.r) ** 2) {
          const d = Math.sqrt(d2) || 1;
          this.damageEnemy(e, enemyDmg, "fire", src, { kx: ((e.x - x) / d) * 300, ky: ((e.y - y) / d) * 300, noCrit: src === "explosion" });
        }
      }
    }
  }

  hurtPlayer(dmg: number, sx: number, sy: number, effect: 0 | 1 | 2 | 3 = 0): boolean {
    const p = this.player;
    if (p.iframes > 0 || p.dashT > 0 || this.state !== "playing" || this.intro) return false;
    let d = dmg * (p.dragonT > 0 ? 0.5 : 1) - this.stats.armor;
    d = Math.max(1, d);
    p.hp -= d;
    p.iframes = 0.5;
    p.hurtT = 0.25;
    const dd = Math.hypot(p.x - sx, p.y - sy) || 1;
    p.vx += ((p.x - sx) / dd) * 220;
    p.vy += ((p.y - sy) / dd) * 220;
    if (effect === 1) { p.slowT = 1.5; p.slowAmt = 0.4; }
    if (effect === 2) { p.dotT = 3; p.dotDps = Math.max(2, dmg * 0.25); }
    if (effect === 3) { p.dotT = 2; p.dotDps = Math.max(2, dmg * 0.3); }
    this.shake(8);
    this.flash("#ff2a2a", 0.18);
    this.audioPlay("hurt");
    this.text(p.x, p.y - 22, `-${Math.round(d)}`, "#ff4a4a", 16);
    this.burst(p.x, p.y, "#ff4a4a", 8, 200, 3, 0.4);
    if (p.hp <= 0) this.die();
    return true;
  }
  hurtRaw(d: number, color: string) {
    const p = this.player;
    if (this.state !== "playing") return;
    p.hp -= d;
    this.text(p.x + rand(-6, 6), p.y - 20, `-${Math.max(1, Math.round(d))}`, color, 12);
    if (p.hp <= 0) this.die();
  }

  private die() {
    const p = this.player;
    if (this.revives > 0) {
      this.revives--;
      p.hp = this.stats.maxHp * 0.5;
      p.iframes = 2.5;
      this.slowT = 0.8;
      this.flash("#ffffff", 0.6);
      this.ring(p.x, p.y, 520, "#ffe14a", 0.8, 10);
      for (const e of this.enemies) {
        if (e.dead) continue;
        const d = Math.sqrt(dist2(e.x, e.y, p.x, p.y)) || 1;
        if (d < 520) { e.kx += ((e.x - p.x) / d) * 1200; e.ky += ((e.y - p.y) / d) * 1200; this.damageEnemy(e, 250, "arcane", "revive", { noCrit: true, silent: true }); }
      }
      this.eprojs.clear();
      this.audioPlay("heal");
      this.banner({ text: "Revived", sub: "Fate grants you another chance", kind: "info" });
      return;
    }
    p.hp = 0;
    this.burst(p.x, p.y, this.char.glow, 60, 400, 6, 1.2);
    this.endRun(false);
  }

  endRun(won: boolean) {
    if (this.ended) return;
    this.ended = true;
    this.state = "over";
    audio().setTrack("none");
    this.audioPlay(won ? "victory" : "defeat");
    const mult = this.diff.coin;
    const score = Math.round((this.kills * 10 + Math.floor(this.time) * 5 + this.level * 50 + this.bossesKilled.length * 1500 + (won ? 5000 : 0)) * mult);
    const bonusCoins = Math.floor((this.time / 60) * 8 + this.bossesKilled.length * 60);
    const weaponDmg = [...this.weaponDmg.entries()]
      .filter(([k]) => k in WEAPONS || k === "ability")
      .map(([k, v]) => {
        const wd = k in WEAPONS ? WEAPONS[k as WeaponId] : null;
        const evo = this.weapons.find((w) => w.id === k)?.evolved;
        return { id: k, name: wd ? (evo ? wd.evoName : wd.name) : this.char.ability.name, dmg: Math.round(v), color: wd?.color ?? this.char.glow };
      })
      .sort((a, b) => b.dmg - a.dmg);
    this.cb.onEnd({
      mode: this.cfg.mode, map: this.cfg.map, char: this.cfg.char, difficulty: this.cfg.difficulty,
      challenge: this.cfg.mode === "challenge" ? this.cfg.challenge : null,
      time: Math.floor(this.time), kills: this.kills, level: this.level,
      coins: Math.round(this.coins + bonusCoins * this.stats.coinMul),
      bossesKilled: [...this.bossesKilled], evolutions: this.evolutions, won, score, weaponDmg,
    });
  }

  // ---------------------------------------------------------------- level up
  addXp(v: number) {
    this.xp += v * this.stats.xpMul;
    while (this.xp >= this.xpNext) {
      this.xp -= this.xpNext;
      this.level++;
      this.xpNext = xpFor(this.level);
      this.pendingLevels++;
    }
  }
  openLevelUp() {
    if (this.state !== "playing" || this.pendingLevels <= 0) return;
    this.state = "levelup";
    this.choices = genChoices(this);
    this.audioPlay("levelup");
    this.cb.onLevelUp(this.choices);
  }
  choose(i: number) {
    if (this.state !== "levelup") return;
    const c = this.choices[i];
    if (!c) return;
    applyChoice(this, c);
    this.pendingLevels--;
    this.audioPlay("click");
    if (this.pendingLevels > 0) {
      this.choices = genChoices(this);
      this.cb.onLevelUp(this.choices);
    } else {
      this.state = "playing";
      this.cb.onLevelUp(null);
      this.input.clearQueued();
      // level-up shockwave gives breathing room
      const p = this.player;
      this.ring(p.x, p.y, 170, "#8ae8ff", 0.45, 6);
      for (const e of this.grid.query(p.x, p.y, 180, [])) {
        if (e.dead || e.boss) continue;
        const d = Math.sqrt(dist2(e.x, e.y, p.x, p.y)) || 1;
        if (d < 170) { e.kx += ((e.x - p.x) / d) * 700; e.ky += ((e.y - p.y) / d) * 700; }
      }
      p.iframes = Math.max(p.iframes, 0.6);
    }
  }
  reroll() {
    if (this.state !== "levelup" || this.rerolls <= 0) return;
    this.rerolls--;
    this.choices = genChoices(this);
    this.audioPlay("click");
    this.cb.onLevelUp(this.choices);
  }

  openChest(x: number, y: number) {
    this.audioPlay("chest");
    this.ring(x, y, 220, "#ffe14a", 0.7, 8);
    this.burst(x, y, "#ffe14a", 50, 380, 5, 1);
    this.coins += Math.round(25 * this.stats.coinMul);
    const evos = evolutionsAvailable(this);
    if (evos.length) applyEvolution(this, evos[0]!);
    else {
      this.pendingLevels += 2;
      this.banner({ text: "Treasure!", sub: "Two bonus upgrades", kind: "info" });
    }
  }

  // ---------------------------------------------------------------- pickups
  dropPickup(kind: PickupKind, x: number, y: number, value: number) {
    if (kind === "gem" && this.pickups.length > 520) {
      // merge into the oldest far gem to keep things fast
      for (const g of this.pickups) if (g.kind === "gem" && !g.mag) { g.value += value; g.tier = gemTier(g.value); return; }
    }
    this.pickups.push({ alive: true, kind, x, y, vx: rand(-60, 60), vy: rand(-60, 60), value, tier: kind === "gem" ? gemTier(value) : 0, mag: false, t: 0 });
  }

  private updatePickups(dt: number) {
    const p = this.player, s = this.stats;
    const mr2 = s.magnet * s.magnet;
    let j = 0;
    for (const g of this.pickups) {
      if (!g.alive) continue;
      g.t += dt;
      const d2 = dist2(g.x, g.y, p.x, p.y);
      if (!g.mag) {
        g.x += g.vx * dt; g.y += g.vy * dt;
        g.vx *= Math.exp(-6 * dt); g.vy *= Math.exp(-6 * dt);
        if (g.kind !== "chest" && d2 < mr2) g.mag = true;
      } else {
        const d = Math.sqrt(d2) || 1;
        const sp = 280 + Math.min(900, g.t * 300);
        g.vx = lerp(g.vx, ((p.x - g.x) / d) * sp, 1 - Math.exp(-10 * dt));
        g.vy = lerp(g.vy, ((p.y - g.y) / d) * sp, 1 - Math.exp(-10 * dt));
        g.x += g.vx * dt; g.y += g.vy * dt;
      }
      if (d2 < (p.r + 12) ** 2) { this.collect(g); g.alive = false; }
      if (g.alive) this.pickups[j++] = g;
    }
    this.pickups.length = j;
  }

  private collect(g: Pickup) {
    const p = this.player;
    switch (g.kind) {
      case "gem": this.addXp(g.value); this.audioPlay("xp", 0.6, 1 + Math.min(0.6, g.tier * 0.15)); break;
      case "coin": this.coins += g.value * this.stats.coinMul; this.audioPlay("coin", 0.6); break;
      case "heart":
        if (this.chal?.noHeal) break;
        p.hp = Math.min(this.stats.maxHp, p.hp + this.stats.maxHp * 0.3);
        this.text(p.x, p.y - 26, "+HEAL", "#7dff6a", 15);
        this.audioPlay("heal");
        break;
      case "magnet": for (const o of this.pickups) if (o.kind === "gem" || o.kind === "coin") { o.mag = true; o.t = 0.5; } this.audioPlay("chest", 0.5); this.banner({ text: "Magnet", sub: "All crystals pulled in", kind: "info" }); break;
      case "bomb": {
        this.flash("#ffffff", 0.4);
        this.shake(16);
        this.ring(p.x, p.y, 900, "#ffffff", 0.7, 12);
        this.audioPlay("explosion", 1.3, 0.7);
        for (const e of this.enemies) {
          if (e.dead) continue;
          if (Math.abs(e.x - p.x) < this.viewW / 2 + 40 && Math.abs(e.y - p.y) < this.viewH / 2 + 40) this.damageEnemy(e, e.boss ? 300 : 9999, "arcane", "bomb", { noCrit: true, silent: !!e.boss ? false : true });
        }
        break;
      }
      case "chest": this.openChest(g.x, g.y); break;
    }
  }

  // ---------------------------------------------------------------- enemy projectiles
  fireEProj(kind: EProj["kind"], x: number, y: number, ang: number, speed: number, dmg: number, color: string, effect: 0 | 1 | 2 | 3 = 0, r = 8, life = 4) {
    const e = this.eprojs.spawn();
    if (!e) return null;
    e.kind = kind; e.x = x; e.y = y; e.vx = Math.cos(ang) * speed; e.vy = Math.sin(ang) * speed;
    e.r = r; e.dmg = dmg; e.life = life; e.color = color; e.effect = effect; e.t = 0; e.accel = 0; e.tx = 0; e.ty = 0; e.lob = 0;
    return e;
  }
  private updateEProjs(dt: number) {
    const p = this.player;
    for (const e of this.eprojs.items) {
      e.t += dt;
      e.life -= dt;
      if (e.accel) { const sp = Math.hypot(e.vx, e.vy) || 1; const ns = sp + e.accel * dt; e.vx = (e.vx / sp) * ns; e.vy = (e.vy / sp) * ns; }
      e.x += e.vx * dt; e.y += e.vy * dt;
      if (e.kind === "spit" && e.life <= 0) {
        this.addZone("puddle", e.x, e.y, 46, { life: 4, dmg: e.dmg * 0.5, tick: 0.5, color: "#9dff6a", src: "enemy" });
        e.alive = false;
        continue;
      }
      if (e.life <= 0) { e.alive = false; continue; }
      const hitR = e.kind === "spit" ? (e.lob > 0 && e.t > e.lob * 0.7 ? e.r : -1) : e.r;
      if (hitR > 0 && dist2(e.x, e.y, p.x, p.y) < (hitR + p.r - 3) ** 2) {
        if (this.hurtPlayer(e.dmg, e.x - e.vx, e.y - e.vy, e.effect)) {
          this.burst(e.x, e.y, e.color, 8, 160, 3, 0.3);
          e.alive = false;
        }
      }
    }
    this.eprojs.sweep();
  }

  // ---------------------------------------------------------------- zones
  addZone(kind: ZoneKind, x: number, y: number, r: number, o: { life?: number; delay?: number; dmg?: number; tick?: number; color?: string; a?: number; b?: number; evo?: boolean; src?: string } = {}): Zone {
    const z: Zone = {
      alive: true, kind, x, y, r, maxR: r, t: 0, life: o.life ?? 1, delay: o.delay ?? 0, delayMax: o.delay ?? 0,
      dmg: o.dmg ?? 0, tick: o.tick ?? 0.5, tickT: 0, color: o.color ?? "#fff", a: o.a ?? 0, b: o.b ?? 0, evo: !!o.evo, src: o.src ?? "zone",
    };
    this.zones.push(z);
    return z;
  }

  private updateZones(dt: number) {
    const p = this.player;
    const buf = this.qbuf;
    for (const z of this.zones) {
      if (!z.alive) continue;
      z.t += dt;
      if (z.delay > 0) {
        z.delay -= dt;
        if (z.delay > 0) continue;
        this.zoneTrigger(z);
        if (!z.alive) continue;
      }
      z.life -= dt;
      z.tickT -= dt;
      switch (z.kind) {
        case "puddle":
          if (z.tickT <= 0 && dist2(z.x, z.y, p.x, p.y) < (z.r + p.r * 0.5) ** 2) {
            z.tickT = z.tick;
            p.slowT = 0.4; p.slowAmt = 0.35;
            this.hurtPlayer(z.dmg, z.x, z.y);
          }
          break;
        case "nova": {
          const prev = z.r;
          z.r = Math.min(z.maxR, z.r + z.a * dt);
          for (const e of this.grid.query(z.x, z.y, z.r + 50, buf)) {
            if (e.dead) continue;
            const d = Math.sqrt(dist2(e.x, e.y, z.x, z.y));
            const key = "nova" + z.b;
            if (d < z.r + e.r && d >= prev - e.r - 4 && !e.hitCd.has(key)) {
              e.hitCd.set(key, 1);
              this.damageEnemy(e, z.dmg, "fire", z.src, { kx: ((e.x - z.x) / (d || 1)) * 520, ky: ((e.y - z.y) / (d || 1)) * 520, burn: z.evo ? z.dmg * 0.4 : 0 });
            }
          }
          if (z.r >= z.maxR) {
            z.alive = false;
            for (const e of this.enemies) e.hitCd.delete(key0(z.b));
          }
          break;
        }
        case "cloud": case "burn": case "lava": case "miasma": case "rift": {
          if (z.kind === "miasma") { z.x = p.x; z.y = p.y; z.life = 10; }
          if (z.tickT <= 0) {
            z.tickT = z.tick;
            const dtype: DamageType = z.kind === "cloud" || z.kind === "miasma" ? "poison" : z.kind === "rift" ? "shadow" : "fire";
            for (const e of this.grid.query(z.x, z.y, z.r + 40, buf)) {
              if (e.dead) continue;
              if (dist2(e.x, e.y, z.x, z.y) < (z.r + e.r * 0.5) ** 2) {
                this.damageEnemy(e, z.dmg, dtype, z.src, { noCrit: z.kind !== "rift", poison: dtype === "poison" ? z.dmg * 0.3 : 0, silent: z.kind === "miasma" && Math.random() < 0.6 });
              }
            }
          }
          if (z.kind === "rift") {
            for (const e of this.grid.query(z.x, z.y, z.r * 2, buf)) {
              if (e.dead || e.boss) continue;
              const d = Math.sqrt(dist2(e.x, e.y, z.x, z.y)) || 1;
              if (d < z.r * 2) { e.x += ((z.x - e.x) / d) * 160 * dt; e.y += ((z.y - e.y) / d) * 160 * dt; }
            }
          }
          if (Math.random() < 0.3) {
            const a = rand(0, TAU), rr = rand(0, z.r);
            this.particle(z.x + Math.cos(a) * rr, z.y + Math.sin(a) * rr, 0, rand(-40, -10), z.color, 0.7, rand(4, 9), z.kind === "cloud" || z.kind === "miasma" ? 2 : 0);
          }
          break;
        }
        case "mine": {
          let trig = false;
          for (const e of this.grid.query(z.x, z.y, 60, buf)) if (!e.dead && dist2(e.x, e.y, z.x, z.y) < (40 + e.r) ** 2) { trig = true; break; }
          if (trig || z.life <= 0) { this.mineBoom(z); z.alive = false; }
          break;
        }
        case "gravity": {
          const d = Math.sqrt(dist2(p.x, p.y, z.x, z.y)) || 1;
          const fade = Math.min(1, z.t / 0.8, z.life / 0.8);
          if (d < z.r) {
            const f = z.a * fade * (1 - d / z.r * 0.5);
            p.x += ((z.x - p.x) / d) * f * dt;
            p.y += ((z.y - p.y) / d) * f * dt;
          }
          if (d < z.r * 0.16 && z.tickT <= 0) { z.tickT = z.tick; this.hurtPlayer(z.dmg, z.x, z.y); }
          for (const e of this.grid.query(z.x, z.y, z.r, buf)) {
            if (e.dead || e.boss) continue;
            const de = Math.sqrt(dist2(e.x, e.y, z.x, z.y)) || 1;
            e.x += ((z.x - e.x) / de) * z.a * 0.6 * fade * dt;
            e.y += ((z.y - e.y) / de) * z.a * 0.6 * fade * dt;
          }
          if (Math.random() < 0.5) {
            const a = rand(0, TAU);
            this.particle(z.x + Math.cos(a) * z.r, z.y + Math.sin(a) * z.r, -Math.cos(a) * z.r * 0.9, -Math.sin(a) * z.r * 0.9, z.color, 1, 4, 1);
          }
          break;
        }
        case "turret": {
          z.a -= dt;
          if (z.a <= 0) {
            z.a = 0.13;
            const t = this.nearestEnemy(z.x, z.y, 520);
            if (t) {
              const ang = Math.atan2(t.y - z.y, t.x - z.x);
              z.b = ang;
              this.fireProj("bullet", z.x, z.y, ang, 900, 12, "physical", 0, 5, 0.8, "#ffcf3a", "turret");
              this.audioPlay("shoot", 0.4, 1.4);
            }
          }
          break;
        }
        default: break;
      }
      if (z.life <= 0 && z.delay <= 0) z.alive = false;
    }
    let j = 0;
    for (const z of this.zones) if (z.alive) this.zones[j++] = z;
    this.zones.length = j;
  }

  private zoneTrigger(z: Zone) {
    const p = this.player;
    switch (z.kind) {
      case "telegraph": case "eruption":
        if (dist2(z.x, z.y, p.x, p.y) < (z.r + p.r * 0.6) ** 2) this.hurtPlayer(z.dmg, z.x, z.y, z.kind === "eruption" ? 3 : 0);
        this.ring(z.x, z.y, z.r, z.color, 0.35, 6);
        this.burst(z.x, z.y, z.color, 16, 300, 5, 0.5);
        if (z.kind === "eruption") for (let i = 0; i < 10; i++) this.particle(z.x + rand(-20, 20), z.y + rand(-20, 20), rand(-80, 80), rand(-320, -120), pickFire(), 0.8, rand(5, 10), 0, 0, 500);
        this.shake(5);
        this.audioPlay("explosion", 0.5, 1.3);
        z.alive = false;
        break;
      case "meteor": {
        this.ring(z.x, z.y, z.r * 1.2, "#ffb347", 0.45, 8);
        this.burst(z.x, z.y, "#ff6a2a", 30, 420, 6, 0.7);
        this.burst(z.x, z.y, "#ffe9b0", 10, 250, 8, 0.4);
        this.burst(z.x, z.y, "#2a1a14", 10, 120, 16, 1.1, 2);
        this.shake(z.evo ? 9 : 6);
        this.audioPlay("explosion", 0.8);
        for (const e of this.grid.query(z.x, z.y, z.r + 50, [])) {
          if (e.dead) continue;
          const d = Math.sqrt(dist2(e.x, e.y, z.x, z.y)) || 1;
          if (d < z.r + e.r) this.damageEnemy(e, z.dmg, "fire", "meteor", { kx: ((e.x - z.x) / d) * 400, ky: ((e.y - z.y) / d) * 400, burn: z.dmg * 0.15 });
        }
        if (z.evo) this.addZone("lava", z.x, z.y, z.r * 0.75, { life: 3.5, dmg: z.dmg * 0.12, tick: 0.4, color: "#ff5a1a", src: "meteor" });
        z.alive = false;
        break;
      }
      case "summon": {
        const id = z.src as EnemyId;
        if (id in ENEMIES) this.spawnEnemy(id, z.x, z.y, { summoned: true });
        this.burst(z.x, z.y, z.color, 12, 160, 4, 0.5);
        z.alive = false;
        break;
      }
      case "mine":
        z.b = 1; // armed
        break;
      default: break;
    }
  }

  private mineBoom(z: Zone) {
    this.explode(z.x, z.y, z.r, 0, z.dmg, "#ffcf3a", "mines");
    if (z.evo) for (let i = 0; i < 4; i++) {
      const a = rand(0, TAU), d = rand(60, 110);
      const m = this.addZone("meteor", z.x + Math.cos(a) * d, z.y + Math.sin(a) * d, 55 * this.stats.area, { delay: 0.25 + i * 0.08, dmg: z.dmg * 0.35, color: "#ffcf3a", src: "mines" });
      m.src = "mines";
    }
  }

  // ---------------------------------------------------------------- projectiles (player)
  fireProj(kind: Proj["kind"], x: number, y: number, ang: number, speed: number, dmg: number, dtype: DamageType, pierce: number, r: number, life: number, color: string, src: Proj["src"], evo = false): Proj | null {
    const p = this.projs.spawn();
    if (!p) return null;
    p.kind = kind; p.x = x; p.y = y; p.vx = Math.cos(ang) * speed; p.vy = Math.sin(ang) * speed; p.r = r;
    p.dmg = dmg; p.dtype = dtype; p.pierce = pierce; p.life = life; p.max = life; p.color = color; p.src = src;
    p.hits.clear(); p.t = 0; p.a = 0; p.b = 0; p.st = 0; p.target = null; p.evo = evo;
    return p;
  }

  // ---------------------------------------------------------------- effects
  particle(x: number, y: number, vx: number, vy: number, color: string, life: number, size: number, kind: 0 | 1 | 2 | 3, drag = 3, grav = 0) {
    const q = this.parts.spawn();
    if (!q) return;
    q.x = x; q.y = y; q.vx = vx; q.vy = vy; q.color = color; q.life = life; q.max = life; q.size = size; q.kind = kind; q.drag = drag; q.grav = grav; q.rot = rand(0, TAU);
  }
  burst(x: number, y: number, color: string, n: number, speed: number, size: number, life: number, kind: 0 | 1 | 2 | 3 = 1) {
    for (let i = 0; i < n; i++) {
      const a = rand(0, TAU), s = rand(0.3, 1) * speed;
      this.particle(x, y, Math.cos(a) * s, Math.sin(a) * s, color, life * rand(0.6, 1.1), size * rand(0.6, 1.2), kind, kind === 2 ? 1.5 : 4);
    }
  }
  text(x: number, y: number, s: string, color: string, size: number) {
    const t = this.texts.spawn();
    if (!t) return;
    t.x = x; t.y = y; t.vy = -70; t.life = 0.75; t.max = 0.75; t.text = s; t.color = color; t.size = size;
  }
  ring(x: number, y: number, max: number, color: string, life: number, width: number) {
    if (this.rings.length > 80) return;
    this.rings.push({ x, y, r: 0, max, life, maxLife: life, color, width });
  }
  bolt(x1: number, y1: number, x2: number, y2: number, color: string, width = 3, life = 0.18) {
    const pts: number[] = [];
    const n = Math.max(3, Math.floor(Math.hypot(x2 - x1, y2 - y1) / 22));
    const nx = -(y2 - y1), ny = x2 - x1, nl = Math.hypot(nx, ny) || 1;
    for (let i = 0; i <= n; i++) {
      const t = i / n;
      const off = i === 0 || i === n ? 0 : rand(-16, 16);
      pts.push(lerp(x1, x2, t) + (nx / nl) * off, lerp(y1, y2, t) + (ny / nl) * off);
    }
    if (this.bolts.length < 60) this.bolts.push({ pts, life, max: life, color, width });
  }
  shake(m: number) { this.shakeMag = Math.max(this.shakeMag, m); }
  flash(color: string, t: number) { this.flashColor = color; this.flashT = Math.max(this.flashT, t); }
  banner(b: Banner) { this.cb.onBanner(b); }
  audioPlay(n: Parameters<ReturnType<typeof audio>["play"]>[0], vol = 1, pitch = 1) { audio().play(n, vol, pitch); }

  updateEffects(dt: number) {
    for (const q of this.parts.items) {
      q.life -= dt;
      if (q.life <= 0) { q.alive = false; continue; }
      const dr = Math.exp(-q.drag * dt);
      q.vx *= dr; q.vy *= dr;
      q.vy += q.grav * dt;
      q.x += q.vx * dt; q.y += q.vy * dt;
    }
    this.parts.sweep();
    for (const t of this.texts.items) {
      t.life -= dt;
      t.y += t.vy * dt;
      t.vy *= Math.exp(-4 * dt);
      if (t.life <= 0) t.alive = false;
    }
    this.texts.sweep();
    let j = 0;
    for (const r of this.rings) { r.life -= dt; r.r = r.max * (1 - Math.pow(r.life / r.maxLife, 2)); if (r.life > 0) this.rings[j++] = r; }
    this.rings.length = j;
    j = 0;
    for (const b of this.bolts) { b.life -= dt; if (b.life > 0) this.bolts[j++] = b; }
    this.bolts.length = j;
    for (const e of this.enemies) if (e.hitFlash > 0) e.hitFlash -= dt;
  }

  // ---------------------------------------------------------------- hud
  hud(): HudSnapshot {
    const b = this.boss?.boss;
    const mode = this.cfg.mode;
    let goal = "";
    if (mode === "classic") goal = this.time < CLASSIC_DURATION ? `Final boss in ${fmt(CLASSIC_DURATION - this.time)}` : "Defeat the final boss!";
    else if (mode === "challenge") goal = `${this.chal?.name}: survive ${fmt(Math.max(0, CHALLENGE_DURATION - this.time))}`;
    else if (mode === "bossrush") goal = `Boss ${Math.min(this.rushIndex + 1, this.bossQueue.length)} / ${this.bossQueue.length}`;
    else goal = `Endless · threat ×${this.hpScale().toFixed(1)}`;
    return {
      hp: Math.max(0, this.player.hp), maxHp: this.stats.maxHp,
      xp: this.xp, xpNext: this.xpNext, level: this.level,
      time: this.time, kills: this.kills, coins: Math.floor(this.coins),
      weapons: this.weapons.map((w) => ({ id: w.id, level: w.level, evolved: w.evolved, ready: w.aux2 })),
      passives: (Object.keys(this.passives) as PassiveId[]).map((id) => ({ id, level: this.passives[id] ?? 0 })),
      ability: clamp(1 - this.abilityCd / (this.char.ability.cd * Math.max(0.5, this.stats.cdMul)), 0, 1),
      abilityReady: this.abilityCd <= 0, abilityActive: this.player.dragonT > 0,
      dash: clamp(1 - this.dashCd / this.stats.dashCd, 0, 1),
      boss: b && this.boss ? { name: b.def.name, title: b.def.title, hp: Math.max(0, this.boss.hp), max: this.boss.maxHp, phase: b.phase, color: b.def.color } : null,
      goal, rerolls: this.rerolls, revives: this.revives, hazardText: this.hazardText,
    };
  }
}

const key0 = (b: number) => "nova" + b;
function fmt(s: number) { const m = Math.floor(s / 60), r = Math.floor(s % 60); return `${m}:${r < 10 ? "0" : ""}${r}`; }
export function gemTier(v: number) { return v < 3 ? 0 : v < 10 ? 1 : v < 40 ? 2 : 3; }
const FIRE = ["#ff4a1a", "#ff8a2a", "#ffd04a", "#ff6a2a"];
export function pickFire() { return FIRE[Math.floor(Math.random() * FIRE.length)]!; }
export { PASSIVES, chance };
