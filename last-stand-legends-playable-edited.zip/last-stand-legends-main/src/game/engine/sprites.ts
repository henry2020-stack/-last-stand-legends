import { TAU } from "../core/math";
import type { CharacterDef } from "../data/characters";
import type { Game } from "./game";
import type { Enemy } from "./types";
import { drawGlow, rgba } from "./draw-utils";

const W = "#ffffff";

export function drawCharacter(ctx: CanvasRenderingContext2D, c: CharacterDef, x: number, y: number, t: number, moving: boolean, aim: number, scale = 1, flash = false) {
  const bob = moving ? Math.abs(Math.sin(t)) * 2.5 : Math.sin(t * 0.3) * 1;
  const flip = Math.cos(aim) < 0 ? -1 : 1;
  ctx.save();
  ctx.translate(x, y);
  ctx.scale(scale, scale);
  // feet
  const step = moving ? Math.sin(t) * 4 : 0;
  ctx.fillStyle = flash ? W : "#1a1420";
  ctx.beginPath();
  ctx.ellipse(-5 + step, 12, 4, 3, 0, 0, TAU);
  ctx.ellipse(5 - step, 12, 4, 3, 0, 0, TAU);
  ctx.fill();
  ctx.translate(0, -bob);
  // cape
  if (c.accessory === "crown" || c.accessory === "helm" || c.accessory === "mask") {
    ctx.fillStyle = flash ? W : rgba(c.trim, 0.85);
    ctx.beginPath();
    ctx.moveTo(-8 * flip, -4);
    ctx.quadraticCurveTo(-16 * flip, 8 + Math.sin(t * 1.3) * 2, -10 * flip, 14);
    ctx.lineTo(2 * flip, 10);
    ctx.closePath();
    ctx.fill();
  }
  // body
  ctx.fillStyle = flash ? W : c.body;
  ctx.beginPath();
  ctx.ellipse(0, 3, 10, 11, 0, 0, TAU);
  ctx.fill();
  ctx.fillStyle = flash ? W : c.trim;
  ctx.fillRect(-10, 4, 20, 3);
  // head
  ctx.fillStyle = flash ? W : c.skin;
  ctx.beginPath();
  ctx.arc(0, -10, 8.5, 0, TAU);
  ctx.fill();
  // eyes
  const ex = Math.cos(aim) * 2.5, ey = Math.sin(aim) * 1.5;
  ctx.fillStyle = "#16121c";
  ctx.beginPath();
  ctx.arc(-3 + ex, -10 + ey, 1.6, 0, TAU);
  ctx.arc(3 + ex, -10 + ey, 1.6, 0, TAU);
  ctx.fill();
  // accessory
  ctx.fillStyle = flash ? W : c.trim;
  ctx.strokeStyle = flash ? W : c.trim;
  switch (c.accessory) {
    case "helm":
      ctx.fillStyle = flash ? W : "#c8d6e8";
      ctx.beginPath(); ctx.arc(0, -12, 9.5, Math.PI, 0); ctx.fill();
      ctx.fillStyle = flash ? W : c.trim; ctx.fillRect(-1.5, -24, 3, 7);
      break;
    case "hat":
      ctx.fillStyle = flash ? W : c.body;
      ctx.beginPath(); ctx.ellipse(0, -16, 13, 3.5, 0, 0, TAU); ctx.fill();
      ctx.beginPath(); ctx.moveTo(-7, -16); ctx.lineTo(4 * flip, -34); ctx.lineTo(7, -16); ctx.fill();
      ctx.fillStyle = flash ? W : c.trim; ctx.beginPath(); ctx.arc(4 * flip, -34, 2.5, 0, TAU); ctx.fill();
      break;
    case "hood":
      ctx.fillStyle = flash ? W : c.body;
      ctx.beginPath(); ctx.arc(0, -11, 10.5, Math.PI * 0.9, Math.PI * 2.1); ctx.lineTo(8, -2); ctx.lineTo(-8, -2); ctx.fill();
      ctx.fillStyle = flash ? W : c.skin; ctx.beginPath(); ctx.arc(ex * 0.5, -9, 6.5, 0, TAU); ctx.fill();
      ctx.fillStyle = "#ff8a3d"; ctx.beginPath(); ctx.arc(-2.5 + ex, -9 + ey, 1.6, 0, TAU); ctx.arc(2.5 + ex, -9 + ey, 1.6, 0, TAU); ctx.fill();
      break;
    case "mask":
      ctx.fillStyle = flash ? W : "#1a0f24";
      ctx.fillRect(-8.5, -9, 17, 6);
      ctx.fillStyle = c.trim; ctx.fillRect(-6 + ex, -8 + ey * 0.5, 3, 1.6); ctx.fillRect(3 + ex, -8 + ey * 0.5, 3, 1.6);
      ctx.fillStyle = flash ? W : "#2a1a3a"; ctx.beginPath(); ctx.arc(0, -13, 9, Math.PI, 0); ctx.fill();
      break;
    case "horns":
      ctx.fillStyle = flash ? W : "#e8e0d0";
      ctx.beginPath(); ctx.moveTo(-7, -15); ctx.quadraticCurveTo(-16, -20, -14, -28); ctx.lineTo(-4, -17); ctx.fill();
      ctx.beginPath(); ctx.moveTo(7, -15); ctx.quadraticCurveTo(16, -20, 14, -28); ctx.lineTo(4, -17); ctx.fill();
      ctx.fillStyle = flash ? W : "#8a6a4a"; ctx.beginPath(); ctx.arc(0, -4, 6, 0, Math.PI); ctx.fill();
      break;
    case "goggles":
      ctx.fillStyle = flash ? W : "#2a3a2a"; ctx.fillRect(-9, -12, 18, 2);
      ctx.fillStyle = flash ? W : c.trim; ctx.beginPath(); ctx.arc(-3.5, -11, 3, 0, TAU); ctx.arc(3.5, -11, 3, 0, TAU); ctx.fill();
      ctx.fillStyle = "#e8ffd8"; ctx.beginPath(); ctx.arc(-3 + ex * 0.4, -11.5, 1, 0, TAU); ctx.arc(4 + ex * 0.4, -11.5, 1, 0, TAU); ctx.fill();
      break;
    case "bandana":
      ctx.fillStyle = flash ? W : "#c8402a"; ctx.beginPath(); ctx.arc(0, -13, 9, Math.PI, 0); ctx.fill();
      ctx.beginPath(); ctx.moveTo(-8 * flip, -13); ctx.lineTo(-15 * flip, -9 + Math.sin(t * 2) * 2); ctx.lineTo(-13 * flip, -14); ctx.fill();
      break;
    case "crown":
      ctx.fillStyle = flash ? W : c.trim;
      ctx.beginPath(); ctx.moveTo(-7, -16); ctx.lineTo(-7, -22); ctx.lineTo(-3.5, -18); ctx.lineTo(0, -24); ctx.lineTo(3.5, -18); ctx.lineTo(7, -22); ctx.lineTo(7, -16); ctx.fill();
      ctx.fillStyle = flash ? W : "#c8402a";
      ctx.beginPath(); ctx.moveTo(-8, -10); ctx.lineTo(-13, -18); ctx.lineTo(-6, -14); ctx.fill();
      ctx.beginPath(); ctx.moveTo(8, -10); ctx.lineTo(13, -18); ctx.lineTo(6, -14); ctx.fill();
      break;
  }
  // hand focus orb toward aim
  const hx = Math.cos(aim) * 13, hy = 2 + Math.sin(aim) * 9;
  ctx.globalCompositeOperation = "lighter";
  drawGlow(ctx, c.glow, hx, hy, 9);
  ctx.globalCompositeOperation = "source-over";
  ctx.fillStyle = W;
  ctx.beginPath(); ctx.arc(hx, hy, 2.2, 0, TAU); ctx.fill();
  ctx.restore();
}

export function drawPlayer(ctx: CanvasRenderingContext2D, g: Game) {
  const p = g.player;
  const moving = Math.hypot(p.vx, p.vy) > 20;
  if (p.dragonT > 0) {
    ctx.globalCompositeOperation = "lighter";
    drawGlow(ctx, "#ff6a1a", p.x, p.y, 120 + Math.sin(g.realT * 12) * 8);
    ctx.globalCompositeOperation = "source-over";
  }
  if (p.iframes > 0 && p.hurtT <= 0 && p.dashT <= 0 && Math.floor(g.realT * 20) % 2 === 0) ctx.globalAlpha = 0.5;
  drawCharacter(ctx, g.char, p.x, p.y, p.walkT, moving, g.aimAngle, p.dragonT > 0 ? 1.25 : 1, p.hurtT > 0.15);
  ctx.globalAlpha = 1;
}

// ------------------------------------------------------------------ enemies
export function drawEnemy(ctx: CanvasRenderingContext2D, e: Enemy, g: Game) {
  const f = e.hitFlash > 0;
  const C = (c: string) => (f ? W : c);
  const r = e.r;
  const t = e.t;
  const sc = e.spawnT > 0 ? Math.max(0.05, 1 - e.spawnT / 0.35) : 1;
  ctx.save();
  ctx.translate(e.x, e.y);
  if (sc !== 1) ctx.scale(sc, sc);
  if (e.invuln) ctx.globalAlpha = 0.28 + Math.sin(t * 20) * 0.08;
  const face = e.facing;
  const fx = Math.cos(face), fy = Math.sin(face);
  switch (e.type) {
    case "zombie": {
      const sway = Math.sin(t * 8) * 0.25;
      ctx.strokeStyle = C(e.color2); ctx.lineWidth = r * 0.3; ctx.lineCap = "round";
      ctx.beginPath();
      for (const s of [-1, 1]) {
        const a = face + s * 0.5 + sway * s;
        ctx.moveTo(Math.cos(face + s * 1.4) * r * 0.6, Math.sin(face + s * 1.4) * r * 0.6);
        ctx.lineTo(Math.cos(a) * r * 1.35, Math.sin(a) * r * 1.35);
      }
      ctx.stroke();
      ctx.fillStyle = C(e.color);
      ctx.beginPath(); ctx.ellipse(0, 0, r * 0.85, r, 0, 0, TAU); ctx.fill();
      ctx.fillStyle = C("#8fae78");
      ctx.beginPath(); ctx.arc(fx * r * 0.2, -r * 0.45, r * 0.55, 0, TAU); ctx.fill();
      ctx.fillStyle = "#ff3a2a";
      ctx.beginPath(); ctx.arc(fx * r * 0.45 - 3, -r * 0.5, 1.8, 0, TAU); ctx.arc(fx * r * 0.45 + 3, -r * 0.5, 1.8, 0, TAU); ctx.fill();
      break;
    }
    case "bug": {
      ctx.rotate(face);
      ctx.strokeStyle = C("#3a2a10"); ctx.lineWidth = 1.5;
      ctx.beginPath();
      for (let i = -1; i <= 1; i++) {
        const l = Math.sin(t * 30 + i) * 3;
        ctx.moveTo(i * 3, 0); ctx.lineTo(i * 3 + l, -r * 1.3);
        ctx.moveTo(i * 3, 0); ctx.lineTo(i * 3 - l, r * 1.3);
      }
      ctx.stroke();
      ctx.fillStyle = C(e.color);
      ctx.beginPath(); ctx.ellipse(0, 0, r * 1.1, r * 0.75, 0, 0, TAU); ctx.fill();
      ctx.fillStyle = C(e.color2);
      ctx.fillRect(-r * 0.1, -r * 0.7, 1.5, r * 1.4);
      ctx.fillStyle = "#ff4a1a"; ctx.beginPath(); ctx.arc(r * 0.9, 0, 2, 0, TAU); ctx.fill();
      break;
    }
    case "bat": {
      const flap = Math.sin(t * 22) * 0.8;
      ctx.fillStyle = C(e.color2);
      for (const s of [-1, 1]) {
        ctx.beginPath();
        ctx.moveTo(0, 0);
        ctx.quadraticCurveTo(s * r * 1.6, -r * (1.2 + flap), s * r * 2.4, -r * 0.2 * flap);
        ctx.quadraticCurveTo(s * r * 1.6, r * 0.2, s * r * 0.8, r * 0.5);
        ctx.closePath(); ctx.fill();
      }
      ctx.fillStyle = C(e.color);
      ctx.beginPath(); ctx.arc(0, 0, r * 0.75, 0, TAU); ctx.fill();
      ctx.beginPath(); ctx.moveTo(-r * 0.5, -r * 0.4); ctx.lineTo(-r * 0.3, -r * 1.1); ctx.lineTo(0, -r * 0.5); ctx.lineTo(r * 0.3, -r * 1.1); ctx.lineTo(r * 0.5, -r * 0.4); ctx.fill();
      ctx.fillStyle = "#ffdd4a"; ctx.beginPath(); ctx.arc(-2.5, -1, 1.5, 0, TAU); ctx.arc(2.5, -1, 1.5, 0, TAU); ctx.fill();
      break;
    }
    case "brute": {
      const windup = e.st === 1 ? 1 - e.stT / 0.85 : 0;
      ctx.fillStyle = C(e.color2);
      ctx.beginPath(); ctx.ellipse(0, r * 0.1, r * 1.05, r * 0.9, 0, 0, TAU); ctx.fill();
      ctx.fillStyle = C(e.color);
      ctx.beginPath(); ctx.ellipse(0, -r * 0.05, r * 0.92, r * 0.8, 0, 0, TAU); ctx.fill();
      // fists
      const lift = windup * r * 0.9;
      for (const s of [-1, 1]) {
        const a = face + s * 1.1;
        ctx.fillStyle = C("#6a2a2a");
        ctx.beginPath(); ctx.arc(Math.cos(a) * r * 1.05, Math.sin(a) * r * 1.05 - lift + Math.sin(t * 5 + s) * 2, r * 0.38, 0, TAU); ctx.fill();
      }
      ctx.fillStyle = C("#e8d8c0");
      ctx.beginPath(); ctx.moveTo(-r * 0.5, -r * 0.6); ctx.lineTo(-r * 0.75, -r * 1.15); ctx.lineTo(-r * 0.25, -r * 0.7); ctx.fill();
      ctx.beginPath(); ctx.moveTo(r * 0.5, -r * 0.6); ctx.lineTo(r * 0.75, -r * 1.15); ctx.lineTo(r * 0.25, -r * 0.7); ctx.fill();
      ctx.fillStyle = windup > 0 ? "#ffea4a" : "#ff8a2a";
      ctx.beginPath(); ctx.arc(fx * r * 0.3 - 6, -r * 0.3, 3, 0, TAU); ctx.arc(fx * r * 0.3 + 6, -r * 0.3, 3, 0, TAU); ctx.fill();
      break;
    }
    case "slime": {
      const sq = Math.sin(t * 4 + e.id);
      const sx = 1 + Math.max(0, -sq) * 0.2, sy = 1 + Math.max(0, sq) * 0.18;
      ctx.globalCompositeOperation = "lighter";
      drawGlow(ctx, e.color, 0, 0, r * 1.8);
      ctx.globalCompositeOperation = "source-over";
      ctx.fillStyle = f ? W : rgba(e.color, 0.82);
      ctx.beginPath(); ctx.ellipse(0, r * 0.1, r * sx, r * 0.85 * sy, 0, Math.PI, 0); ctx.quadraticCurveTo(r * sx, r * 0.6, 0, r * 0.65); ctx.quadraticCurveTo(-r * sx, r * 0.6, -r * sx, r * 0.1); ctx.fill();
      ctx.fillStyle = rgba("#ffffff", 0.5);
      ctx.beginPath(); ctx.ellipse(-r * 0.35, -r * 0.35, r * 0.2, r * 0.12, -0.5, 0, TAU); ctx.fill();
      ctx.fillStyle = "#123a12";
      ctx.beginPath(); ctx.arc(fx * 3 - 4, -r * 0.1, 2.2, 0, TAU); ctx.arc(fx * 3 + 4, -r * 0.1, 2.2, 0, TAU); ctx.fill();
      break;
    }
    case "stalker": {
      ctx.fillStyle = C(e.color2);
      for (let i = 0; i < 4; i++) {
        const a = Math.PI / 2 + (i - 1.5) * 0.4 + Math.sin(t * 6 + i) * 0.2;
        ctx.beginPath(); ctx.moveTo(-3 + i * 2, 0); ctx.quadraticCurveTo(Math.cos(a) * r * 1.2, Math.sin(a) * r * 1.3, Math.cos(a) * r * 1.7, Math.sin(a) * r * 1.9); ctx.lineTo(i * 2, r * 0.3); ctx.fill();
      }
      ctx.fillStyle = C(e.color);
      ctx.beginPath(); ctx.moveTo(0, -r * 1.2); ctx.quadraticCurveTo(r * 1.1, -r * 0.2, r * 0.6, r * 0.6); ctx.lineTo(-r * 0.6, r * 0.6); ctx.quadraticCurveTo(-r * 1.1, -r * 0.2, 0, -r * 1.2); ctx.fill();
      ctx.globalCompositeOperation = "lighter";
      drawGlow(ctx, "#b07aff", fx * 3 - 4, -r * 0.3, 6); drawGlow(ctx, "#b07aff", fx * 3 + 4, -r * 0.3, 6);
      ctx.globalCompositeOperation = "source-over";
      ctx.fillStyle = W; ctx.beginPath(); ctx.arc(fx * 3 - 4, -r * 0.3, 1.5, 0, TAU); ctx.arc(fx * 3 + 4, -r * 0.3, 1.5, 0, TAU); ctx.fill();
      break;
    }
    case "exploder": {
      const fuse = e.st === 1;
      const pulse = fuse ? 1 + Math.sin(t * 40) * 0.12 + (1 - e.stT / 0.8) * 0.3 : 1 + Math.sin(t * 5) * 0.04;
      ctx.scale(pulse, pulse);
      ctx.globalCompositeOperation = "lighter";
      drawGlow(ctx, fuse ? "#ff3a1a" : "#ff8a2a", 0, 0, r * (fuse ? 3 : 1.8));
      ctx.globalCompositeOperation = "source-over";
      ctx.fillStyle = C(fuse && Math.floor(t * 16) % 2 ? "#ffe14a" : e.color);
      ctx.beginPath(); ctx.arc(0, 0, r, 0, TAU); ctx.fill();
      ctx.strokeStyle = C(e.color2); ctx.lineWidth = 2;
      ctx.beginPath(); ctx.moveTo(-r * 0.6, -r * 0.2); ctx.lineTo(-r * 0.1, r * 0.1); ctx.lineTo(r * 0.4, -r * 0.3); ctx.moveTo(-r * 0.2, r * 0.5); ctx.lineTo(r * 0.3, r * 0.2); ctx.stroke();
      ctx.strokeStyle = "#3a2a1a"; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.moveTo(0, -r); ctx.quadraticCurveTo(r * 0.4, -r * 1.4, r * 0.2, -r * 1.6); ctx.stroke();
      ctx.globalCompositeOperation = "lighter";
      drawGlow(ctx, "#ffe14a", r * 0.2, -r * 1.6, 6 + Math.random() * 4);
      ctx.globalCompositeOperation = "source-over";
      break;
    }
    case "knight": {
      ctx.fillStyle = C(e.color2);
      ctx.beginPath(); ctx.arc(0, 0, r, 0, TAU); ctx.fill();
      ctx.fillStyle = C(e.color);
      ctx.beginPath(); ctx.arc(0, -r * 0.1, r * 0.82, 0, TAU); ctx.fill();
      ctx.fillStyle = "#1a1e26"; ctx.fillRect(-r * 0.5 + fx * 3, -r * 0.3, r, r * 0.16);
      ctx.fillStyle = C("#c83a3a"); ctx.beginPath(); ctx.moveTo(0, -r * 0.9); ctx.quadraticCurveTo(-r * 0.6, -r * 1.5, -r * 0.9, -r * 1.1); ctx.lineTo(0, -r * 0.7); ctx.fill();
      // shield arc in front
      ctx.rotate(face);
      ctx.strokeStyle = C("#e8eef8"); ctx.lineWidth = r * 0.35; ctx.lineCap = "round";
      ctx.beginPath(); ctx.arc(0, 0, r * 1.15, -1.0, 1.0); ctx.stroke();
      ctx.strokeStyle = C("#5ab8ff"); ctx.lineWidth = 2;
      ctx.beginPath(); ctx.arc(0, 0, r * 1.15, -0.6, 0.6); ctx.stroke();
      break;
    }
    case "demon": {
      const charge = e.st === 1;
      ctx.globalCompositeOperation = "lighter";
      drawGlow(ctx, "#ff4a1a", 0, 0, r * (2 + Math.sin(t * 9) * 0.2));
      if (charge) drawGlow(ctx, "#ffd04a", fx * r, fy * r, r * 1.2);
      ctx.globalCompositeOperation = "source-over";
      ctx.fillStyle = C(e.color2);
      ctx.beginPath();
      for (let i = 0; i < 7; i++) { const a = -Math.PI / 2 + (i - 3) * 0.35; const fl = r * (1.1 + Math.sin(t * 12 + i) * 0.25); ctx.lineTo(Math.cos(a) * fl, Math.sin(a) * fl - r * 0.2); }
      ctx.lineTo(r * 0.8, r * 0.6); ctx.lineTo(-r * 0.8, r * 0.6); ctx.fill();
      ctx.fillStyle = C(e.color);
      ctx.beginPath(); ctx.arc(0, 0, r * 0.8, 0, TAU); ctx.fill();
      ctx.fillStyle = C("#2a0a06");
      ctx.beginPath(); ctx.moveTo(-r * 0.5, -r * 0.5); ctx.lineTo(-r * 0.9, -r * 1.3); ctx.lineTo(-r * 0.2, -r * 0.7); ctx.fill();
      ctx.beginPath(); ctx.moveTo(r * 0.5, -r * 0.5); ctx.lineTo(r * 0.9, -r * 1.3); ctx.lineTo(r * 0.2, -r * 0.7); ctx.fill();
      ctx.fillStyle = "#ffe14a"; ctx.beginPath(); ctx.arc(fx * 3 - 4, -2, 2, 0, TAU); ctx.arc(fx * 3 + 4, -2, 2, 0, TAU); ctx.fill();
      break;
    }
    case "icemonster": {
      ctx.globalCompositeOperation = "lighter";
      drawGlow(ctx, "#5ab8ff", 0, 0, r * 2.2);
      ctx.globalCompositeOperation = "source-over";
      ctx.strokeStyle = rgba("#cff4ff", 0.18); ctx.lineWidth = 1;
      ctx.beginPath(); ctx.arc(0, 0, 140, 0, TAU); ctx.stroke();
      ctx.fillStyle = C(e.color2);
      ctx.beginPath();
      for (let i = 0; i < 8; i++) { const a = (i / 8) * TAU + t * 0.4; const rr = i % 2 ? r * 0.8 : r * 1.25; ctx.lineTo(Math.cos(a) * rr, Math.sin(a) * rr); }
      ctx.closePath(); ctx.fill();
      ctx.fillStyle = C(e.color);
      ctx.beginPath();
      for (let i = 0; i < 6; i++) { const a = (i / 6) * TAU - t * 0.3; ctx.lineTo(Math.cos(a) * r * 0.75, Math.sin(a) * r * 0.75); }
      ctx.closePath(); ctx.fill();
      ctx.fillStyle = "#0a2a4a"; ctx.beginPath(); ctx.arc(fx * 4 - 4, -2, 2.4, 0, TAU); ctx.arc(fx * 4 + 4, -2, 2.4, 0, TAU); ctx.fill();
      break;
    }
    case "spider": {
      ctx.strokeStyle = C("#2a1a3a"); ctx.lineWidth = 2;
      ctx.beginPath();
      for (let s = -1; s <= 1; s += 2) for (let i = 0; i < 4; i++) {
        const a = face + s * (0.5 + i * 0.45);
        const k = Math.sin(t * 18 + i * 1.3 + s) * 0.18;
        const kx = Math.cos(a + k) * r * 1.1, ky = Math.sin(a + k) * r * 1.1;
        ctx.moveTo(0, 0); ctx.lineTo(kx, ky - 5); ctx.lineTo(Math.cos(a + k) * r * 1.8, Math.sin(a + k) * r * 1.8);
      }
      ctx.stroke();
      ctx.fillStyle = C(e.color);
      ctx.beginPath(); ctx.ellipse(-fx * r * 0.4, -fy * r * 0.4, r * 0.85, r * 0.75, face, 0, TAU); ctx.fill();
      ctx.fillStyle = C("#4a2a5a");
      ctx.beginPath(); ctx.arc(fx * r * 0.45, fy * r * 0.45, r * 0.5, 0, TAU); ctx.fill();
      ctx.fillStyle = C(e.color2);
      ctx.beginPath(); ctx.arc(-fx * r * 0.45, -fy * r * 0.45, r * 0.3, 0, TAU); ctx.fill();
      ctx.fillStyle = "#ff3a5a";
      for (let i = 0; i < 4; i++) { ctx.beginPath(); ctx.arc(fx * r * 0.7 + Math.cos(face + Math.PI / 2) * (i - 1.5) * 2.5, fy * r * 0.7 + Math.sin(face + Math.PI / 2) * (i - 1.5) * 2.5, 1.2, 0, TAU); ctx.fill(); }
      break;
    }
    case "mage": {
      const cast = e.cd < 1;
      ctx.fillStyle = C(e.color);
      ctx.beginPath(); ctx.moveTo(0, -r * 1.3); ctx.lineTo(r * 0.95, r * 0.9); ctx.quadraticCurveTo(0, r * 1.1, -r * 0.95, r * 0.9); ctx.closePath(); ctx.fill();
      ctx.fillStyle = "#0a0614"; ctx.beginPath(); ctx.arc(fx * 2, -r * 0.35, r * 0.38, 0, TAU); ctx.fill();
      ctx.fillStyle = e.color2; ctx.beginPath(); ctx.arc(fx * 2 - 3, -r * 0.4, 1.6, 0, TAU); ctx.arc(fx * 2 + 3, -r * 0.4, 1.6, 0, TAU); ctx.fill();
      const sx = Math.cos(face) * r * 1.0, sy = -r * 0.2;
      ctx.strokeStyle = C("#6a4a2a"); ctx.lineWidth = 2.5;
      ctx.beginPath(); ctx.moveTo(sx, sy + r); ctx.lineTo(sx, sy - r * 0.9); ctx.stroke();
      ctx.globalCompositeOperation = "lighter";
      drawGlow(ctx, e.color2, sx, sy - r * 0.9, cast ? 18 + Math.sin(t * 20) * 4 : 10);
      ctx.globalCompositeOperation = "source-over";
      if (cast) { ctx.strokeStyle = rgba(e.color2, 0.6); ctx.lineWidth = 1.5; ctx.beginPath(); ctx.arc(0, r * 0.8, r * 1.3, t * 3, t * 3 + 4.5); ctx.stroke(); }
      break;
    }
    case "phantom": {
      ctx.globalCompositeOperation = "lighter";
      drawGlow(ctx, "#8aa6ff", 0, 0, r * 2);
      ctx.globalCompositeOperation = "source-over";
      ctx.fillStyle = f ? W : rgba(e.color, 0.85);
      ctx.beginPath();
      ctx.arc(0, -r * 0.2, r, Math.PI, 0);
      for (let i = 0; i <= 6; i++) { const x = r - (i / 6) * r * 2; ctx.lineTo(x, r * 0.8 + Math.sin(t * 8 + i * 1.5) * r * 0.25 * (i % 2 ? 1 : -0.4)); }
      ctx.closePath(); ctx.fill();
      ctx.fillStyle = "#1a2a4a";
      ctx.beginPath(); ctx.ellipse(fx * 3 - 4, -r * 0.25, 2.2, 3.4, 0, 0, TAU); ctx.ellipse(fx * 3 + 4, -r * 0.25, 2.2, 3.4, 0, 0, TAU); ctx.fill();
      ctx.beginPath(); ctx.ellipse(fx * 3, r * 0.2, 2, 3, 0, 0, TAU); ctx.fill();
      break;
    }
    case "hunter": {
      if (e.st === 1) {
        ctx.save(); ctx.rotate(face);
        ctx.fillStyle = rgba("#ff2a3a", 0.12 + 0.1 * Math.sin(t * 30)); ctx.fillRect(0, -r * 0.8, 290, r * 1.6);
        ctx.strokeStyle = rgba("#ff4a5a", 0.6); ctx.setLineDash([10, 8]); ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(290, 0); ctx.stroke(); ctx.setLineDash([]);
        ctx.restore();
      }
      ctx.rotate(face);
      ctx.fillStyle = C("#3a0a12");
      ctx.beginPath(); ctx.moveTo(-r * 0.6, 0); ctx.quadraticCurveTo(-r * 1.8, -r * 0.9 + Math.sin(t * 10) * 3, -r * 2, r * 0.2); ctx.quadraticCurveTo(-r * 1.6, r * 1, -r * 0.6, r * 0.4); ctx.fill();
      ctx.fillStyle = C(e.color2);
      ctx.beginPath(); ctx.moveTo(r * 1.3, 0); ctx.lineTo(-r * 0.8, -r * 0.95); ctx.lineTo(-r * 0.4, 0); ctx.lineTo(-r * 0.8, r * 0.95); ctx.closePath(); ctx.fill();
      ctx.fillStyle = C(e.color);
      ctx.beginPath(); ctx.moveTo(r * 1.1, 0); ctx.lineTo(-r * 0.5, -r * 0.65); ctx.lineTo(-r * 0.2, 0); ctx.lineTo(-r * 0.5, r * 0.65); ctx.closePath(); ctx.fill();
      ctx.globalCompositeOperation = "lighter";
      drawGlow(ctx, "#ff2a3a", r * 0.4, 0, 9);
      ctx.globalCompositeOperation = "source-over";
      break;
    }
    case "guardian": {
      ctx.globalCompositeOperation = "lighter";
      drawGlow(ctx, e.color2, 0, 0, r * 1.6 + Math.sin(t * 3) * 6);
      ctx.globalCompositeOperation = "source-over";
      for (let i = 0; i < 4; i++) {
        const a = t * 0.8 + (i / 4) * TAU;
        ctx.fillStyle = C("#6a6458");
        ctx.beginPath(); ctx.arc(Math.cos(a) * r * 1.45, Math.sin(a) * r * 1.45, r * 0.22, 0, TAU); ctx.fill();
      }
      ctx.fillStyle = C("#5a5448");
      ctx.beginPath(); ctx.roundRect(-r, -r * 0.9, r * 2, r * 1.8, r * 0.3); ctx.fill();
      ctx.fillStyle = C(e.color);
      ctx.beginPath(); ctx.roundRect(-r * 0.8, -r * 1.05, r * 1.6, r * 1.2, r * 0.25); ctx.fill();
      ctx.strokeStyle = e.color2; ctx.lineWidth = 2.5;
      ctx.beginPath(); ctx.moveTo(-r * 0.5, r * 0.3); ctx.lineTo(0, r * 0.6); ctx.lineTo(r * 0.5, r * 0.3); ctx.moveTo(0, r * 0.6); ctx.lineTo(0, r * 0.85); ctx.stroke();
      ctx.globalCompositeOperation = "lighter";
      drawGlow(ctx, e.color2, fx * 6 - 10, -r * 0.5, 10); drawGlow(ctx, e.color2, fx * 6 + 10, -r * 0.5, 10);
      ctx.globalCompositeOperation = "source-over";
      break;
    }
  }
  ctx.restore();
  if (e.freezeT > 0) {
    ctx.fillStyle = rgba("#bfeaff", 0.45);
    ctx.strokeStyle = rgba("#ffffff", 0.8); ctx.lineWidth = 1.5;
    ctx.beginPath();
    for (let i = 0; i < 6; i++) { const a = (i / 6) * TAU + 0.3; ctx.lineTo(e.x + Math.cos(a) * r * 1.2, e.y + Math.sin(a) * r * 1.2); }
    ctx.closePath(); ctx.fill(); ctx.stroke();
  } else if (e.slowT > 0 && e.slowAmt > 0.3 && !f) {
    ctx.fillStyle = rgba("#9be7ff", 0.2);
    ctx.beginPath(); ctx.arc(e.x, e.y, r, 0, TAU); ctx.fill();
  }
  if (e.burnT > 0) { ctx.globalCompositeOperation = "lighter"; drawGlow(ctx, "#ff6a1a", e.x, e.y - r * 0.3, r * 1.2); ctx.globalCompositeOperation = "source-over"; }
  if (e.poisonT > 0) { ctx.fillStyle = rgba("#9dff6a", 0.25); ctx.beginPath(); ctx.arc(e.x, e.y, r * 0.9, 0, TAU); ctx.fill(); }
  if (e.elite && e.type !== "guardian") {
    ctx.strokeStyle = rgba("#ffd84a", 0.7); ctx.lineWidth = 2;
    ctx.beginPath(); ctx.arc(e.x, e.y, r + 5, g.realT * 3, g.realT * 3 + 4.5); ctx.stroke();
  }
  if (e.maxHp > 60 && e.hp < e.maxHp) {
    const w = Math.max(24, r * 2);
    const y = e.y + r + 8;
    ctx.fillStyle = "rgba(0,0,0,0.6)"; ctx.fillRect(e.x - w / 2 - 1, y - 1, w + 2, 5);
    ctx.fillStyle = e.type === "guardian" ? "#5affd6" : "#ff4a4a"; ctx.fillRect(e.x - w / 2, y, w * Math.max(0, e.hp / e.maxHp), 3);
  }
}

// ------------------------------------------------------------------ bosses
export function drawBoss(ctx: CanvasRenderingContext2D, e: Enemy, g: Game) {
  const b = e.boss!;
  const f = e.hitFlash > 0;
  const C = (c: string) => (f ? W : c);
  const r = e.r, t = e.t;
  const def = b.def;
  const face = e.facing;
  const fx = Math.cos(face);
  const sc = e.spawnT > 0 ? Math.max(0.05, 1 - e.spawnT / 0.8) : 1;
  ctx.save();
  ctx.translate(e.x, e.y);
  ctx.scale(sc, sc);
  if (e.invuln) ctx.globalAlpha = 0.3;
  ctx.globalCompositeOperation = "lighter";
  drawGlow(ctx, def.color, 0, 0, r * (2.4 + b.phase * 0.3) + Math.sin(t * 4) * 8);
  ctx.globalCompositeOperation = "source-over";
  switch (def.id) {
    case "plague_queen": {
      const flap = Math.sin(t * 16) * 0.3;
      ctx.fillStyle = f ? W : rgba("#c8ffb0", 0.35);
      for (const s of [-1, 1]) {
        ctx.beginPath(); ctx.ellipse(s * r * 0.9, -r * 0.5, r * 1.1, r * 0.45, s * (0.5 + flap), 0, TAU); ctx.fill();
        ctx.beginPath(); ctx.ellipse(s * r * 0.8, -r * 0.1, r * 0.8, r * 0.3, s * (0.9 + flap), 0, TAU); ctx.fill();
      }
      ctx.fillStyle = C(def.color2);
      ctx.beginPath(); ctx.ellipse(0, r * 0.5, r * 0.7, r * 0.95, 0, 0, TAU); ctx.fill();
      ctx.globalCompositeOperation = "lighter";
      drawGlow(ctx, def.color, 0, r * 0.6, r * 0.9);
      ctx.globalCompositeOperation = "source-over";
      ctx.strokeStyle = C(def.color); ctx.lineWidth = 3;
      for (let i = 0; i < 3; i++) { ctx.beginPath(); ctx.ellipse(0, r * 0.5, r * 0.6 - i * 4, r * 0.25, 0, 0.2, Math.PI - 0.2); ctx.stroke(); }
      ctx.fillStyle = C("#5a2a6a");
      ctx.beginPath(); ctx.arc(0, -r * 0.35, r * 0.55, 0, TAU); ctx.fill();
      ctx.fillStyle = C("#ffd84a");
      ctx.beginPath(); ctx.moveTo(-r * 0.4, -r * 0.75); for (let i = 0; i < 5; i++) { ctx.lineTo(-r * 0.4 + i * r * 0.2, -r * (i % 2 ? 0.9 : 1.15)); } ctx.lineTo(r * 0.4, -r * 0.75); ctx.fill();
      ctx.fillStyle = def.color;
      for (let i = 0; i < 3; i++) { ctx.beginPath(); ctx.arc(fx * 6 + (i - 1) * 9, -r * 0.35, 3, 0, TAU); ctx.fill(); }
      break;
    }
    case "infernal_beast": {
      ctx.fillStyle = C("#ff8a2a");
      ctx.beginPath();
      for (let i = 0; i < 16; i++) { const a = (i / 16) * TAU; const rr = r * (1.15 + Math.sin(t * 10 + i * 2) * 0.12) * (i % 2 ? 0.95 : 1.2); ctx.lineTo(Math.cos(a) * rr, Math.sin(a) * rr); }
      ctx.closePath(); ctx.fill();
      ctx.fillStyle = C(def.color2);
      ctx.beginPath(); ctx.arc(0, 0, r * 0.95, 0, TAU); ctx.fill();
      ctx.strokeStyle = "#ff5a1a"; ctx.lineWidth = 3;
      ctx.beginPath(); ctx.moveTo(-r * 0.6, r * 0.2); ctx.lineTo(-r * 0.2, r * 0.5); ctx.lineTo(r * 0.1, r * 0.2); ctx.lineTo(r * 0.6, r * 0.5); ctx.moveTo(-r * 0.3, -r * 0.6); ctx.lineTo(0, -r * 0.3); ctx.stroke();
      ctx.fillStyle = C("#1a0a06");
      for (const s of [-1, 1]) { ctx.beginPath(); ctx.moveTo(s * r * 0.4, -r * 0.6); ctx.quadraticCurveTo(s * r * 1.2, -r * 1.1, s * r * 1.0, -r * 1.7); ctx.lineTo(s * r * 0.7, -r * 0.7); ctx.fill(); }
      ctx.fillStyle = "#ffe14a";
      ctx.beginPath(); ctx.ellipse(fx * 8 - 14, -r * 0.2, 6, 4, -0.3, 0, TAU); ctx.ellipse(fx * 8 + 14, -r * 0.2, 6, 4, 0.3, 0, TAU); ctx.fill();
      ctx.fillStyle = "#ff3a1a"; ctx.beginPath(); ctx.ellipse(fx * 6, r * 0.35, r * 0.35, r * 0.15 + Math.sin(t * 6) * 3, 0, 0, TAU); ctx.fill();
      break;
    }
    case "bone_king": {
      for (let i = 0; i < 5; i++) {
        const a = t * 1.2 + (i / 5) * TAU;
        const x = Math.cos(a) * r * 1.6, y = Math.sin(a) * r * 1.6;
        ctx.fillStyle = C("#e8f4ff"); ctx.beginPath(); ctx.arc(x, y, 9, 0, TAU); ctx.fill();
        ctx.fillStyle = "#4ab8ff"; ctx.beginPath(); ctx.arc(x - 3, y - 1, 2, 0, TAU); ctx.arc(x + 3, y - 1, 2, 0, TAU); ctx.fill();
      }
      ctx.fillStyle = C("#2a3a5a");
      ctx.beginPath(); ctx.moveTo(-r, r); ctx.lineTo(-r * 0.7, -r * 0.2); ctx.lineTo(r * 0.7, -r * 0.2); ctx.lineTo(r, r); ctx.quadraticCurveTo(0, r * 1.3, -r, r); ctx.fill();
      ctx.strokeStyle = C(def.color); ctx.lineWidth = 4;
      for (let i = 0; i < 4; i++) { ctx.beginPath(); ctx.moveTo(-r * 0.5, r * 0.05 + i * 10); ctx.quadraticCurveTo(0, r * 0.2 + i * 10, r * 0.5, r * 0.05 + i * 10); ctx.stroke(); }
      ctx.fillStyle = C(def.color);
      ctx.beginPath(); ctx.arc(0, -r * 0.5, r * 0.55, 0, TAU); ctx.fill();
      ctx.fillRect(-r * 0.3, -r * 0.15, r * 0.6, r * 0.2);
      ctx.fillStyle = "#0a1424";
      ctx.beginPath(); ctx.arc(-r * 0.2 + fx * 3, -r * 0.55, r * 0.14, 0, TAU); ctx.arc(r * 0.2 + fx * 3, -r * 0.55, r * 0.14, 0, TAU); ctx.fill();
      ctx.globalCompositeOperation = "lighter";
      drawGlow(ctx, def.color2, -r * 0.2 + fx * 3, -r * 0.55, 10); drawGlow(ctx, def.color2, r * 0.2 + fx * 3, -r * 0.55, 10);
      ctx.globalCompositeOperation = "source-over";
      ctx.fillStyle = C("#7ad7ff");
      ctx.beginPath(); ctx.moveTo(-r * 0.5, -r * 0.85); for (let i = 0; i < 7; i++) ctx.lineTo(-r * 0.5 + i * r / 6, -r * (i % 2 ? 1.0 : 1.4)); ctx.lineTo(r * 0.5, -r * 0.85); ctx.fill();
      break;
    }
    case "destroyer": {
      ctx.save(); ctx.rotate(t * 0.5);
      ctx.fillStyle = C("#5a5448");
      for (let i = 0; i < 4; i++) { ctx.rotate(TAU / 4); ctx.fillRect(r * 0.6, -r * 0.18, r * 0.75, r * 0.36); ctx.fillStyle = C("#ff3a2a"); ctx.fillRect(r * 1.25, -r * 0.1, r * 0.12, r * 0.2); ctx.fillStyle = C("#5a5448"); }
      ctx.restore();
      ctx.fillStyle = C("#3a3630");
      ctx.beginPath(); for (let i = 0; i < 8; i++) { const a = (i / 8) * TAU + Math.PI / 8; ctx.lineTo(Math.cos(a) * r, Math.sin(a) * r); } ctx.closePath(); ctx.fill();
      ctx.fillStyle = C(def.color);
      ctx.beginPath(); for (let i = 0; i < 8; i++) { const a = (i / 8) * TAU + Math.PI / 8; ctx.lineTo(Math.cos(a) * r * 0.75, Math.sin(a) * r * 0.75); } ctx.closePath(); ctx.fill();
      ctx.fillStyle = "#1a1814"; ctx.beginPath(); ctx.arc(0, 0, r * 0.4, 0, TAU); ctx.fill();
      ctx.globalCompositeOperation = "lighter";
      drawGlow(ctx, def.color2, Math.cos(face) * r * 0.15, Math.sin(face) * r * 0.15, r * 0.6 + Math.sin(t * 8) * 4);
      ctx.globalCompositeOperation = "source-over";
      ctx.fillStyle = "#ffffff"; ctx.beginPath(); ctx.arc(Math.cos(face) * r * 0.15, Math.sin(face) * r * 0.15, 4, 0, TAU); ctx.fill();
      break;
    }
    case "void_titan": {
      ctx.strokeStyle = rgba("#c27bff", 0.6); ctx.lineWidth = 3;
      for (let i = 0; i < 3; i++) { ctx.beginPath(); ctx.ellipse(0, 0, r * (1.4 + i * 0.25), r * (0.35 + i * 0.08), t * (0.4 + i * 0.2) + i, 0, TAU); ctx.stroke(); }
      ctx.strokeStyle = C("#2a0a4a"); ctx.lineWidth = 8; ctx.lineCap = "round";
      for (let i = 0; i < 6; i++) { const a = (i / 6) * TAU + Math.sin(t + i) * 0.3; ctx.beginPath(); ctx.moveTo(Math.cos(a) * r * 0.8, Math.sin(a) * r * 0.8); ctx.quadraticCurveTo(Math.cos(a + 0.4) * r * 1.4, Math.sin(a + 0.4) * r * 1.4, Math.cos(a + Math.sin(t * 2 + i) * 0.5) * r * 1.8, Math.sin(a + Math.sin(t * 2 + i) * 0.5) * r * 1.8); ctx.stroke(); }
      ctx.fillStyle = C(def.color2);
      ctx.beginPath(); ctx.arc(0, 0, r, 0, TAU); ctx.fill();
      ctx.fillStyle = C("#3a1a5a");
      ctx.beginPath(); ctx.arc(0, 0, r * 0.82, 0, TAU); ctx.fill();
      const ex = Math.cos(face) * r * 0.25, ey = Math.sin(face) * r * 0.25;
      ctx.fillStyle = "#f8e8ff"; ctx.beginPath(); ctx.ellipse(ex, ey, r * 0.42, r * 0.3, 0, 0, TAU); ctx.fill();
      ctx.fillStyle = def.color; ctx.beginPath(); ctx.arc(ex + Math.cos(face) * 6, ey + Math.sin(face) * 6, r * 0.2, 0, TAU); ctx.fill();
      ctx.fillStyle = "#0a0414"; ctx.beginPath(); ctx.ellipse(ex + Math.cos(face) * 8, ey + Math.sin(face) * 8, r * 0.06, r * 0.17, 0, 0, TAU); ctx.fill();
      break;
    }
  }
  ctx.restore();
  void fx;
}
