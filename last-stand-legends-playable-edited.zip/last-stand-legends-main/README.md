# Last Stand Legends

# CREATE THE ULTIMATE SURVIVORS.IO GAME

Build a complete, highly polished, addictive and skill-based survival roguelite game inspired by Survivors.io, but make it significantly more advanced, exciting and visually impressive.

The game should feel like a professional indie action game with fluid gameplay, satisfying combat, incredible visual effects, challenging enemies and deep progression.

IMPORTANT: Do not create just a landing page or a static prototype. Build a FULLY PLAYABLE GAME.

# 1. CORE GAMEPLAY

Create a top-down 2D survival arena game.

The player must survive increasingly difficult waves of monsters while collecting XP, leveling up and choosing upgrades.

Controls:
- WASD to move.
- Arrow keys as alternative movement.
- Mouse to aim where applicable.
- Space for a special ability.
- Shift for a dodge dash with cooldown.
- Responsive mobile joystick and ability buttons.

Make movement smooth and responsive.

The game should reward:
- Accurate movement.
- Good positioning.
- Dodging enemy attacks.
- Timing abilities.
- Choosing smart upgrades.
- Learning enemy attack patterns.

Avoid making the game completely automatic. Player skill must matter.

# 2. AMAZING GRAPHICS AND VISUAL EFFECTS

Create a polished visual style with:
- Smooth character animations.
- Detailed monster animations.
- Glowing projectiles.
- Particle explosions.
- Screen shake on powerful hits.
- Damage numbers.
- Critical hit effects.
- Glowing XP crystals.
- Beautiful attack animations.
- Dynamic shadows.
- Animated environmental effects.
- Flash effects when enemies get hit.
- Cinematic boss introductions.

Add satisfying visual feedback to every important action.

Use a consistent, professional art direction.

# 3. MONSTERS AND ENEMIES

Create at least 15 different enemy types.

Examples:

1. Zombie Runner – fast but weak.
2. Giant Brute – slow and extremely strong.
3. Toxic Slime – leaves dangerous puddles.
4. Shadow Stalker – teleports toward the player.
5. Exploder – creates an explosion when defeated.
6. Flying Bat – moves unpredictably.
7. Armored Knight – blocks frontal attacks.
8. Fire Demon – shoots fire projectiles.
9. Ice Monster – slows the player.
10. Swarm Bug – attacks in large groups.
11. Poison Spider – shoots poison.
12. Dark Mage – summons other monsters.
13. Phantom – briefly becomes invulnerable.
14. Elite Hunter – actively tracks the player.
15. Ancient Guardian – extremely powerful boss.

Every enemy must have:
- Unique movement.
- Different attack patterns.
- Different health and damage.
- Unique animations.
- Unique visual design.

# 4. EPIC BOSS FIGHTS

Add large boss battles throughout each run.

Bosses should have:
- Multiple attack patterns.
- Special abilities.
- Multiple phases.
- Large health bars.
- Unique animations.
- Special sound effects.
- Reward drops.

Make boss fights challenging and skill-based.

Examples:
- The Bone King.
- The Infernal Beast.
- The Void Titan.
- The Plague Queen.
- The Ancient Destroyer.

# 5. WEAPONS AND UPGRADES

Create at least 12 unique weapons.

Examples:
- Plasma Blades.
- Lightning Orb.
- Fire Nova.
- Shadow Daggers.
- Ice Storm.
- Meteor Strike.
- Poison Cloud.
- Energy Beam.
- Magic Missiles.
- Explosive Mines.
- Boomerang Blades.
- Dragon Breath.

Each weapon should have:
- Different attack mechanics.
- Upgrade levels.
- Unique animations.
- Different damage types.
- Special evolution forms.

# 6. WEAPON EVOLUTION SYSTEM

Create an exciting evolution system.

When a weapon reaches maximum level and the player meets certain requirements, it can evolve into a powerful new weapon.

Examples:
- Lightning Orb → Thunderstorm.
- Fire Nova → Inferno.
- Shadow Daggers → Void Blades.
- Ice Storm → Absolute Zero.

Evolved weapons should look and feel significantly more powerful.

# 7. LEVEL-UP SYSTEM

Whenever the player collects enough XP:
- Pause the game.
- Display 3 randomized upgrade choices.
- Give each upgrade a unique icon and description.
- Let the player choose one.

Upgrade categories:
- Damage.
- Attack speed.
- Movement speed.
- Critical chance.
- Maximum health.
- Armor.
- XP collection range.
- Dodge cooldown.
- Weapon upgrades.

Make every choice feel meaningful.

# 8. MAPS AND ENVIRONMENTS

Create at least 5 unique arenas:

1. Cursed Forest.
2. Lava Wasteland.
3. Frozen Kingdom.
4. Abandoned City.
5. Dark Dimension.

Each map should have:
- Unique background.
- Different enemy types.
- Environmental effects.
- Unique visual atmosphere.
- Special challenges.
- Unique boss.

# 9. PROGRESSION AND REWARDS

Add:
- Coins.
- XP.
- Unlockable characters.
- Permanent upgrades.
- Weapon unlocks.
- Achievements.
- Daily challenges.
- Best score tracking.
- Survival time records.
- Difficulty levels.

Create a satisfying progression system that makes players want to play again.

# 10. CHARACTER SYSTEM

Create at least 8 unlockable characters.

Every character should have:
- Unique appearance.
- Unique starting weapon.
- Special ability.
- Different strengths and weaknesses.
- Unique animations.

# 11. GAME MODES

Include:

CLASSIC SURVIVAL:
Survive for 15 minutes and defeat the final boss.

ENDLESS MODE:
Enemies become increasingly difficult forever.

BOSS RUSH:
Fight a sequence of powerful bosses.

CHALLENGE MODE:
Special gameplay rules and unique rewards.

# 12. SOUND AND MUSIC

Add:
- Background music.
- Weapon sounds.
- Monster sounds.
- Hit sounds.
- Level-up sounds.
- Boss music.
- Reward sounds.
- Menu sound effects.

Include sound settings and volume controls.

# 13. USER INTERFACE

Create a premium game interface.

Main menu:
- Play.
- Character selection.
- Weapon collection.
- Upgrades.
- Achievements.
- Settings.

During gameplay:
- Health bar.
- XP bar.
- Level indicator.
- Survival timer.
- Kill counter.
- Weapon indicators.
- Special ability cooldowns.
- Boss health bar.

Make everything clean, modern and easy to understand.

# 14. IMPORTANT GAME FEEL

This is extremely important:

The game must feel FUN.

Add:
- Satisfying combat.
- Smooth animations.
- Responsive controls.
- Interesting enemy combinations.
- Intense boss battles.
- Powerful weapon evolutions.
- Rewarding progression.
- Increasing difficulty.
- Interesting strategic decisions.

The player should constantly feel that they are becoming stronger, while the enemies become more dangerous.

# 15. TECHNICAL REQUIREMENTS

Build the game using a suitable game-rendering system such as HTML5 Canvas.

Requirements:
- Real-time game loop.
- Delta-time-based movement.
- Efficient enemy spawning.
- Object pooling for projectiles and particles.
- Collision detection.
- Proper hitboxes.
- Responsive screen scaling.
- Optimized rendering.
- Smooth performance.
- Working keyboard and mouse controls.
- Mobile support.
- Proper game state management.
- Functional menus and buttons.

Separate game logic, rendering, enemies, weapons, progression and UI into maintainable modules.

Do not use fake buttons or non-functional features.

# FINAL INSTRUCTION

Prioritize a genuinely playable, polished and skill-based game over simply adding lots of menus.

Build the complete core gameplay first, then implement the additional systems.

Every weapon, enemy, boss, upgrade and game mode must actually work.

The final result should feel like a premium next-generation Survivors.io experience with incredible effects, smooth animations, challenging gameplay and tons of replayability.

Make it visually spectacular and extremely fun to play.

This project was built with [Lovable](https://lovable.dev).

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/28c33adf-233a-42c6-972a-49a62da82aea).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
